// name: 物品模型示例
// author: coj2
// version: 1.0.0
// description: 演示自定义物品的 3D 模型 + 动画 —— 一把会飘会转的"水晶法杖"。
//              · icon  = 背包/物品栏里的 2D 图标（老能力）
//              · model = 手持 / 掉在地上时的 3D 模型（复用方块那套写法：box 单位是像素）
//              · anim  = 每帧姿态：水晶部件自转 + 上下浮动
//              需要 2026-09-16 之后编的 exe（那时 Item.defineItem 才认 model / anim）。

var STAFF_ID = 240;          // 逻辑 id（被占会自动顺延，用返回值）

var TEX_WOOD    = "blocks/staff_wood.png";      // 木柄
var TEX_CRYSTAL = "blocks/staff_crystal.png";   // 水晶（也拿它当背包图标）

var staff = Item.defineItem(STAFF_ID, {
	name: "水晶法杖",
	icon: TEX_CRYSTAL,

	// box: [x, y, z, 宽, 高, 深]，单位是像素（16 = 一格）
	model: [
		{ name: "handle",  box: [7, 0,  7, 2, 10, 2], texture: TEX_WOOD },              // 木柄
		{ name: "crystal", box: [5, 10, 5, 6, 6,  6], texture: TEX_CRYSTAL, emissive: true }  // 顶端水晶（自发光）
	],

	// anim: function(part, age, time) -> {x,y,z[, px,py,pz]} | null
	//   x/y/z  = 相对静止姿态再叠加的旋转（弧度）；px/py/pz = 平移（格内单位 0..1）
	//   age    = 世界时间(刻的低 16 位)，time = 世界时间(秒)
	//   返回 null 表示这个部件不动。
	anim: function (part, age, time) {
		if (part !== "crystal") return null;   // 木柄不动
		return {
			x: 0,
			y: age * 0.08,                                    // 绕着竖轴慢慢自转
			z: 0,
			py: 11.0 / 16.0 + Math.sin(age * 0.12) * 0.04     // 上下轻轻浮动
		};
	}
});

log("水晶法杖已注册：物理 id=" + staff);

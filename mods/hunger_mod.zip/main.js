// name: 饥饿值系统
// author: You
// version: 1.4.0
// description: 饥饿值 + 自然回血 + 饿死 + 难度/创造感知 + 持久化
modLog("hunger mod loading...");

// ===== 饥饿值状态（0-10 格，半格 0.5） =====
var HUNGER_MAX = 10;
var hunger = 10;
var prevHealth = 20;
var regTick = 0;
var starveTick = 0;
var tick = 0;
var prevHunger = 10;

function clampHunger() {
    if (hunger < 0) hunger = 0;
    if (hunger > HUNGER_MAX) hunger = HUNGER_MAX;
}

// 暴露给其他模组（疾跑等）
function __mod_get_hunger() { return hunger; }

// 按难度调整消耗：和平=0，简单/普通=30%（少70%），困难=100%
function hungerCost(base) {
    var d = level.getDifficulty();
    if (d == 0) return 0;
    if (d < 3) return base * 0.3;
    return base;
}

// ===== 消耗（创造模式不消耗） =====
function onJump()       { if (player.isCreative()) return; hunger -= hungerCost(0.05); clampHunger(); }
function onAttack()     { if (player.isCreative()) return; hunger -= hungerCost(0.1);  clampHunger(); }
function onBreakBlock() { if (player.isCreative()) return; hunger -= hungerCost(0.005); clampHunger(); }

// 吃食物：nutrition（0-20 单位）-> 恢复饥饿（/2 转成格）
function onEatFood(nutrition) {
    if (player.isCreative()) return;
    hunger += nutrition / 2;
    clampHunger();
    player.sendMessage("恢复了饥饿值 +" + (nutrition / 2));
}

// 测试指令：/starve 一键饥饿归零
function onChat(msg) {
    if (msg == "/starve") {
        hunger = 0;
        starveTick = 0;
        player.sendMessage("饥饿值已归零！开始掉血");
    }
}

// 能不能吃由 JS 决定：血满也能吃，只有饥饿值满了才吃不了
__mod_can_eat = function(itemId) {
    if (player.isCreative()) return false;
    return hunger < HUNGER_MAX;
};

// 进世界：恢复上次保存的饥饿值
function onJoinWorld() {
    var v = parseFloat(level.getModState("hunger"));
    if (!isNaN(v)) {
        hunger = v;
        clampHunger();
    }
    prevHealth = player.getHealth();
}

// ===== 每 tick：受伤 + 自然回血 + 饿死 + 定期保存 =====
function onTick() {
    tick++;
    if (player.isCreative()) {
        prevHealth = player.getHealth();
        return;   // 创造模式：不消耗、不回血、不饿死
    }
    var h = player.getHealth();

    // 死亡复活：饥饿值回满
    if (prevHealth <= 0 && h > 0) {
        hunger = HUNGER_MAX;
        regTick = 0;
        starveTick = 0;
    }

    if (h < prevHealth) {
        hunger -= hungerCost(0.1);   // 受伤消耗（按难度）
        clampHunger();
    }
    prevHealth = h;

    // 饥饿耗尽：归零立即扣第一下，之后每秒扣 1 血（走伤害系统，有受击反馈）
    if (hunger <= 0) {
        if (prevHunger > 0 || starveTick >= 20) {
            starveTick = 0;
            if (h > 0) player.damage(1);
        } else {
            starveTick++;
        }
    } else {
        starveTick = 0;
    }
    prevHunger = hunger;

    // 自然回血（饥饿驱动）
    regTick++;
    var interval = 0;           // tick 间隔；0 = 不回血
    if (hunger >= 10)      interval = 10;   // 满 -> 每 0.5 秒回 1 血
    else if (hunger >= 6)  interval = 80;   // 6~9 -> 每 4 秒回 1 血
    // <=5 不回血
    if (interval > 0 && h > 1 && regTick >= interval) {
        regTick = 0;
        player.setHealth(h + 1);
        hunger -= hungerCost(0.1);   // 每回 1 滴血消耗（按难度）
        clampHunger();
    }

    // 每 5 秒保存一次饥饿值
    if (tick % 100 == 0)
        level.setModState("hunger", hunger);
}

// ===== 右上角显示 10 个饥饿值（自适应界面大小，创造模式不显示） =====
function onGuiRender() {
    if (player.isCreative()) return;
    var scale = ui.getScale();              // GUI 缩放：正常 3，小 1.5，大 4.5
    var icon = Math.round(14 * scale / 3);  // 小界面 7；普通/大界面封顶 9
    if (icon < 5) icon = 5;
    if (icon > 9) icon = 9;
    var gap = Math.max(1, Math.round(icon / 16));
    var w = ui.getWidth();
    var totalW = 10 * icon + 9 * gap;
    var x0 = w - totalW - 6;                // 右对齐
    var y = 6;
    for (var i = 0; i < 10; i++) {
        var img = "hud/hunger_empty.png";
        if (hunger >= i + 1)      img = "hud/hunger_full.png";
        else if (hunger > i)      img = "hud/hunger_half.png";
        ui.drawImage(img, x0 + i * (icon + gap), y, icon, icon);
    }
}

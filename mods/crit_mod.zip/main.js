// name: 暴击模组
// author: You
// version: 1.3.0
// description: 玩家跳跃后 2 秒内攻击 -> 暴击（跳砍）：爆炸粒子 + 伤害 1.5 倍
modLog("crit mod loading...");

var lastPlayerJump = -999;   // 玩家最近一次跳跃的 tick
var tick = 0;
var CRIT_WINDOW = 40;        // 2 秒（20 tick/秒）

function onTick() { tick++; }

// 玩家跳跃（跳砍暴击的来源）
function onJump() { lastPlayerJump = tick; }

// C++ 攻击前调：玩家在 2 秒内跳过 -> 这次攻击暴击（伤害 +50%）
__mod_is_critical = function(victimId) {
    return tick - lastPlayerJump <= CRIT_WINDOW;
};

// 攻击命中瞬间：被攻击物位置爆出爆炸粒子
function onAttack(victimId) {
    if (tick - lastPlayerJump > CRIT_WINDOW) return;
    var p = mob.getPos(victimId);
    if (!p) return;
    var bx = p[0], by = p[1] + 1, bz = p[2];
    // 40 个爆炸粒子（径向高速扩散）
    for (var i = 0; i < 40; i++) {
        var a = Math.random() * Math.PI * 2;
        var v = 0.5 + Math.random() * 0.8;
        level.spawnParticle("explode", bx, by, bz,
            Math.cos(a) * v, Math.random() * 0.8, Math.sin(a) * v);
    }
    // 8 个浓烟补充
    for (var i = 0; i < 8; i++) {
        level.spawnParticle("largesmoke", bx, by, bz,
            (Math.random() - 0.5) * 0.5, Math.random() * 0.4, (Math.random() - 0.5) * 0.5);
    }
}

// 测试指令：/zombie 生成一只僵尸（测暴击用）
function onChat(msg) {
    if (msg == "/zombie" || msg == "/z") {
        level.spawnVanilla("zombie", player.getX() + 2, player.getY(), player.getZ());
        player.sendMessage("生成了一只僵尸！");
    } else if (msg == "/cow") {
        level.spawnVanilla("cow", player.getX() + 2, player.getY(), player.getZ());
        player.sendMessage("生成了一只牛！");
    }
}

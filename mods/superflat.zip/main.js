// name: 超平坦维度
// author: coj2
// version: 1.0.0
// environment: both
// description: 一个超平坦维度（建筑 / 测试用）：地表一层草，下面泥土，再往下石头直到基岩。
//   /flat             进入超平坦
//   /flat back        回主世界（出生点附近）
//   /flat height <n>  改地面高度（8~120，默认 64；只对还没生成的区块生效）
//   /flat info        看当前设置
//
// 用到的引擎 API：
//   Dimension.define(编号, { name, clouds, blocks, getHeight })
//   level.changePlayerDimension(pid, dim, x, y, z)   // pid <= 0 = 本机玩家
//   level.getBlock(x, y, z)
//   getConfig(key, default) / setConfig(key, value)  // 模组级配置，不依赖世界
//
// 为什么维度编号写死：
//   维度编号会进存档目录（<世界>/dim<编号>/）。自动编号（Dimension.define 省略编号）
//   是按"当前装了哪些模组"算的，加载顺序一变、或某个模组被禁用，编号就会挪位，旧存档的
//   维度跟着错位。所以这个模组装在哪个世界上，编号都得是同一个 → 写死 21。

var MOD_NAME    = "超平坦";
var MOD_VERSION = "1.0.0";
var MOD_TAG     = "\u00a7b[" + MOD_NAME + "]\u00a7r ";

var C_OK = "\u00a7a", C_ERR = "\u00a7c", C_INFO = "\u00a7e", C_DIM = "\u00a77", C_HI = "\u00a7f";

var FLAT_DIM    = 21;   // 写死（避开主世界 0 与 10）
var FLAT_HEIGHT = 64;   // 地面（草方块）所在的高度
var GRASS = 2, DIRT = 3, STONE = 1;

var HAS_DIM_API = (typeof Dimension !== "undefined") && Dimension && typeof Dimension.define === "function";

function log(m) { modLog("[superflat] " + m); }
function reply(m) { return MOD_TAG + m; }
function s(v) { return (v === null || v === undefined) ? "" : String(v); }
function trim(v) { return s(v).replace(/^\s+|\s+$/g, ""); }

// 高度存在模组配置里（跟着游戏走，不依赖某个世界）
if (typeof getConfig === "function") {
	var cfgH = parseInt(getConfig("flat_height", "64"), 10);
	if (!isNaN(cfgH) && cfgH >= 8 && cfgH <= 120) FLAT_HEIGHT = cfgH;
}

if (HAS_DIM_API) {
	Dimension.define(FLAT_DIM, {
		name: "Superflat",
		clouds: true,
		blocks: { grass: GRASS, dirt: DIRT, stone: STONE },
		// 超平坦 = 高度常量。引擎铺法：y == h 是草，下面 4 格泥土，再往下石头到底 + 基岩。
		getHeight: function (x, z) { return FLAT_HEIGHT; }
	});
	log("维度已注册：编号 " + FLAT_DIM + " 地面高度 " + FLAT_HEIGHT);
} else {
	log("引擎里没有 Dimension.define —— 这个模组需要新版引擎");
}

// 找一列的地面（回主世界时用；顺带会触发那一列所在区块生成）
function findGround(x, z) {
	for (var y = 126; y > 2; y--) {
		var b = level.getBlock(x, y, z);
		if (b !== 0 && b !== 10 && b !== 11) return y;   // 非空气、非岩浆
	}
	return 64;
}

function travel(dim, x, y, z, msg) {
	if (typeof level.changePlayerDimension !== "function")
		return reply(C_ERR + "引擎没有 level.changePlayerDimension");
	level.changePlayerDimension(0, dim, x, y, z);   // 0 = 本机玩家（单机/房主/服务器都走这条）
	return reply(C_OK + msg);
}

function cmdFlat(args) {
	var parts = trim(args).toLowerCase().split(/\s+/);
	var sub = parts[0] || "";

	if (sub === "info") {
		return reply(C_INFO + "维度编号 " + C_HI + FLAT_DIM + C_INFO + " | 地面高度 " + C_HI + FLAT_HEIGHT +
			C_DIM + " | 方块 草" + GRASS + "/泥土" + DIRT + "/石" + STONE +
			C_DIM + " | 用法：/flat | /flat back | /flat height <8~120>");
	}
	if (sub === "height") {
		var n = parseInt(parts[1], 10);
		if (isNaN(n) || n < 8 || n > 120) return reply(C_ERR + "用法：/flat height <8~120>");
		FLAT_HEIGHT = n;
		if (typeof setConfig === "function") setConfig("flat_height", String(n));
		return reply(C_OK + "地面高度已设为 " + n + C_DIM + "（只对还没生成过的区块生效 —— 往没走过的地方走）");
	}
	if (sub === "back") {
		var gy = findGround(0, 0);   // 主世界出生点附近
		return travel(0, 0.5, gy + 1.2, 0.5, "正在回主世界…");
	}
	if (!HAS_DIM_API) return reply(C_ERR + "引擎里没有 Dimension.define");
	// 默认：进超平坦（落点固定在 0,0 —— 平坦地形哪儿都一样）
	return travel(FLAT_DIM, 0.5, FLAT_HEIGHT + 3, 0.5, "正在进入超平坦世界…");
}

if (typeof Commands !== "undefined" && Commands && typeof Commands.register === "function") {
	Commands.register("flat", function (sender, args) { return cmdFlat(trim(args)); },
		"超平坦维度：/flat | back | height <n> | info");
}

// name: obj 模型演示
// author: engine self-test
// version: 1.1.0
//
// 三个演示：obj 物品 / obj 方块 / obj + 骨骼动画（转起来）

// ---------- ① obj 物品（独立大贴图 modelTexture）----------
var PYRAMID = Item.defineItem(220, {
    name: "Obj 金字塔",
    model: [ { mesh: "models/pyramid.obj" } ],   // obj 的 o/g 分组 = 部件，组名 = 骨骼名
    modelTexture: "models/pyramid.png"
});
modLog("obj 物品已注册，号 = " + PYRAMID);

// ---------- ② obj 物品 + 骨骼动画（绕 y 轴自转）----------
// 组名 pyramid 自动绑到同名骨骼；anim 返回 {x,y,z}（**弧度**，不是 {rot:[...]}）
var SPIN = Item.defineItem(221, {
    name: "Obj 旋转金字塔",
    model: [ { mesh: "models/pyramid.obj" } ],
    modelTexture: "models/pyramid.png",
    bones: [ { name: "pyramid", pivot: [8, 8, 8] } ],   // pivot 单位 = 像素（16 = 1 格）
    anim: function (part, age, time) {
        if (part === "pyramid") return { x: 0, y: time * 1.5, z: 0 };
        return null;
    }
});
modLog("obj 动画物品已注册，号 = " + SPIN);

// ---------- ③ obj 方块（贴图走 terrain 图集，按 16x16 画）----------
var OBJCUBE = Block.defineBlock(230, {
    name: "Obj 方块",
    model: [ { mesh: "models/objcube.obj" } ],
    texture: "blocks/objcube.png",
    material: "stone"
});
modLog("obj 方块已注册，号 = " + OBJCUBE);

// ---------- ④ obj 方块 + 动画（每帧重画）----------
var OBJCUBE2 = Block.defineBlock(231, {
    name: "Obj 旋转方块",
    model: [ { mesh: "models/objcube.obj" } ],
    texture: "blocks/objcube.png",
    material: "stone",
    anim: function (part, age, time) {
        // 方块动画：同样是 {x,y,z} 弧度
        return { x: 0, y: time * 1.2, z: 0 };
    }
});
modLog("obj 动画方块已注册，号 = " + OBJCUBE2);

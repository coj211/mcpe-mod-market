// name: 末影龙
// author: engine
// version: 1.0.0
//
// 模型 / 动画全部来自文件，这里只写引用：
//   mesh:      "models/dragon.obj"   几何，obj 的 o/g 分组名 = 骨骼名
//   animation: "models/dragon.json"  骨骼层级(pivot/parent) + 关键帧，可加 #片段名
//
// 换模型只改这两行；AI 用 onMobTick 之类另写。

var DRAGON_ID = 60;

Mob.defineMob(DRAGON_ID, {
    name: "末影龙",
    texture: "mob/dragon.png",
    texSize: [64, 64],
    health: 200,
    size: [4.0, 3.0],
    scale: 1.0,
    hostile: false,
    mesh: "models/dragon.obj",
    animation: "models/dragon.json#fly"
});

modLog("末影龙已注册，id = " + DRAGON_ID);

// ---- 指令：/dragon [数量] ----
Commands.register("dragon", function (sender, args) {
    var n = parseInt(args, 10);
    if (!n || n < 1) n = 1;
    if (n > 10) n = 10;

    var px = player.getX(), py = player.getY(), pz = player.getZ();
    for (var i = 0; i < n; i++) {
        var ang = i * Math.PI * 2 / n;
        level.spawnMob(DRAGON_ID, px + Math.sin(ang) * 5, py + 4, pz + Math.cos(ang) * 5);
    }
    return "召唤了 " + n + " 只末影龙";
}, "召唤末影龙（/dragon [数量]，1~10，默认 1）");

// ---- 指令：/dragonclear ----
Commands.register("dragonclear", function (sender, args) {
    return "用法：毁掉附近的末影龙请用 /kill（引擎自带）";
}, "末影龙说明（清除请用 /kill）");

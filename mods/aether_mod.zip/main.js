// name: 天境
// author: coj2
// version: 3.1.0
// description: 天境 v3.1 —— 柏林噪声浮空大陆 + 装饰 + 进入加载页（分帧预生成防卡顿）+ 云弹性（白云轻弹/蓝云高弹）

// ============================================================
//  常量
// ============================================================
var AETHER_DIM   = 20;
var GLOWSTONE    = 89;
var WATER        = 8;
var CALM_WATER   = 9;
var AIR          = 0;

var PORTAL_BLOCK = 130;   // 传送门
var CLOUD_BLOCK  = 131;   // 白云
var GRASS_A      = 132;   // 天境草
var DIRT_A       = 133;   // 天境土
var STONE_A      = 134;   // 圣石 holystone
var LOG_A        = 135;   // 天境原木
var LEAF_A       = 136;   // 天境叶
var BLUE_CLOUD   = 137;   // 蓝云
var ICE_STONE    = 138;   // 冰石
var QUICKSOIL    = 139;   // 流沙
var GOLD_CLOUD   = 140;   // 金云
var PINK_CLOUD   = 141;   // 粉云
var BERRY_BUSH   = 142;   // 蓝莓灌木
var ORE_AMBRO    = 143;   // ambrosium 矿
var ORE_ZANITE   = 144;   // zanite 矿
var ORE_GRAVIT   = 145;   // gravitite 矿
var FLOWER_W     = 146;   // 白花
var FLOWER_P     = 147;   // 紫花

// ============================================================
//  方块定义
// ============================================================
// 矿石贴图优先注入（terrain 图集槽位 255 递减，先定义的拿高槽位，避免被后续方块挤成 tex=1）
ORE_AMBRO = Block.defineBlock(ORE_AMBRO,    { name: "天境矿石", texture: "blocks/ambrosium_ore.png", destroyTime: 3, requiresPickaxe: true });
ORE_ZANITE = Block.defineBlock(ORE_ZANITE,   { name: "紫晶矿",   texture: "blocks/zanite_ore.png", destroyTime: 3.5, requiresPickaxe: true });
ORE_GRAVIT = Block.defineBlock(ORE_GRAVIT,   { name: "重力矿",   texture: "blocks/gravitite_ore.png", destroyTime: 4, requiresPickaxe: true });
// 重力矿上浮用的"方块生物"：一个 1x1x1 方块模型，贴重力矿纹理。
// 生物不被玩家捡走、不自动消失，mob.setPos 可精确控制上浮。
var GRAVIT_MOB = 40;
Mob.defineMob(GRAVIT_MOB, {
	name: "重力矿",
	texture: "blocks/gravitite_ore.png",
	health: 1,
	size: [1.0, 1.0],
	texSize: [16, 16],
	model: [ { name: "ore", tex: [0, 0], box: [-8, -8, -8, 16, 16, 16], pos: [0, 0, 0] } ]
});

// ============================================================
//  Boss：太阳之灵（Sun Spirit，还原自原版 Aether）
//  地牢飞行 boss：固定矩形内往返 + 自转 + 玩家靠近召唤火傀儡
//  还原原版：originPoint 固定原点、rotary 自转（血量越低越快）、
//  召唤火傀儡、Boss 血条 HUD
// ============================================================
var SUNSPIRIT_MOB = 41;
Mob.defineMob(SUNSPIRIT_MOB, {
	name: "太阳之灵",
	texture: "bosses/sun_spirit.png",
	health: 70,
	size: [2.0, 2.0],       // 原版 width=height=2
	scale: 2.5,              // 整体放大（原版模型仅 ~1.25 格，放大后更有 Boss 威严）
	hostile: false,          // 关闭引擎怪物 AI：巡逻/火球/伤害全由 JS 控制
	texSize: [64, 32],
	// 原版 SunSpiritModel（ModelBiped 子类）逐部件还原，贴图 64x32 布局
	// 1:1 对应：tex=贴图原点，box=addBox(相对原点偏移+尺寸)，pos=setRotationPoint
	model: [
		{ name: "head",  tex: [0, 0],   box: [-4, -8, -3, 8, 5, 7],       pos: [0, 0, 0] },
		{ name: "body",  tex: [32, 0],  box: [-4, -3, -4, 8, 3, 8],       pos: [0, 0, 0] },
		{ name: "armR",  tex: [0, 12],  box: [-5, 0, -2.5, 10, 6, 5],     pos: [0, 0, 0] },
		{ name: "body2", tex: [0, 23],  box: [-4.5, 6, -2, 9, 5, 4],      pos: [0, 0, 0] },
		{ name: "body3", tex: [30, 27], box: [-4.5, 11, -2, 5, 1, 4],     pos: [0, 0, 0] },
		{ name: "body4", tex: [30, 27], box: [-0.5, 11, -2, 5, 1, 4],     pos: [0, 0, 0] },
		{ name: "armL",  tex: [30, 11], box: [-2.5, -2.5, -2.5, 5, 5, 5], pos: [-8, 0, 0] },
		{ name: "armR2", tex: [30, 11], box: [-2.5, 2.5, -2.5, 5, 10, 5], pos: [-8, 0, 0] },
		{ name: "armR3", tex: [30, 26], box: [-2.5, 7.5, -2.5, 5, 1, 5],  pos: [-8, 0, 0] },
		{ name: "legR",  tex: [30, 11], box: [-2.5, -2.5, -2.5, 5, 5, 5], pos: [-8, 0, 0] },
		{ name: "armL2", tex: [30, 11], box: [-2.5, 2.5, -2.5, 5, 10, 5], pos: [8, 0, 0] },
		{ name: "armL3", tex: [30, 26], box: [-2.5, 7.5, -2.5, 5, 1, 5],  pos: [8, 0, 0] }
	],
	anim: function(part, age, limb, limbAmount) {
		// 自转：rotary 由 onMobTick 驱动（血量越低越快）；两侧柱反向慢转
		if (part == "head") return { x: 0, y: _sunRotary, z: 0 };
		if (part == "armR" || part == "armL" || part == "armR2" || part == "armL2"
		 || part == "armR3" || part == "armL3") return { x: 0, y: -_sunRotary * 0.5, z: 0 };
		return null;
	}
});
// 火球（原版 Aether EntityCrystal-FIRE，贴图 entities/crystals/fire.png）：
// Boss 每 60 tick 朝玩家射一颗；玩家攻击会把它弹回 Boss（原版机制）。
var FIREBALL_MOB = 42;
Mob.defineMob(FIREBALL_MOB, {
	name: "火球",
	texture: "bosses/fireball.png",
	health: 999,             // 打不死的飞行物：玩家攻击弹回而非击杀
	size: [1.0, 1.0],
	hostile: false,          // 关闭引擎怪物 AI：飞行/命中全由 JS 控制
	texSize: [64, 32],
	model: [
		{ name: "core", tex: [0, 0], box: [-6, -6, -6, 12, 12, 12], pos: [0, 0, 0] }
	],
	anim: function(part, age, limb, limbAmount) { return null; }
});
// Sun Spirit 状态：正在战斗的 boss 实体 id、固定原点、旋转角、召唤冷却
var _sunBossId = -1;
var _sunOriginX = 0, _sunOriginY = 0, _sunOriginZ = 0;
var _sunRotary = 0;
var _sunSummonTick = 0;   // 召唤火傀儡冷却
var SUNSPIRIT_HP = 70;
var SUNSPIRIT_SUMMON_CD = 80;   // 召唤间隔（tick）
var _lastSunHpLog = 0;          // 调试：Boss 血量定期日志（排查莫名死亡）
var _sunBossHp = 0;             // JS 托管血量：Boss 只接受反弹火球伤害（见 onMobTick）
var _sunMinions = [];           // 场上火傀儡（原版僵尸）eid，最多 4 只
// 太阳之灵火球（原版 EntityCrystal-FIRE）：Boss 定时发射，玩家可打回去
var _fireballs = [];      // [{eid, vx, vy, vz, fromBoss, age}]
var _sunFireCd = 0;       // 火球发射冷却（tick）
var FIREBALL_SPEED = 0.45; // 飞行速度（格/tick，放慢便于玩家瞄准反弹）
var FIREBALL_DMG = 4;     // 命中玩家伤害
var FIREBALL_BDMG = 8;    // 打回命中 Boss 伤害
PORTAL_BLOCK = Block.defineBlock(PORTAL_BLOCK, { name: "天境传送门", texture: "blocks/aether_portal.png", material: "plant", transparent: true });
CLOUD_BLOCK = Block.defineBlock(CLOUD_BLOCK,  { name: "天境云",   texture: "blocks/aercloud.png", material: "stone", transparent: true });
GRASS_A = Block.defineBlock(GRASS_A,      { name: "天境草",   texture: "blocks/aether_grass_side.png", topTexture: "blocks/aether_grass_top.png", sideTexture: "blocks/aether_grass_side.png", bottomTexture: "blocks/aether_dirt.png" });
DIRT_A = Block.defineBlock(DIRT_A,       { name: "天境土",   texture: "blocks/aether_dirt.png" });
STONE_A = Block.defineBlock(STONE_A,      { name: "圣石",     texture: "blocks/holystone.png" });
LOG_A = Block.defineBlock(LOG_A,        { name: "天境原木", texture: "blocks/skyroot_log_side.png" });
LEAF_A = Block.defineBlock(LEAF_A,       { name: "天境叶",   texture: "blocks/skyroot_leaves.png", renderLayer: "alphatest" });
BLUE_CLOUD = Block.defineBlock(BLUE_CLOUD,   { name: "蓝云",     texture: "blocks/blue_aercloud.png", material: "stone", transparent: true });
ICE_STONE = Block.defineBlock(ICE_STONE,    { name: "冰石",     texture: "blocks/icestone.png" });
QUICKSOIL = Block.defineBlock(QUICKSOIL,    { name: "流沙",     texture: "blocks/quicksoil.png", material: "sand" });
GOLD_CLOUD = Block.defineBlock(GOLD_CLOUD,   { name: "金云",     texture: "blocks/golden_aercloud.png", material: "stone", transparent: true });
PINK_CLOUD = Block.defineBlock(PINK_CLOUD,   { name: "粉云",     texture: "blocks/pink_aercloud.png", material: "stone", transparent: true });
BERRY_BUSH = Block.defineBlock(BERRY_BUSH,   { name: "蓝莓灌木", texture: "blocks/berry_bush.png", material: "plant", renderLayer: "alphatest", shape: "cross" });
FLOWER_W = Block.defineBlock(FLOWER_W,     { name: "白花",     texture: "blocks/white_flower.png", material: "plant", renderLayer: "alphatest", shape: "cross" });
FLOWER_P = Block.defineBlock(FLOWER_P,     { name: "紫花",     texture: "blocks/purple_flower.png", material: "plant", renderLayer: "alphatest", shape: "cross" });
// 太阳之灵竞技场（原版金地牢：地狱火石封闭地牢 + 圣石地面 + 太阳祭坛）
var SUN_ALTAR      = 148;   // 太阳祭坛（原版 BlockSunAltar）
var HELLFIRE       = 149;   // 地狱火石（原版 locked_hellfire_stone，橙红墙）
var HELLFIRE_LIGHT = 150;   // 发光地狱火石（原版 locked_light_hellfire_stone）
SUN_ALTAR = Block.defineBlock(SUN_ALTAR,      { name: "太阳祭坛", texture: "blocks/sun_altar_side.png", topTexture: "blocks/sun_altar_top.png", material: "stone" });
HELLFIRE = Block.defineBlock(HELLFIRE,       { name: "地狱火石", texture: "blocks/hellfire_stone.png", material: "stone" });
HELLFIRE_LIGHT = Block.defineBlock(HELLFIRE_LIGHT, { name: "发光地狱火石", texture: "blocks/light_hellfire_stone.png", material: "stone" });

// ============================================================
//  天境工具/武器（钻石级）+ 合成配方
// ============================================================
Item.defineItem(210, { name: "天境剑", icon: [3, 4], type: "weapon", tier: "emerald" });
Item.defineItem(211, { name: "天境镐", icon: [3, 6], type: "pickaxe", tier: "emerald" });
Item.defineItem(212, { name: "天境斧", icon: [3, 7], type: "axe", tier: "emerald" });
Item.defineItem(213, { name: "天境铲", icon: [3, 5], type: "shovel", tier: "emerald" });

// 合成：矿石 + 天境原木（木棍替代）
Recipes.addShapedRecipe(210, 1, ["Z", "Z", "L"], { Z: ORE_ZANITE, L: LOG_A });   // 天境剑
Recipes.addShapedRecipe(211, 1, ["ZZZ", " L ", " L "], { Z: ORE_ZANITE, L: LOG_A }); // 天境镐
Recipes.addShapedRecipe(212, 1, ["ZZ ", "ZL ", " L "], { Z: ORE_ZANITE, L: LOG_A }); // 天境斧
Recipes.addShapedRecipe(213, 1, ["Z  ", "L  ", "L  "], { Z: ORE_ZANITE, L: LOG_A }); // 天境铲

// ============================================================
//  噪声（确定性，跨区块一致）
// ============================================================
function hash2(x, z) {
	var n = (x * 374761393 + z * 668265263) | 0;
	n = (n ^ (n >> 13)) | 0;
	n = (n * 1274126177) | 0;
	return ((n ^ (n >> 16)) & 0x7fffffff) / 0x7fffffff;
}
function smoothstep(t) { return t * t * (3 - 2 * t); }
function noise2(x, z) {
	var ix = Math.floor(x), iz = Math.floor(z);
	var fx = x - ix, fz = z - iz;
	var sx = smoothstep(fx), sz = smoothstep(fz);
	var a = hash2(ix, iz),     b = hash2(ix + 1, iz);
	var c = hash2(ix, iz + 1), d = hash2(ix + 1, iz + 1);
	return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz;
}
function fbm2(x, z) {
	return noise2(x, z) * 0.5 + noise2(x * 2.13, z * 2.13) * 0.3 + noise2(x * 4.71, z * 4.71) * 0.2;
}

// ---- 天境地形（移植原版 ChunkProviderAether 密度场）：----
// 原版 density = 3D噪声 - 8（几乎全负），只有强凸起处 >0 成岛
// → 稀疏的独立浮空岛（宽 20~45 格），不是连片大陆，没有整片云海
// 垂直分层：超低频场把空间分成低/中/高三层，不同区域的岛落在不同海拔
// → 岛屿垂直散开（头顶/脚下都可能撞到别的岛），不再是单层平面。
// 同一 (x,z) 列可同时存在多层岛（低/中/高各查一次密度场），引擎单柱
// 模型只生成最高层，其余层由 onChunkGenerate 的 genAetherExtra 补出。
function aetherLayerTop(x, z, base) {
	var n = fbm2(x * 0.045 + 1000.0, z * 0.045 + 2000.0);
	if (n < 0.585) return 0;
	var h = base + (n - 0.585) * 46;
	if (h > 126) h = 126;
	return h;
}
function aetherLayerBottom(x, z, base) {
	var h = aetherLayerTop(x, z, base);
	if (h <= 0) return 0;
	var n = fbm2(x * 0.045 + 1000.0, z * 0.045 + 2000.0);
	var thick = 3 + (n - 0.585) * 26;   // 3~12 块
	return h - Math.floor(thick);
}
// 该列的岛层判定：低/中/高三层各自独立概率（不互斥）→ 同一列可同时
// 有低层+中层+高层岛，垂直错落；引擎单柱生成最高层，其余由
// genAetherExtra 补出（否则重叠列的下层会"消失"）。
function aetherLayerBase(x, z, which) {
	if (which == 0) {
		// 低层：独立阈值场，~30% 区域
		return fbm2(x * 0.012 + 300.0, z * 0.012 + 400.0) < 0.3 ? 58 : 0;
	}
	if (which == 1) {
		// 中层：独立阈值场，~30% 区域
		return fbm2(x * 0.014 + 900.0, z * 0.014 + 1100.0) < 0.3 ? 84 : 0;
	}
	if (which == 2) {
		// 高层岛：独立阈值场，~30% 区域；base 100 → 岛顶最高 ~110，
		// 保证金橡树（树冠到 top+11 ≤121 < 世界高度 126）永不截断
		return fbm2(x * 0.016 + 1500.0, z * 0.016 + 1800.0) < 0.3 ? 100 : 0;
	}
	return 0;
}
// 主柱高度 = 该列所有层里最高的岛顶（引擎据此生成主体）
// 缓存：同一 (x,z) 在区块生成期被 getAetherHeight 调用多次（引擎主柱、
// genSurface 每列、genOres 检查），缓存避免重复算 fbm2（区块生成卡顿元凶）。
var _heightCache = {};
var _heightCacheSize = 0;
var _heightCacheMax = 4096;
function getAetherHeight(x, z) {
	var key = x + "," + z;
	if (_heightCache[key] !== undefined) return _heightCache[key];
	var best = 0;
	for (var w = 0; w < 3; w++) {
		var base = aetherLayerBase(x, z, w);
		if (base <= 0) continue;
		var h = aetherLayerTop(x, z, base);
		if (h > best) best = h;
	}
	if (_heightCacheSize < _heightCacheMax) {
		_heightCache[key] = best;
		_heightCacheSize++;
	}
	return best;
}
// 主柱底部：最高层的底（引擎单柱，这里只服务主柱）
function getAetherBottom(x, z) {
	var h = getAetherHeight(x, z);
	if (h <= 0) return 0;
	// 找最高层对应的底
	var bestBase = 0;
	for (var w = 0; w < 3; w++) {
		var base = aetherLayerBase(x, z, w);
		if (base <= 0) continue;
		if (aetherLayerTop(x, z, base) == h) { bestBase = base; break; }
	}
	if (bestBase <= 0) return h - 8;
	return aetherLayerBottom(x, z, bestBase);
}
// 区块生成时补齐非最高层岛（引擎单柱不画的层）：草/土/石分层同主柱。
// 性能：每列只算一次 n（fbm2 固定频率）和每层的层判定场，避免重复调用
// aetherLayerTop/Bottom 里各自的 fbm2。
function genAetherExtra(setBlock, seedX, seedZ) {
	for (var lx = 0; lx < 16; lx++)
		for (var lz = 0; lz < 16; lz++) {
			var wx = seedX + lx, wz = seedZ + lz;
			// 一次算密度场 n（所有层共用同一高频场 → 同列各层形状一致）
			var n = fbm2(wx * 0.045 + 1000.0, wz * 0.045 + 2000.0);
			if (n < 0.585) continue;              // 该列无任何层
			var main = 0;
			// 先算各层顶，找最高层（引擎主柱）
			var tops = [0, 0, 0], bases = [0, 0, 0];
			for (var w = 0; w < 3; w++) {
				var base = aetherLayerBase(wx, wz, w);
				bases[w] = base;
				if (base <= 0) continue;
				var h = base + (n - 0.585) * 46;
				if (h > 126) h = 126;
				tops[w] = h;
				if (h > main) main = h;
			}
			if (main <= 0) continue;
			for (var w = 0; w < 3; w++) {
				if (bases[w] <= 0) continue;
				if (tops[w] == main) continue;    // 主柱引擎已生成，跳过
				var thick = 3 + (n - 0.585) * 26;
				var bot = tops[w] - Math.floor(thick);
				for (var y = bot; y <= tops[w]; y++) {
					var id = (y == tops[w]) ? GRASS_A : (y >= tops[w] - 3 ? DIRT_A : STONE_A);
					sb(setBlock, seedX, seedZ, wx, y, wz, id);
				}
			}
		}
}

// 区块内 setBlock（只画落在当前区块的部分）
function sb(setBlock, seedX, seedZ, wx, y, wz, id) {
	if (wx < seedX || wx >= seedX + 16 || wz < seedZ || wz >= seedZ + 16) return;
	if (y < 1 || y > 126) return;
	setBlock(wx - seedX, y, wz - seedZ, id);
}

// ============================================================
//  维度
// ============================================================
Dimension.define(AETHER_DIM, {
	name: "天境",
	clouds: false,
	// 风格一体化：大陆和小岛都用天境方块
	blocks: { grass: GRASS_A, dirt: DIRT_A, stone: STONE_A },
	getHeight: getAetherHeight,
	getBottom: getAetherBottom,
	onChunkGenerate: function(cx, cz, setBlock) {
		var seedX = cx * 16, seedZ = cz * 16;
		// ---- 补齐同列的下层岛（引擎单柱只生成最高层）----
		genAetherExtra(setBlock, seedX, seedZ);
		// ---- 矿石矿脉（列内嵌矿）----
		genOres(setBlock, seedX, seedZ, cx, cz);
		// ---- 装饰：大陆表面树/花/灌木 ----
		genSurface(setBlock, seedX, seedZ);
		// ---- 4 色云团 ----
		genClouds(setBlock, seedX, seedZ, cx, cz);
		// ---- 银地牢（低频）----
		if (hash2(cx * 17 + 3, cz * 29 + 11) < 0.02) {
			var dx = 4 + Math.floor(hash2(cx * 7, cz * 13) * 8);
			var dz = 4 + Math.floor(hash2(cx * 19, cz * 5) * 8);
			var top = getAetherHeight(cx * 16 + dx, cz * 16 + dz);
			if (top > 0)
				genSilverDungeon(setBlock, seedX, seedZ, cx * 16 + dx, top + 1, cz * 16 + dz);
		}
		// ---- 流沙区（大陆表面）----
		if (hash2(cx * 5 + 1, cz * 3 + 7) < 0.03) {
			var dx = 6 + Math.floor(hash2(cx * 9, cz * 15) * 4);
			var dz = 6 + Math.floor(hash2(cx * 21, cz * 7) * 4);
			var top = getAetherHeight(cx * 16 + dx, cz * 16 + dz);
			if (top > 0)
				genQuicksoil(setBlock, seedX, seedZ, cx * 16 + dx, top, cz * 16 + dz);
		}
	}
});

// ---- 矿石矿脉：列内嵌矿（ambrosium 常见 / zanite / 冰石 / gravitite 稀有）----
// 矿石生成规则（用户要求）：
//   1. 矿块 6 邻中至少 5 面是任何方块（石头/土/矿/草都算，不裸露）
//   2. 一条矿脉 1~8 块
//   3. 一个区块最多 2 条矿脉（可同种可异种）
// 注意：生成期不能查 level.getBlock（会递归触发生成），用 getAetherHeight/
// getAetherBottom 纯函数推导地形范围。
function isSolidAt(wx, y, wz) {
	var top = getAetherHeight(wx, wz);
	if (top <= 0) return false;
	var bottom = getAetherBottom(wx, wz);
	return y >= bottom && y <= top;   // 地形范围内任何方块（石头层+土+草）都算
}

// ============================================================
//  矿石（一比一移植原版 AetherGenMinable + AetherBiomeDecorator）
//  原版 spawnOre(block, chance, count, yMax)：
//    每区块尝试 yMax 次，每次在区块内随机位置 (x=rand16, y=rand(yMax), z=rand16)
//    生成 count 块大小的椭球矿脉（AetherGenMinable），只替换 holystone(圣石)
//  参数（AetherBiomeDecorator 反编译）：
//    icestone     chance=16  count=10  yMax=128
//    ambrosium    chance=16  count=15  yMax=128
//    zanite       chance=8   count=12  yMax=64
//    gravitite    chance=6   count=8   yMax=32
//  原版每矿还有 shouldSpawn(chance) 整组概率（chance 是 1/N）；
//  这里每区块先按 1/chance 决定该矿本区块是否生成，再 yMax 次尝试。
// ============================================================
var ORES_TABLE = [
	{ id: ICE_STONE,  chance: 16, count: 10, yMax: 128, topBias: 0.3 },  // 全深度偏下
	{ id: ORE_AMBRO,  chance: 16, count: 15, yMax: 128, topBias: 0.4 },  // 全深度
	{ id: ORE_ZANITE, chance: 8,  count: 12, yMax: 64,  topBias: 0.6 },  // 中浅层
	{ id: ORE_GRAVIT, chance: 6,  count: 8,  yMax: 32,  topBias: 0.85 }  // 浅层（原版 y0~32 接近地表）
];

function genOres(setBlock, seedX, seedZ, cx, cz) {
	for (var m = 0; m < ORES_TABLE.length; m++) {
		var ore = ORES_TABLE[m];
		// 原版 shouldSpawn(1/chance)：整组概率
		if (hash2(cx * 97 + m * 131, cz * 103 + m * 47) > 1.0 / ore.chance) continue;
		// 尝试次数：原版 yMax 次尝试太重（每区块可能 128 条脉 → 卡死）。
		// 用 count 决定尝试次数（矿大少试，矿小多试），每区块最多 ~10 条。
		var tries = 4 + Math.floor(ore.count / 4);
		if (tries > 10) tries = 10;
		// 矿脉中心 y：落在区块中心列的岛圣石带内（bottom+2 ~ top-6）。
		// 原版 yMax 是相对世界高度（有地表石头层），天境是浮空岛，石头只在
		// 岛上——直接 rand(yMax) 大多落在岛外虚空 → 矿全被滤掉。
		var topC = getAetherHeight(seedX + 8, seedZ + 8);
		if (topC <= 0) continue;   // 区块中心无岛 → 本区块不放矿
		var botC = getAetherBottom(seedX + 8, seedZ + 8);
		var band = topC - botC - 8;
		if (band < 4) band = 4;
		for (var t = 0; t < tries; t++) {
			var lx = Math.floor(hash2(cx * 7 + m * 13 + t * 3, cz * 5) * 16);
			var lz = Math.floor(hash2(cx * 3, cz * 7 + m * 17 + t * 5) * 16);
			// 深度按 topBias 分布：bias 越高越靠岛体上部（浅层矿如重力矿），
			// 对应原版 yMax 的相对深度语义。
			var frac = ore.topBias + (1 - ore.topBias) * hash2(cx * 11 + t * 7, cz * 13 + m * 23);
			if (frac > 1) frac = 1;
			var ly = botC + 2 + Math.floor(band * frac);
			genVein(setBlock, seedX, seedZ, ore.id, ore.count, seedX + lx, ly, seedZ + lz, cx, cz, m * 31 + t);
		}
	}
	// ---- 重力矿（特殊规则）：每 4~5 个岛一个矿脉，生成在岛体下方悬空 ----
	// 重力矿后面要加特性（反重力等），所以做成稀有 + 挂岛底的特殊形态。
	var gtop = getAetherHeight(seedX + 8, seedZ + 8);
	if (gtop <= 0) return;   // 区块中心无岛 → 无重力矿
	var gbot = getAetherBottom(seedX + 8, seedZ + 8);
	// 每 4~5 个岛一个：hash 对 4 取模命中（0、1、2、3 = 平均 4 岛一个，
	// 再按 hash 细化到 5：~20% 的区块延长到 5 岛一个）
	var roll = hash2(cx * 131 + 77, cz * 149 + 23);
	var step = roll < 0.5 ? 4 : 5;      // 一半区块 4 岛一脉，一半 5 岛一脉
	if (Math.floor(roll * 100) % step != 0) return;
	// 矿脉中心：岛底下方悬空（bottom-3 ~ bottom+2），像挂在岛底的矿簇
	var gy = gbot - 3 + Math.floor(hash2(cx * 37 + 11, cz * 43 + 7) * 5);
	if (gy < 30) gy = 30;   // 别太低（防掉出世界）
	var glx = 4 + Math.floor(hash2(cx * 17, cz * 23) * 8);   // 区块中央附近
	var glz = 4 + Math.floor(hash2(cx * 29, cz * 31) * 8);
	genVein(setBlock, seedX, seedZ, ORE_GRAVIT, 8, seedX + glx, gy, seedZ + glz, cx, cz, 999, true);
}

// 原版 AetherGenMinable：线性插值两端点 + 正弦包络半径 + 归一化椭球，
// 只替换 holystone（圣石 134）。hangBelow=true 时允许岛底下方悬空放矿
// （重力矿挂在岛底）。
function genVein(setBlock, seedX, seedZ, ore, size, bx, by, bz, cx, cz, seedOff, hangBelow) {
	// 随机角度 theta（决定矿脉走向）
	var theta = hash2(cx * 19 + seedOff, cz * 29) * 3.1415927;
	// 两端点（区块中心 ± 正弦偏移）
	var dx = Math.sin(theta) * size / 8.0, dz = Math.cos(theta) * size / 8.0;
	var ax = bx + dx, az = bz + dz;
	var bx2 = bx - dx, bz2 = bz - dz;
	var ay = by + 2 + Math.floor(hash2(seedOff * 3, cz) * 3);
	var by2 = by + 2 + Math.floor(hash2(seedOff, cx * 3) * 3);
	var n = size;
	// 性能：k 步进 2（相邻椭球重叠，形状不变、计算减半）
	for (var k = 0; k <= n; k += 2) {
		// 线性插值当前位置
		var cx2 = ax + (bx2 - ax) * k / n;
		var cy = ay + (by2 - ay) * k / n;
		var cz2 = az + (bz2 - az) * k / n;
		// 半径：正弦包络（中间粗两端细）* 随机
		var r = (1.0 + Math.sin(k * 3.1415927 / n)) * (hash2(k * 7 + seedOff, cx) * n / 16.0) + 1.0;
		// 遍历椭球包围盒
		var x0 = Math.floor(cx2 - r), x1 = Math.floor(cx2 + r);
		var y0 = Math.floor(cy - r), y1 = Math.floor(cy + r);
		var z0 = Math.floor(cz2 - r), z1 = Math.floor(cz2 + r);
		for (var x = x0; x <= x1; x++)
			for (var y = y0; y <= y1; y++)
				for (var z = z0; z <= z1; z++) {
					// 归一化椭球判定
					var nx = (x - cx2) / r, ny = (y - cy) / r, nz = (z - cz2) / r;
					if (nx * nx + ny * ny + nz * nz < 1) {
						// 只替换岛体方块：生成期不能 level.getBlock（会递归
						// 触发生成），用高度函数判断该列 y 是否在岛体内
						// （bottom ~ top，含表层——矿可少量混进土/草，更自然）。
						// hangBelow=true：重力矿——若矿块上方是空气（y<bottom，
						// 悬在岛底下方），就向上移动到岛底 bottom（贴住上方
						// 方块），即"上面没有方块就向上直到有方块"。
						var top = getAetherHeight(x, z);
						if (top <= 0) continue;
						var bottom = getAetherBottom(x, z);
						var yp = y;
						if (hangBelow) {
							if (y > top) continue;
							if (y < bottom) yp = bottom;   // 悬空 → 升到贴岛底
						} else {
							if (y < bottom || y > top) continue;
						}
						sb(setBlock, seedX, seedZ, x, yp, z, ore);
					}
				}
	}
}

// ---- 大陆表面装饰：树/花/灌木（低频、确定性）----
function genSurface(setBlock, seedX, seedZ) {
	for (var lx = 0; lx < 16; lx++) {
		for (var lz = 0; lz < 16; lz++) {
			var wx = seedX + lx, wz = seedZ + lz;
			var top = getAetherHeight(wx, wz);
			if (top <= 0) continue;
			var r = hash2(wx * 7 + 1, wz * 13 + 3);
			if (r > 0.995) {
				// 金橡树（高层岛 base 已降，岛顶 ≤~110，树到 121 < 126 不截断）
				genOakTree(setBlock, seedX, seedZ, wx, top + 1, wz);
			} else if (r > 0.985) {
				// 花/灌木
				var id = hash2(wx, wz * 3) > 0.5 ? FLOWER_W : (hash2(wx * 3, wz) > 0.5 ? FLOWER_P : BERRY_BUSH);
				sb(setBlock, seedX, seedZ, wx, top + 1, wz, id);
			}
		}
	}
}

// ============================================================
//  金橡树（移植 AetherGenOakTree：9 高原木 + 球冠叶）
// ============================================================
function genOakTree(setBlock, seedX, seedZ, tx, baseY, tz) {
	for (var n = 0; n < 9; n++)
		sb(setBlock, seedX, seedZ, tx, baseY + n, tz, LOG_A);
	for (var dx = -3; dx <= 3; dx++) {
		for (var dy = 5; dy < 12; dy++) {
			for (var dz = -3; dz <= 3; dz++) {
				var d2 = dx * dx + (dy - 8) * (dy - 8) + dz * dz;
				if (d2 < 12 + Math.floor(hash2(tx + dx, tz + dz) * 5)) {
					if (dx == 0 && dz == 0 && dy < 9) continue;
					sb(setBlock, seedX, seedZ, tx + dx, baseY + dy, tz + dz, LEAF_A);
				}
			}
		}
	}
}

// ============================================================
//  云（一比一移植原版 AetherGenClouds：曼哈顿距离实心椭球云团）
// ============================================================
function cloudChain(setBlock, seedX, seedZ, bx, by, bz, amount, cid, so, hscale) {
	if (!hscale) hscale = 1;
	var px = bx, py = by, pz = bz;
	for (var a = 0; a < amount; a++) {
		// 原版：xOffset=rand(2), yOffset=50%概率 rand(3)-1, zOffset=rand(2)
		var xo = Math.floor(hash2(a * 11 + so, so * 3) * 2);
		var yo = (hash2(a * 13 + so, so * 5) > 0.5 ? Math.floor(hash2(a * 5 + so, so * 9) * 3) - 1 : 0);
		var zo = Math.floor(hash2(a * 17 + so, so * 7) * 2);
		px += xo; py += yo; pz += zo;
		// 原版盒：rand(2)+3 (3~4) x rand(1)+2 (2~3) x rand(2)+3 (3~4)
		var sx = 3 + Math.floor(hash2(px * 2 + so, a) * 2);
		var sy = 2 + Math.floor(hash2(a + so, py * 3) * 1);
		var sz = 3 + Math.floor(hash2(a, pz * 2 + so) * 2);
		for (var x = px; x < px + sx; x++)
			for (var y = py; y < py + sy; y++)
				for (var z = pz; z < pz + sz; z++) {
					// 原版：曼哈顿距离 |x|+|y|+|z| < 4+rand(2) → 实心椭球（无随机洞）
					var md = Math.abs(x - px) + Math.abs(y - py) + Math.abs(z - pz);
					if (md < 4 + Math.floor(hash2(x * 7 + so, z * 11 + y) * 2))
						sb(setBlock, seedX, seedZ, x, y, z, cid);
				}
	}
}
function genClouds(setBlock, seedX, seedZ, cx, cz) {
	// 一比一原版 AetherBiomeDecorator 云参数：
	//   pink    amount=1,  chance=50(2%),  y=110~173 → clamp ≤118
	//   golden  amount=4,  chance=50(2%),  y=96~159  → clamp ≤112
	//   blue    amount=8,  chance=26(3.8%),y=32~95
	//   cold    amount=16, chance=14(7.1%),y=64~127 → clamp ≤115
	// 世界高度上限 126（引擎），云团垂直约 2~3 格，留余量 clamp。
	// 白云（Cold，原版主云）：7.1% 区块生成 16 朵大云团（区域性，非均匀）
	var r = hash2(cx * 7 + 2, cz * 5 + 1);
	// 白云
	if (r < 1 / 14.0) {
		var by = 64 + Math.floor(hash2(cx * 3, cz * 11) * 51);   // y 64~115
		if (by > 115) by = 115;
		cloudChain(setBlock, seedX, seedZ, seedX, by, seedZ, 16, CLOUD_BLOCK, 1, 1);
	}
	// 蓝云（弹跳）：3.8% 区块，8 朵，y 32~95
	if (r >= 0.15 && r < 0.15 + 1 / 26.0) {
		var by = 32 + Math.floor(hash2(cx * 5, cz * 13) * 63);    // y 32~95
		if (by > 95) by = 95;
		cloudChain(setBlock, seedX, seedZ, seedX, by, seedZ, 8, BLUE_CLOUD, 2, 1);
	}
	// 金云：2% 区块，4 朵，y 96~112
	if (r >= 0.925) {
		var by = 96 + Math.floor(hash2(cx * 7, cz * 7) * 16);     // y 96~112
		if (by > 112) by = 112;
		cloudChain(setBlock, seedX, seedZ, seedX, by, seedZ, 4, GOLD_CLOUD, 3, 1);
	}
	// 粉云：2% 区块，1 朵，y 110~118
	if (r >= 0.7 && r < 0.72) {
		var by = 110 + Math.floor(hash2(cx * 2, cz * 17) * 8);    // y 110~118
		if (by > 118) by = 118;
		cloudChain(setBlock, seedX, seedZ, seedX, by, seedZ, 1, PINK_CLOUD, 4, 1);
	}
}

//  流沙区 / 银地牢
// ============================================================
function genQuicksoil(setBlock, seedX, seedZ, qx, qy, qz) {
	for (var x = qx - 3; x <= qx + 3; x++)
		for (var z = qz - 3; z <= qz + 3; z++) {
			var d2 = (x - qx) * (x - qx) + (z - qz) * (z - qz);
			if (d2 < 12) sb(setBlock, seedX, seedZ, x, qy, z, QUICKSOIL);
		}
}
function genSilverDungeon(setBlock, seedX, seedZ, dx, dy, dz) {
	for (var x = 0; x < 5; x++)
		for (var z = 0; z < 5; z++) {
			sb(setBlock, seedX, seedZ, dx + x, dy, dz + z, STONE_A);
			sb(setBlock, seedX, seedZ, dx + x, dy + 3, dz + z, STONE_A);
		}
	for (var y = 1; y <= 2; y++)
		for (var x = 0; x < 5; x++)
			for (var z = 0; z < 5; z++) {
				var isWall = x == 0 || x == 4 || z == 0 || z == 4;
				if (!isWall) continue;
				if (z == 0 && x >= 1 && x <= 3) continue;  // 入口
				sb(setBlock, seedX, seedZ, dx + x, dy + y, dz + z, STONE_A);
			}
	sb(setBlock, seedX, seedZ, dx + 2, dy, dz - 1, STONE_A);
}

// ============================================================
//  传送
// ============================================================
var _lastPortalCheck = 0;
var _lastFrameScan = 0;
var _musicTimer = 0;
var _musicNames = ["aether1", "aether2", "aether3"];
var _lastMusicIdx = -1;
var _prevDim = -1;
var _lastPosSave = 0;
var _gravitRise = [];   // 上升中的重力矿实体：[{eid, x, z, y}]
var _gravitTick = 0;    // 重力矿扫描节流（曾未声明 -> onTick 每 tick ReferenceError，传送门/音乐全部中断）
var _lastBlueBounce = 0;   // 云弹性：上次弹跳 tick（冷却防抖）
var BLUE_BOUNCE_H = 15;    // 蓝云弹起高度（格，原版 Blue Aercloud 蹦床）
var CLOUD_BOUNCE_H = 8;    // 白云弹起高度（格，轻弹）
var _lastDbg = 0;          // 调试：天境位置日志节流
var _bounce = null;        // 弹跳状态机：{x, z, y, vy, g, t, baseY}，非空=弹跳中
var BOUNCE_G = 0.04;       // 弹跳重力（每 tick 速度变化），越小越平缓
var ENGINE_VT = 3.92;      // 引擎终端下落速度（yd 收敛值，用于补偿物理下拉）

function isPortalFrame(x, y, z) {
	// 门框 4 宽 5 高（下界式）：内部空间 2x3（x..x+1, y..y+2），边框全萤石
	// 日志只打"缺块"诊断（真正需要排查的异常）：缺哪块一目了然；成功/预期
	// 路径（已激活、未倒水）不打，避免站在已激活门旁每 0.5 秒刷屏。
	for (var i = -1; i <= 3; i++) {
		if (level.getBlock(x - 1, y + i, z) != GLOWSTONE) { modLog("[天境] portal: 左柱缺萤石 @" + (x-1) + "," + (y+i) + "," + z + " got=" + level.getBlock(x - 1, y + i, z)); return false; }
		if (level.getBlock(x + 2, y + i, z) != GLOWSTONE) { modLog("[天境] portal: 右柱缺萤石 @" + (x+2) + "," + (y+i) + "," + z + " got=" + level.getBlock(x + 2, y + i, z)); return false; }
	}
	if (level.getBlock(x, y - 1, z) != GLOWSTONE) { modLog("[天境] portal: 底梁缺萤石 @" + x + "," + (y-1) + "," + z + " got=" + level.getBlock(x, y - 1, z)); return false; }
	if (level.getBlock(x + 1, y - 1, z) != GLOWSTONE) { modLog("[天境] portal: 底梁缺萤石 @" + (x+1) + "," + (y-1) + "," + z + " got=" + level.getBlock(x + 1, y - 1, z)); return false; }
	if (level.getBlock(x, y + 3, z) != GLOWSTONE) { modLog("[天境] portal: 顶梁缺萤石 @" + x + "," + (y+3) + "," + z + " got=" + level.getBlock(x, y + 3, z)); return false; }
	if (level.getBlock(x + 1, y + 3, z) != GLOWSTONE) { modLog("[天境] portal: 顶梁缺萤石 @" + (x+1) + "," + (y+3) + "," + z + " got=" + level.getBlock(x + 1, y + 3, z)); return false; }
	// 内部：无萤石；有传送门方块 = 已激活（不再激活）；有水 = 待激活
	var hasWater = false, hasPortal = false;
	for (var iy = 0; iy < 3; iy++)
		for (var ix = 0; ix < 2; ix++) {
			var b = level.getBlock(x + ix, y + iy, z);
			if (b == GLOWSTONE) { modLog("[天境] portal: 内部有萤石 @" + (x+ix) + "," + (y+iy) + "," + z); return false; }
			if (b == WATER || b == CALM_WATER) hasWater = true;
			if (b == PORTAL_BLOCK) hasPortal = true;
		}
	if (hasPortal && !hasWater) return false;   // 已激活：跳过
	if (!hasWater && !hasPortal) return false;  // 未倒水：预期状态，跳过
	return true;
}
function activatePortal(x, y, z) {
	modLog("[天境] activatePortal @" + x + "," + y + "," + z);
	for (var iy = 0; iy < 3; iy++)
		for (var ix = 0; ix < 2; ix++)
			level.setBlock(x + ix, y + iy, z, PORTAL_BLOCK);
	level.playSound("random.explode", x + 1, y, z, 1.0, 1.2);
}
function scanForPortal() {
	var px = Math.floor(player.getX());
	var py = Math.floor(player.getY());
	var pz = Math.floor(player.getZ());
	// 性能优化：只在玩家 2 格内扫（5x5x5=125 点），且先快速预筛——左柱
	// 顶/底必须是萤石才可能成门，避免对每个点全量 isPortalFrame（原来
	// 7x7x7=448 点 × 每点 ~20 次 getBlock，主世界每 0.4 秒 ~9000 次调用，
	// 是主世界卡顿元凶）。频率也从 8 tick 降到 40 tick（见 onTick）。
	for (var dx = -2; dx <= 2; dx++)
		for (var dz = -2; dz <= 2; dz++)
			for (var dy = -2; dy <= 2; dy++) {
				var x = px + dx, y = py + dy, z = pz + dz;
				if (y < 1 || y > 120) continue;
				// 快速预筛：左上柱顶(x-1,y+3) 与左下柱底(x-1,y-1) 是萤石才查
				if (level.getBlock(x - 1, y - 1, z) != GLOWSTONE) continue;
				if (level.getBlock(x - 1, y + 3, z) != GLOWSTONE) continue;
				if (isPortalFrame(x, y, z)) { activatePortal(x, y, z); return true; }
			}
	return false;
}
function findLandY(x, z) {
	for (var y = 120; y > 30; y--) {
		var id = level.getBlock(x, y, z);
		if (id != AIR && id != CLOUD_BLOCK && id != BLUE_CLOUD && id != GOLD_CLOUD && id != PINK_CLOUD && id != PORTAL_BLOCK) return y + 1;
	}
	return -1;
}
// 主世界兜底：在目标点周围螺旋扫描最近地表（避免单点落在海洋/虚空导致生成天境欢迎岛）
function findLandYNear(x, z) {
	for (var r = 1; r <= 10; r++) {
		for (var dx = -r; dx <= r; dx++) {
			for (var dz = -r; dz <= r; dz++) {
				if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
				var y = findLandY(x + dx, z + dz);
				if (y > 0) return y;
			}
		}
	}
	return -1;
}
function makeWelcomeIsland(x, z) {
	var top = 92;
	for (var dx = -2; dx <= 2; dx++)
		for (var dz = -2; dz <= 2; dz++) {
			var d2 = dx * dx + dz * dz;
			if (d2 > 4) continue;
			var depth = d2 <= 1 ? 10 : 6;
			for (var y = top - depth; y <= top; y++) {
				var id = (y == top) ? GRASS_A : (y >= top - 2 ? DIRT_A : STONE_A);
				level.setBlock(x + dx, y, z + dz, id);
			}
		}
	return top + 1;
}
// ============================================================
//  传送 + 分帧预生成（v3.1：加载页盖住，区块生成摊到预生成期）
// ============================================================
// _pregen 状态机：{ dim, chunks:[[cx,cz]...], idx, total, lx, ly, lz, perFrame }
// onTick 每帧生成 perFrame 个区块（level.getBlock 同步触发生成），
// 进度写入加载页文字，完成后才放行玩家落地。
var _pregen = null;
// 防重入：resetChunks 切换维度时引擎会再次 fire onJoinWorld，若此时已在
// 传送（_pregen 非空）或刚传过，直接跳过，避免 travelTo 死循环（加载页闪）。
var _travelGuard = false;
var _lastJoinTick = -9999;

// ============================================================
//  服务器侧替远程玩家传送（联机）
//  除了本地玩家照旧踩传送门传送之外，服务器还会替**远程玩家**判断是否
//  站在传送门上 / 掉出天境虚空，再调 level.changePlayerDimension 传送 ——
//  否则联机时玩家在天境里的位置/掉落没人管（服务器只管方块，不管"谁在
//  哪个维度"这件事的搬运）。
// ============================================================
// 服务器侧：每个远程玩家上次被传送的 tick（防止站在门上被反复传送）。
var _remoteCd = {};
var _lastRemoteTravel = 0;
var _lastRemoteDiag = -9999;   // 服务器视野诊断节流
var _lastScanLog = -9999;      // 扫门诊断节流
var _remoteCd2 = {};          // 天境里"拉回岛顶"的短冷却
var _lastHb = -9999;           // onTick 心跳节流
// 帧计数：联机客户端的世界时间(level.getTime)不前进，用它做节流会
// "第一次之后永远不再触发"。所有节流都改用这个自增计数。
var _myTick = 0;
var _lastCliDiag = -9999;       // 客户端状态诊断节流

// 天境落点高度：用噪声函数算（不查方块，所以服务器侧也能算）。
// getAetherHeight 返回该列最高岛顶（0 = 虚空）。落点不在岛上时螺旋找最近
// 的岛；24 格内都没有 -> 返回 -1（调用方兜底）。
function findAetherLandY(x, z) {
	var h = getAetherHeight(x, z);
	if (h > 0) return h + 1;
	for (var r = 1; r <= 24; r++)
		for (var dx = -r; dx <= r; dx++)
			for (var dz = -r; dz <= r; dz++) {
				if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
				var h2 = getAetherHeight(x + dx, z + dz);
				if (h2 > 0) return h2 + 1;
			}
	return -1;
}

// 围绕任意一点扫描传送门框架并激活（服务器侧替远程玩家用；本地玩家走
// scanForPortal，逻辑一样，只是中心点不同）。
function scanPortalAround(px, py, pz) {
	for (var dx = -2; dx <= 2; dx++)
		for (var dz = -2; dz <= 2; dz++)
			for (var dy = -2; dy <= 2; dy++) {
				var x = px + dx, y = py + dy, z = pz + dz;
				if (y < 1 || y > 120) continue;
				if (level.getBlock(x - 1, y - 1, z) != GLOWSTONE) continue;
				if (level.getBlock(x - 1, y + 3, z) != GLOWSTONE) continue;
				if (isPortalFrame(x, y, z)) { activatePortal(x, y, z); return true; }
			}
	// 诊断：扫不到门时记下服务器眼里的玩家位置与关键方块
	// （萤石 = 89；水 = 8/9；传送门 = 130；空气 = 0）
	var _t = _myTick;
	if (_t - _lastScanLog > 20) {
		_lastScanLog = _t;
		modLog("[天境] 服务器扫门无结果 玩家@" + px + "," + py + "," + pz
			+ " here=" + level.getBlock(px, py, pz)
			+ " up=" + level.getBlock(px, py + 1, pz)
			+ " down=" + level.getBlock(px, py - 1, pz)
			+ " 左柱下=" + level.getBlock(px - 1, py - 1, pz)
			+ " 左柱上=" + level.getBlock(px - 1, py + 3, pz));
	}
	return false;
}

// 服务器侧替远程玩家检测传送（联机时"进天境"由服务器执行）：
//   - 主世界：先尝试激活身边的门（服务器收不到 onPlaceBlock 事件），
//     玩家站在门上 -> changePlayerDimension 送往天境；
//   - 天境：掉到浮空岛下方（y<6）-> 送回主世界入口。
// 位置按玩家名分开记（home_<名字>_x/y/z），多人不会互相覆盖。
function hostRemoteTravelTick(tick) {
	if (!level.listPlayers) return;
	var ps = level.listPlayers();
	if (!ps || !ps.length) return;
	// 诊断：服务器眼里的每个远程玩家（位置 / 维度 / 该处方块 id）
	if (tick - _lastRemoteDiag > 20) {
		_lastRemoteDiag = tick;
		var _d = "";
		for (var _i = 0; _i < ps.length; _i++) {
			var _q = ps[_i];
			var _qy = Math.floor(_q.y);
			_d += " [" + _q.name + " id=" + _q.id + " dim=" + _q.dim
				+ " @" + Math.floor(_q.x) + "," + _qy + "," + Math.floor(_q.z)
				+ " here=" + level.getBlock(Math.floor(_q.x), _qy, Math.floor(_q.z))
				+ " below=" + level.getBlock(Math.floor(_q.x), _qy - 1, Math.floor(_q.z)) + "]";
		}
		modLog("[天境] 服务器视野:" + _d);
	}
	for (var i = 0; i < ps.length; i++) {
		var p = ps[i];
		if (!p || p.local) continue;              // 本地玩家走原来的路
		if (p.dim != 0 && p.dim != AETHER_DIM) continue;
		var last = _remoteCd[p.id];
		if (last !== undefined && tick - last < 60) continue;
		var px = Math.floor(p.x), py = Math.floor(p.y), pz = Math.floor(p.z);
		if (p.dim == 0) {
			scanPortalAround(px, py, pz);
			if (level.getBlock(px, py, pz) == PORTAL_BLOCK ||
			    level.getBlock(px, py + 1, pz) == PORTAL_BLOCK) {
				var ly = findAetherLandY(px, pz);
				if (ly < 0) ly = 92;
				ly = Math.ceil(ly) + 1;   // 对准岛顶上方（整数），别让玩家从半空落下去
				_remoteCd[p.id] = tick;
				level.setModState("home_" + p.name + "_x", px);
				level.setModState("home_" + p.name + "_y", py);
				level.setModState("home_" + p.name + "_z", pz);
				modLog("[天境] 服务器传送 " + p.name + " -> 天境 (" + px + "," + ly + "," + pz + ")");
				level.changePlayerDimension(p.id, AETHER_DIM, px + 0.5, ly, pz + 0.5);
			}
		} else if (p.dim == AETHER_DIM) {
			if (p.y < 6) {
				var hx = parseInt(level.getModState("home_" + p.name + "_x"), 10);
			var hz = parseInt(level.getModState("home_" + p.name + "_z"), 10);
			if (isNaN(hx)) hx = 0;
			if (isNaN(hz)) hz = 0;
			var hy = findLandY(hx, hz);
			if (hy < 0) hy = findLandYNear(hx, hz);
			if (hy < 0) hy = 64;
				_remoteCd[p.id] = tick;
				modLog("[天境] 服务器传送 " + p.name + " -> 主世界 (" + hx + "," + hy + "," + hz + ")");
				level.changePlayerDimension(p.id, 0, hx + 0.5, hy, hz + 0.5);
			} else {
				// 天境地形是懒生成的：传送那一刻脚下区块可能还没生成，玩家会
				// 直接往下掉。用噪声算的岛顶（不依赖区块）把他拉回地面。
				var _cd2 = _remoteCd2[p.id];
				if (_cd2 === undefined || tick - _cd2 > 8) {
					var gy = getAetherHeight(px, pz);
					if (gy > 0 && p.y < gy + 1) {
						_remoteCd2[p.id] = tick;
						modLog("[天境] 把 " + p.name + " 拉回岛顶 y=" + (Math.ceil(gy) + 2));
						level.changePlayerDimension(p.id, AETHER_DIM, px + 0.5, Math.ceil(gy) + 2, pz + 0.5);
					}
				}
			}
		}
	}
}

// ============================================================
//  传送归属：本机踩门该不该自己传送？
//  联机客户端（连别人服务器那一端）**不能**自己传送：本机一传送，玩家位置
//  就离开了那道门，服务器再也认不出"他踩了门"，于是天境永远由本机本地
//  生成；更糟的是天境里的方块改动会被服务器当成主世界同坐标的改动。
//  所以：服务器那一端（单机 / 房主 / 独立服务器）照旧自己传送；
//  联机客户端站在门里等服务器送 —— 带 3 秒兜底，判断失误也不会卡住。
// ============================================================
var _remoteClient = null;
function isRemoteClient() {
	if (_remoteClient === null) {
		var rc = false;
		try {
			if (typeof level.isHost === "function") rc = (level.isHost() === false);
		} catch (e) { rc = false; }
		_remoteClient = rc;
		modLog("[天境] 环境判定: isRemoteClient=" + rc + "（isHost=" +
			(typeof level.isHost === "function" ? level.isHost() : "无API") + "）");
	}
	return _remoteClient;
}
// 联机客户端站在门里等服务器的累计 tick（60 tick = 3 秒兜底）
var _portalWait = 0;
var _voidWait = 0;   // 联机客户端掉虚空后等服务器送回的累计 tick

function travelTo(dim, x, z, radius) {
	if (_travelGuard) { modLog("[天境] travelTo: 防重入跳过"); return; }
	modLog("[天境] travelTo(dim=" + dim + ") 由本机执行（本地传送/本地生成）");
	_travelGuard = true;
	if (level.stopMusic) level.stopMusic();   // 切换维度先停掉正在播的音乐
	// 不用加载界面（ui.showLoading overlay 有残留闪烁 bug）：直接切换，
	// 区块生成由 _pregenTick 锁定玩家位置完成。
	level.resetChunks(dim);
	// 找落地（同步生成目标区块，代价小）
	var y = findLandY(x, z);
	if (y < 0) {
		if (dim == AETHER_DIM) {
			y = makeWelcomeIsland(x, z);   // 天境虚空才生成欢迎岛
		} else {
			y = findLandYNear(x, z);       // 主世界：周围找最近地表（不生成天境方块）
			if (y < 0) { x = 0; z = 0; y = findLandY(0, 0); }
			if (y < 0) y = 64;
		}
	}
	player.teleport(x, y, z);
	// 预生成列表：以落点为圆心，从里到外逐环（先近后远，近处先就绪）
	var pcx = Math.floor(x / 16), pcz = Math.floor(z / 16);
	var chunks = [];
	for (var r = 0; r <= radius; r++)
		for (var dx = -r; dx <= r; dx++)
			for (var dz = -r; dz <= r; dz++) {
				if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
				chunks.push([pcx + dx, pcz + dz]);
			}
	_pregen = {
		dim: dim,
		chunks: chunks,
		idx: 0,
		total: chunks.length,
		lx: x, ly: y, lz: z,
		perFrame: (dim == AETHER_DIM) ? 4 : 8   // 天境每区块生成重，少点；主世界快
	};
	// 注意：saveDimensionState / hideLoading / sendMessage 延迟到预生成完成
}

function _pregenTick() {
	// 锁定玩家位置（防加载期间坠落/走动跑出未生成区）
	player.teleport(_pregen.lx, _pregen.ly, _pregen.lz);
	// 这一帧生成 perFrame 个区块：getBlock 采样一次即同步生成整区块
	var n = 0;
	while (_pregen.idx < _pregen.total && n < _pregen.perFrame) {
		var c = _pregen.chunks[_pregen.idx];
		level.getBlock(c[0] * 16 + 8, 100, c[1] * 16 + 8);
		_pregen.idx++;
		n++;
	}
	if (_pregen.idx >= _pregen.total) {
		var d = _pregen.dim;
		_pregen = null;
		_travelGuard = false;
		ui.hideLoading();   // 清任何残留 overlay（如引擎/其它模组设置过）
		level.saveDimensionState(d);
		player.sendMessage(d == AETHER_DIM ? "你来到了天境！" : "你回到了主世界。");
	}
}
// ============================================================
//  云弹性（v3.1.1：白云轻弹 + 蓝云高弹，移植原版 Aercloud）
// ============================================================
// 判断方块是不是四种云之一
function isCloud(id) {
	return id == CLOUD_BLOCK || id == BLUE_CLOUD || id == GOLD_CLOUD || id == PINK_CLOUD;
}

// 弹跳状态机（全程接管，精确补偿引擎物理下拉）：
//   moveTo 不重置玩家 yd，引擎物理每 tick 会按 yd 把玩家往下拉
//   （yd 序列 yd_t = -3.92*(1-0.98^t)，与我们的 teleport 无关、可预测），
//   所以我们每 tick 把玩家放到「轨迹高度 + 补偿量」，物理下拉后正好落在轨迹上，无抖动。
//   到顶后继续接管下落（轨迹对称），落回云顶结束，落地碰撞会把 yd 归零。
function _bounceTick() {
	var b = _bounce;
	b.t++;
	// 保险：弹跳异常超过 10 秒（200 tick）强制落回云顶，防止卡死
	if (b.t > 200) {
		player.teleport(b.x, b.baseY, b.z);
		_bounce = null;
		modLog("[天境] BOUNCE-ABORT t=" + b.t);
		return;
	}
	// 引擎本 tick 会下拉的量（t 从 1 开始，moveTo 后 yd 从 0 累积）
	var comp = ENGINE_VT * (1 - Math.pow(0.98, b.t - 1));
	// 轨迹积分：上升减速，到顶后下落加速
	if (b.vy > 0) {
		b.vy -= b.g;
		if (b.vy < 0) b.vy = 0;
	} else {
		b.vy += b.g;
	}
	b.y += b.vy;
	// 落回云顶：结束弹跳（引擎落地碰撞会重置 yd，站稳）
	if (b.y <= b.baseY) {
		player.teleport(b.x, b.baseY, b.z);
		_bounce = null;
		return;
	}
	player.teleport(b.x, b.y + comp, b.z);
}

function bounceOnCloud() {
	var tick = _myTick;
	if (_bounce) return;                       // 已在弹跳中
	if (tick - _lastBlueBounce < 10) return;   // 冷却：下落途中不再触发
	var fx = Math.floor(player.getX());
	var fy = Math.floor(player.getY());
	var fz = Math.floor(player.getZ());
	// 只在云的上面弹：脚底 1~2 格内是云（站在云上 / 悬停云上方 1 格内）
	var below1 = level.getBlock(fx, fy - 1, fz);
	var below2 = level.getBlock(fx, fy - 2, fz);
	var cloud = isCloud(below1) ? below1 : (isCloud(below2) ? below2 : 0);
	if (!cloud) return;
	_lastBlueBounce = tick;
	var h = (cloud == BLUE_CLOUD) ? BLUE_BOUNCE_H : CLOUD_BOUNCE_H;
	// 云顶：从脚底向上找第一个非云方块（玩家可能站在云上/悬停/陷在云里，统一落到云顶）
	var topY = fy;
	while (topY < 126 && isCloud(level.getBlock(fx, topY, fz))) topY++;
	// 上升通道检查：上方被云挡住就只弹到云下方（避免弹进上层云卡死）
	var clearH = h;
	for (var yy = topY + 1; yy <= topY + h && yy < 126; yy++)
		if (isCloud(level.getBlock(fx, yy, fz))) { clearH = yy - 1 - topY; break; }
	if (clearH < 1) return;
	// 先站到云顶再弹（若玩家陷在云里，先移出）
	player.teleport(fx + 0.5, topY, fz + 0.5);
	// 优先用引擎速度 API：物理抛起，引擎插值全权负责 = 丝滑
	if (typeof player.setVelocity === "function") {
		player.setVelocity(0, Math.sqrt(2 * 0.08 * clearH), 0);
		level.playSound("random.pop", fx, fy, fz, 1.0, 1.4);
		modLog("[天境] BOUNCE-API cloud=" + cloud + " h=" + clearH + " at " + fx + "," + fy + "," + fz);
		return;
	}
	// 回退：状态机上抛（引擎没有 setVelocity 时的旧路径）
	_bounce = {
		x: fx + 0.5, z: fz + 0.5,
		y: topY,
		baseY: topY,
		vy: Math.sqrt(2 * BOUNCE_G * clearH),
		g: BOUNCE_G,
		t: 0
	};
	level.playSound("random.pop", fx, fy, fz, 1.0, 1.4);   // 弹性音效
	modLog("[天境] BOUNCE cloud=" + cloud + " h=" + clearH + " topY=" + topY + " at " + fx + "," + fy + "," + fz);
}

function isStandingInPortal() {
	var px = Math.floor(player.getX());
	var py = Math.floor(player.getY());
	var pz = Math.floor(player.getZ());
	return level.getBlock(px, py, pz) == PORTAL_BLOCK ||
	       level.getBlock(px, py + 1, pz) == PORTAL_BLOCK;
}

// 重力矿上升（生物实体方案）：
// tryLiftGravit(x,z)：检测该位置周围的重力矿，若上方是空气则生成
//   GRAVIT_MOB 生物（方块形，贴重力矿纹理）替代方块，加入 _gravitRise
// gravitRiseTick()：每 tick mob.setPos 丝滑上移 0.5 格；上方碰到方块
//   或撞世界高度上限 → 移除生物、原位放回重力矿方块。
// 触发：onBreakBlock（挖方块时检测周围重力矿）+ onTick 周期检测
var _gravitRise = [];   // 上升中的重力矿实体：[{eid, x, y, z}]
function tryLiftGravit(x, z) {
	for (var dx = -3; dx <= 3; dx++)
		for (var dz = -3; dz <= 3; dz++) {
			var wx = x + dx, wz = z + dz;
			// 向上找该列最高重力矿（找最上面一块，上方空气才升）
			for (var y = 125; y > 2; y--) {
				if (level.getBlock(wx, y, wz) != ORE_GRAVIT) continue;
				// 该块上方是空气 → 生成方块生物替代
				if (level.getBlock(wx, y + 1, wz) == 0) {
					var already = false;
					for (var i = 0; i < _gravitRise.length; i++)
						if (_gravitRise[i].x == wx && _gravitRise[i].z == wz && Math.abs(_gravitRise[i].y - y) < 2) { already = true; break; }
					if (!already) {
						var eid = level.spawnMob(GRAVIT_MOB, wx + 0.5, y + 0.5, wz + 0.5);
						if (eid > 0) {
							level.setBlock(wx, y, wz, 0);   // 原位清空
							_gravitRise.push({ eid: eid, x: wx + 0.5, y: y + 0.5, z: wz + 0.5 });
						}
					}
				}
				break;   // 只处理该列最上面的重力矿
			}
		}
}

function gravitRiseTick() {
	if (_gravitRise.length == 0) return;
	var remain = [];
	for (var i = 0; i < _gravitRise.length; i++) {
		var g = _gravitRise[i];
		// 用 mob.getPos 读实体实际位置（物理移动后），x/z 也实时更新
		var p = mob.getPos(g.eid);
		var ex, ey, ez;
		if (p && p.length >= 3) {
			ex = p[0]; ey = p[1]; ez = p[2];
			g.x = ex; g.y = ey; g.z = ez;
		} else {
			ex = g.x; ey = g.y; ez = g.z;
		}
		var nx = Math.floor(ex), nz = Math.floor(ez);
		var ny = Math.floor(ey);
		// 上方有方块（生物头顶那格）→ 停止：移除生物，原位放回重力矿方块
		if (level.getBlock(nx, ny + 1, nz) != 0) {
			level.setBlock(nx, ny, nz, ORE_GRAVIT);
			mob.remove(g.eid);
			continue;
		}
		// 撞世界高度上限 → 直接删除自己（不留方块）
		if (ny >= 125) {
			mob.remove(g.eid);
			continue;
		}
		// 丝滑上浮：用 mob.setVelocity 设置向上速度，引擎物理 move 平滑
		// 移动（渲染插值=无瞬移抖动），每 tick 保持 yd 抵消下落
		mob.setVelocity(g.eid, 0, 0.6, 0);
		remain.push(g);
	}
	_gravitRise = remain;
}

// ============================================================
//  事件
// ============================================================
function onChat(msg) {
	if (msg == "/cloud") {
		// 诊断：报告玩家周围云方块数量 + 最近一朵云的位置
		var px = Math.floor(player.getX()), py = Math.floor(player.getY()), pz = Math.floor(player.getZ());
		var n = 0, best = 99999, bx = 0, by = 0, bz = 0;
		for (var dx = -16; dx <= 16; dx++)
			for (var dz = -16; dz <= 16; dz++)
				for (var dy = -12; dy <= 12; dy++) {
					var id = level.getBlock(px + dx, py + dy, pz + dz);
					if (id == CLOUD_BLOCK || id == BLUE_CLOUD || id == GOLD_CLOUD || id == PINK_CLOUD) {
						n++;
						var d = dx * dx + dy * dy + dz * dz;
						if (d < best) { best = d; bx = px + dx; by = py + dy; bz = pz + dz; }
					}
				}
		player.sendMessage("周围云=" + n + " 最近云=" + bx + "," + by + "," + bz);
		modLog("[天境] /cloud n=" + n + " nearest=" + bx + "," + by + "," + bz + " pos=" + px + "," + py + "," + pz);
	} else if (msg == "/bounce") {
		// 诊断：手动弹起，验证 teleport 本身是否生效
		var fx = Math.floor(player.getX()), fy = Math.floor(player.getY()), fz = Math.floor(player.getZ());
		player.teleport(fx + 0.5, fy + 15, fz + 0.5);
		player.sendMessage("手动弹起 +15，落在 " + fx + "," + (fy + 15) + "," + fz);
		modLog("[天境] /bounce manual teleport " + fx + "," + (fy + 15) + "," + fz + " dim=" + level.getCurrentDimension());
	} else if (msg == "/sunspirit") {
		// 召唤太阳之灵 Boss：先生成金地牢风格竞技场（雕纹石墙 + 圣石地面 +
		// 哨兵石角柱 + 中央太阳祭坛），再召唤 Boss（测试版，自然生成后补）
		var px = Math.floor(player.getX());
		var py = Math.floor(player.getY());
		var pz = Math.floor(player.getZ());
		var arenaY = buildSunArena(px, py, pz);
		// 巡逻中心 = 竞技场中心：_sunOriginX 取 px-9，使巡逻椭圆中心
		// (originX+9.25) 落在竞技场中央（否则 Boss 会卡进右侧墙）
		_sunOriginX = px - 9;
		_sunOriginY = arenaY + 5;   // Boss 悬空：中心离地 4 格（AABB 不碰地面/屋顶）
		_sunOriginZ = pz;
		_sunRotary = 0;
		_sunSummonTick = 0;
		_sunFireCd = 0;
		_sunBossHp = SUNSPIRIT_HP;   // 血量由 JS 托管（免疫掉落/窒息/平砍等一切引擎伤害）
		if (_sunBossId > 0) { mob.remove(_sunBossId); _sunBossId = -1; }
		_sunBossId = level.spawnMob(SUNSPIRIT_MOB, _sunOriginX + 9, _sunOriginY, _sunOriginZ);
		if (_sunBossId > 0) {
			player.sendMessage("太阳之灵降临了！血量 " + SUNSPIRIT_HP);
			modLog("[天境] /sunspirit arena=" + px + "," + arenaY + "," + pz + " boss=" + _sunBossId + " origin=" + _sunOriginX + "," + _sunOriginY + "," + _sunOriginZ);
		} else {
			player.sendMessage("召唤太阳之灵失败");
		}
	}
}

// 太阳之灵竞技场：四面不透风的橙红地狱火石地牢（还原原版金地牢）
// 21x21 外框 + 屋顶（内部 19x19x6 空间给 Boss 飞），圣石地面，中央太阳祭坛
function buildSunArena(px, py, pz) {
	var R = 10;
	var y0 = Math.floor(py) - 1;   // 地面 = 玩家脚下
	var top = y0 + 7;              // 屋顶高度（内部空间 6 格高）
	// 清场：区域内方块全清（含上方空间给 Boss 飞）
	for (var dx = -R; dx <= R; dx++)
		for (var dz = -R; dz <= R; dz++)
			for (var dy = 0; dy <= 8; dy++)
				level.setBlock(px + dx, y0 + dy, pz + dz, 0);
	// 圣石地面
	for (var dx = -R; dx <= R; dx++)
		for (var dz = -R; dz <= R; dz++)
			level.setBlock(px + dx, y0, pz + dz, STONE_A);
	// 四面地狱火石墙（1 格厚，y0+1..y0+7），顶部一圈发光地狱火石
	for (var dx = -R; dx <= R; dx++) {
		for (var h = 1; h <= 7; h++) {
			level.setBlock(px + dx, y0 + h, pz - R, HELLFIRE);
			level.setBlock(px + dx, y0 + h, pz + R, HELLFIRE);
		}
		level.setBlock(px + dx, y0 + 7, pz - R, HELLFIRE_LIGHT);
		level.setBlock(px + dx, y0 + 7, pz + R, HELLFIRE_LIGHT);
	}
	for (var dz = -R; dz <= R; dz++) {
		for (var h = 1; h <= 7; h++) {
			level.setBlock(px - R, y0 + h, pz + dz, HELLFIRE);
			level.setBlock(px + R, y0 + h, pz + dz, HELLFIRE);
		}
		level.setBlock(px - R, y0 + 7, pz + dz, HELLFIRE_LIGHT);
		level.setBlock(px + R, y0 + 7, pz + dz, HELLFIRE_LIGHT);
	}
	// 屋顶（地狱火石铺满，封闭不透风）
	for (var dx = -R + 1; dx <= R - 1; dx++)
		for (var dz = -R + 1; dz <= R - 1; dz++)
			level.setBlock(px + dx, y0 + 7, pz + dz, HELLFIRE);
	// 四角内部发光柱（发光地狱火石，1 格高装饰）
	var corners = [[-R + 1, -R + 1], [-R + 1, R - 1], [R - 1, -R + 1], [R - 1, R - 1]];
	for (var c = 0; c < 4; c++)
		level.setBlock(px + corners[c][0], y0 + 1, pz + corners[c][1], HELLFIRE_LIGHT);
	// 中央太阳祭坛
	level.setBlock(px, y0 + 1, pz, SUN_ALTAR);
	// 内部照明 1：墙根一圈原版火把（真光源，像火把一样照亮地牢）
	var TORCH = 50;
	for (var wx = -9; wx <= 9; wx += 3) {
		level.setBlock(px + wx, y0 + 1, pz - 9, TORCH);
		level.setBlock(px + wx, y0 + 1, pz + 9, TORCH);
	}
	for (var wz = -9; wz <= 9; wz += 3) {
		level.setBlock(px - 9, y0 + 1, pz + wz, TORCH);
		level.setBlock(px + 9, y0 + 1, pz + wz, TORCH);
	}
	// 内部照明 2：setLight 打光兜底（两层光点，光传播全覆盖）
	for (var ly = 1; ly <= 4; ly += 3)
		for (var lx = -6; lx <= 6; lx += 3)
			for (var lz = -6; lz <= 6; lz += 3)
				level.setLight(px + lx, y0 + ly, pz + lz, 15);
	modLog("[天境] 太阳祭坛地牢生成 @(" + px + "," + y0 + "," + pz + ")");
	return y0;
}

// Boss 血条 HUD：屏幕上方显示太阳之灵血量（原版 Boss 血条）
function onGuiRender() {
	if (_sunBossId > 0) {
		var hp = _sunBossHp;   // JS 托管血量（引擎血量会被覆盖回此值）
		if (_sunBossHp <= 0) { _sunBossId = -1; return; }
		var w = ui.getWidth(), h = ui.getHeight();
		var bw = Math.floor(w * 0.55);
		var bx = Math.floor((w - bw) / 2), by = 10, bh = 12;
		var ratio = Math.max(0, Math.min(1, hp / SUNSPIRIT_HP));
		ui.fillRect(bx, by, bw, bh, 0xaa000000);
		ui.fillRect(bx + 2, by + 2, Math.floor((bw - 4) * ratio), bh - 4, 0xffb41414);
		ui.drawShadow("太阳之灵", bx + bw / 2 - 24, by - 9, 0xffffffff);
	}
}

function onJoinWorld() {
	// 进世界那一刻先记一条：本机是谁、在哪、看到什么（89=萤石 8/9=水 130=传送门 0=空气）
	var _jx = Math.floor(player.getX());
	var _jy = Math.floor(player.getY());
	var _jz = Math.floor(player.getZ());
	modLog("[天境] onJoinWorld: pos=" + _jx + "," + _jy + "," + _jz
		+ " dim=" + level.getCurrentDimension()
		+ " here=" + level.getBlock(_jx, _jy, _jz)
		+ " down=" + level.getBlock(_jx, _jy - 1, _jz)
		+ " remote=" + isRemoteClient());
	// 清理可能残留的加载 overlay（上次在传送中退出菜单会遗留）
	ui.hideLoading();	// 防重入：resetChunks 切维度会再 fire onJoinWorld；传送中或刚处理过就跳过
	if (_travelGuard) {
		modLog("[天境] onJoinWorld: 传送中，跳过");
		return;
	}
	var now = _myTick;
	if (now - _lastJoinTick < 30) {
		modLog("[天境] onJoinWorld: 去抖跳过 (last=" + _lastJoinTick + " now=" + now + ")");
		return;
	}
	_lastJoinTick = now;
	// 延迟恢复：onJoinWorld fire 时世界名可能还没定（getModState 读不到
	// state 文件 → saved_dim=NaN）。等 20 tick（1 秒）后世界完全就绪再
	// 读取并恢复维度+位置。
	setTimeout(function() {
		restoreSavedState();
	}, 1000);
}

// ---- 维度隔离存档：位置按维度分开保存（dim 0 主世界 / 20 天境各存各的）----
function savedKey(dim, k) { return "saved_" + dim + "_" + k; }
// 读取：新维度 key 优先，缺失时回退旧 key（旧存档兼容）
function readSavedDim(dim, k, oldK) {
	var v = level.getModState(savedKey(dim, k));
	if (v === "" && oldK !== "") v = level.getModState(oldK);
	return parseInt(v, 10);
}

// 读取 saved_* 并恢复上次的维度+位置 —— 这件事**现在由引擎负责**了：
//   引擎会在主世界的存档里记“玩家上次在哪个维度”，而每个维度子世界的存档
//   自己记着“玩家在该维度的位置”，进游戏时引擎自动切回去。
//   所以 mod 不再自己记一份坐标（旧版靠 saved_dim / saved_<dim>_x/y/z 兵分两路，
//   会和引擎抢着切）。函数名保留，交给引擎处理。
function restoreSavedState() {
	if (_travelGuard) return;   // 正在传送就不抢
	if (isRemoteClient()) { modLog("[天境] restoreSavedState: 联机客户端，交给服务器"); return; }
	modLog("[天境] restoreSavedState: 维度/位置恢复已交给引擎（不再用 saved_dim / saved_*）");
}

// 离开世界/退到主菜单：level 已销毁，不能调 level.* —— 只清模组自己的
// 残留状态（传送中的预生成 + loading overlay），否则主菜单一直闪。
function onLeaveWorld() {
	modLog("[天境] onLeaveWorld: 清理传送残留");
	_pregen = null;
	_travelGuard = false;
	ui.hideLoading();
	// 清理残留火球
	for (var i = 0; i < _fireballs.length; i++) mob.remove(_fireballs[i].eid);
	_fireballs = [];
	// 清理残留火傀儡
	for (var j = 0; j < _sunMinions.length; j++) mob.remove(_sunMinions[j]);
	_sunMinions = [];
}

// 太阳之灵 Boss 行为（onMobTick 每帧驱动）：
// 1. 固定矩形内往返（x: origin+8.5~10, z: origin±10, y 固定 originY）
// 2. 自转 rotary 递增（血量越低越快，还原原版 velocity 公式）
// 3. 玩家靠近（<8 格）→ 每 80 tick 召唤一只火傀儡（简化：原版僵尸+火焰）
// 4. 血量归零 → 移除 Boss、清状态
function onMobTick(entityId, typeId) {
	if (typeId != SUNSPIRIT_MOB || entityId != _sunBossId) return;
	// 引擎血量 < 0 = 实体已被移除（极端情况）；死亡以 JS 托管血量为准
	var ehp = mob.getHealth(entityId);
	if (_sunBossHp <= 0 || ehp < 0) {
		var dp = mob.getPos(entityId);
		modLog("[天境] Boss 死亡 hp=" + _sunBossHp + " pos=" + (dp ? dp.join(",") : "?") + " eid=" + entityId);
		mob.remove(entityId); _sunBossId = -1;
		for (var i = 0; i < _fireballs.length; i++) mob.remove(_fireballs[i].eid);
		_fireballs = [];
		for (var j = 0; j < _sunMinions.length; j++) mob.remove(_sunMinions[j]);
		_sunMinions = [];
		return;
	}
	// 关键：把引擎血量覆盖回托管值——Boss 无视一切外部伤害
	// （掉落/窒息/玩家平砍/环境），只有反弹火球命中扣 _sunBossHp
	if (ehp != _sunBossHp) mob.setHealth(entityId, _sunBossHp);
	// 调试：每 120 tick 记一次血量（应恒定 70，除非被打回火球命中）
	var now = _myTick;
	if (now - _lastSunHpLog > 120) {
		_lastSunHpLog = now;
		modLog("[天境] Boss hp=" + _sunBossHp + " pos=" + (mob.getPos(entityId) || []).join(","));
	}
	// 自转：血量越低越快（原版 velocity = (hp/70 - 0.2)*2）
	_sunRotary += 0.05 + (1 - Math.max(0, Math.min(1, _sunBossHp / SUNSPIRIT_HP))) * 0.1;
	// 椭圆往返：绕原点椭圆运动（上下浮动），还原原版巡逻（角速度 0.15，
	// 放慢便于玩家瞄准反弹火球）
	var p = mob.getPos(entityId);
	if (!p || p.length < 3) return;
	var x = p[0], z = p[2];
	var a = _sunRotary * 0.15;
	var nx = _sunOriginX + 9.25 + Math.cos(a) * 1.5;
	var nz = _sunOriginZ + Math.sin(a) * 8.0;
	// 巡逻高度：中心 y0+5±0.8（AABB 底部最低 y0+3.2 > 地面，顶部最高
	// y0+6.8 < 屋顶）——之前 y 太低导致 Boss 插进地面被碰撞乱推卡墙窒息
	var ny = _sunOriginY + Math.sin(a * 2) * 0.8;   // 上下浮动
	mob.setPos(entityId, nx, ny, nz);
	// 关键：清零速度——否则物理（重力）每 tick 把 Boss 从高空拉下，
	// 反复"自由落体几格"触发掉落伤害，血量暴跌（日志 hp 70->64->-232）
	mob.setVelocity(entityId, 0, 0, 0);
	// 召唤火傀儡（玩家靠近 <12 格，每 80 tick 一只）
	_sunSummonTick++;
	if (_sunSummonTick >= SUNSPIRIT_SUMMON_CD) {
		_sunSummonTick = 0;
		// 清理已死亡的火傀儡，统计存活数（上限 4 只）
		var alive = [];
		for (var m = 0; m < _sunMinions.length; m++)
			if (mob.getHealth(_sunMinions[m]) >= 0) alive.push(_sunMinions[m]);
		_sunMinions = alive;
		if (alive.length < 4) {
			var px = Math.floor(player.getX()), py = Math.floor(player.getY()), pz = Math.floor(player.getZ());
			var dist = Math.sqrt((px - x) * (px - x) + (py - p[1]) * (py - p[1]) + (pz - z) * (pz - z));
			if (dist < 12) {
				var mid = level.spawnVanilla("zombie", nx, ny - 1, nz);
				if (mid > 0) {
					mob.setPos(mid, nx, ny - 1, nz);
					level.spawnParticle("flame", nx, ny - 1, nz, 0, 0.2, 0);
					level.playSound("mob.zombie", nx, ny - 1, nz, 1.0, 1.4);
					_sunMinions.push(mid);
				}
			}
		}
	}
	// 发射火球：场上已有火球时不再发（等它被反弹命中 Boss / 打中玩家 /
	// 撞墙或超时消失后才发下一颗），保证同屏最多一颗
	_sunFireCd--;
	if (_sunFireCd <= 0 && _fireballs.length == 0) {
		_sunFireCd = 60;
		// 瞄准玩家中心（不 +1：发射点与瞄准点都取实体中心，弹道才不会
		// 整体抬高到玩家头顶上方飞过）
		var pp = [player.getX(), player.getY(), player.getZ()];
		var dx = pp[0] - nx, dy = pp[1] - ny, dz = pp[2] - nz;
		var len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
		var f = level.spawnMob(FIREBALL_MOB, nx, ny, nz);
		if (f > 0) {
			level.playSound("mob.ghast.fireball", nx, ny, nz, 1.0, 1.2);
			_fireballs.push({ eid: f, vx: dx / len * FIREBALL_SPEED, vy: dy / len * FIREBALL_SPEED, vz: dz / len * FIREBALL_SPEED, fromBoss: true, age: 0 });
		}
	}
	// 火球飞行 + 命中判定
	updateFireballs();
}

// 火球每 tick 移动：命中玩家（受伤）或打回的火球命中 Boss（扣血），
// 撞到固体方块反弹（原版晶体弹墙），出界/超时清理
function updateFireballs() {
	for (var i = _fireballs.length - 1; i >= 0; i--) {
		var fb = _fireballs[i];
		var fp = mob.getPos(fb.eid);
		if (!fp || fp.length < 3) { _fireballs.splice(i, 1); continue; }
		var nx = fp[0] + fb.vx, ny = fp[1] + fb.vy, nz = fp[2] + fb.vz;
		// 撞墙处理：打回状态的火球（fromBoss=false）撞墙 -> 爆炸消失（只有
		// 直接被玩家打回去命中 Boss 才扣血，方块反弹不会）；Boss 发射的
		// 火球撞墙 -> 逐轴反弹继续飞
		if (isBlockSolid(Math.floor(nx), Math.floor(ny), Math.floor(nz))) {
			if (!fb.fromBoss) {
				level.spawnParticle("largeexplode", fp[0], fp[1], fp[2], 0, 0, 0);
				level.playSound("random.explode", fp[0], fp[1], fp[2], 1.0, 1.4);
				mob.remove(fb.eid); _fireballs.splice(i, 1); continue;
			}
			var bounced = false;
			if (isBlockSolid(Math.floor(fp[0] + fb.vx), Math.floor(fp[1]), Math.floor(fp[2]))) { fb.vx = -fb.vx; bounced = true; }
			if (isBlockSolid(Math.floor(fp[0]), Math.floor(fp[1] + fb.vy), Math.floor(fp[2]))) { fb.vy = -fb.vy; bounced = true; }
			if (isBlockSolid(Math.floor(fp[0]), Math.floor(fp[1]), Math.floor(fp[2] + fb.vz))) { fb.vz = -fb.vz; bounced = true; }
			if (bounced) level.playSound("random.orb", fp[0], fp[1], fp[2], 0.8, 1.3);
			// 反弹后重算目标位置
			nx = fp[0] + fb.vx; ny = fp[1] + fb.vy; nz = fp[2] + fb.vz;
		}
		mob.setPos(fb.eid, nx, ny, nz);
		// 打回的火球命中 Boss（唯一伤害来源，直接扣 JS 托管血量）
		if (!fb.fromBoss && _sunBossId > 0) {
			var bp = mob.getPos(_sunBossId);
			var bd = Math.sqrt((nx - bp[0]) * (nx - bp[0]) + (ny - bp[1]) * (ny - bp[1]) + (nz - bp[2]) * (nz - bp[2]));
			if (bd < 3.0) {
				level.spawnParticle("largeexplode", nx, ny, nz, 0, 0, 0);
				level.playSound("random.explode", nx, ny, nz, 1.0, 1.4);
				_sunBossHp -= FIREBALL_BDMG;
				mob.remove(fb.eid); _fireballs.splice(i, 1); continue;
			}
		}
		// 命中玩家
		var pd = Math.sqrt((nx - player.getX()) * (nx - player.getX()) + (ny - player.getY()) * (ny - player.getY()) + (nz - player.getZ()) * (nz - player.getZ()));
		if (pd < 1.5) {
			level.spawnParticle("largeexplode", nx, ny, nz, 0, 0, 0);
			level.playSound("random.explode", nx, ny, nz, 1.0, 1.4);
			player.damage(FIREBALL_DMG);
			mob.remove(fb.eid); _fireballs.splice(i, 1); continue;
		}
		// 出界 / 超过 10 秒清理
		if (ny < 0 || ny > 130 || Math.abs(nx) > 400 || Math.abs(nz) > 400 || fb.age > 200) {
			mob.remove(fb.eid); _fireballs.splice(i, 1); continue;
		}
		fb.age++;
	}
}

// 通用固体检测（火球撞墙用）：空气/水/云/传送门可穿过，其余方块算固体
function isBlockSolid(x, y, z) {
	if (y < 0 || y > 127) return false;
	var id = level.getBlock(x, y, z);
	if (id == 0) return false;
	if (id == WATER || id == CALM_WATER) return false;
	if (id == CLOUD_BLOCK || id == BLUE_CLOUD || id == GOLD_CLOUD || id == PINK_CLOUD) return false;
	if (id == PORTAL_BLOCK) return false;
	return true;
}

// Boss 免疫玩家平砍（命名空间 veto：__mod_<mod名>_<钩子名>，可与 block_mod 共存）
// 双保险：即使 veto 未命中，onMobTick 血量托管也会把引擎血量覆盖回 _sunBossHp
function __mod_aether_can_attack(victimId) {
	if (victimId == _sunBossId) return false;
	return true;
}


// 攻击命中瞬间：玩家打中火球 -> 弹回 Boss（原版机制：晶体被击回）
function onAttack(victimId) {
	for (var i = 0; i < _fireballs.length; i++) {
		if (_fireballs[i].eid == victimId && _fireballs[i].fromBoss) {
			modLog("[天境] 火球被击回 eid=" + victimId);
			var fp = mob.getPos(victimId);
			var bp = _sunBossId > 0 ? mob.getPos(_sunBossId) : null;
			if (fp && fp.length == 3 && bp && bp.length == 3) {
				var dx = bp[0] - fp[0], dy = bp[1] - fp[1], dz = bp[2] - fp[2];
				var len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
				_fireballs[i].vx = dx / len * FIREBALL_SPEED;
				_fireballs[i].vy = dy / len * FIREBALL_SPEED;
				_fireballs[i].vz = dz / len * FIREBALL_SPEED;
				_fireballs[i].fromBoss = false;
				_fireballs[i].age = 0;
				mob.setHealth(victimId, 999);   // 回满血防被打死
				level.playSound("random.orb", fp[0], fp[1], fp[2], 1.0, 1.5);
			}
			return;
		}
	}
}

// 挖方块时：检测被挖位置周围的重力矿——若上方是空气则触发上浮
function onBreakBlock(x, y, z, face, oldTileId, data) {
	if (level.getCurrentDimension() != AETHER_DIM) return;
	tryLiftGravit(x, z);
}

// 玩家放置方块后立即扫描一次传送门框架：倒水/补萤石/补框架的瞬间就激活，
// 不用等周期扫描（最长 0.5 秒）。4 tick 防抖避免连续放置重复全扫。
var _lastPlaceScan = 0;
function onPlaceBlock(x, y, z, face, itemId) {
	if (level.getCurrentDimension() == AETHER_DIM) return;
	var now = _myTick;
	if (now - _lastPlaceScan < 4) return;
	_lastPlaceScan = now;
	scanForPortal();
}

function onTick() {
	_myTick++;   // 帧计数（替代 level.getTime 做节流）
	// 维度传送预生成中：每帧生成一批区块、锁定玩家，先不处理其它逻辑
	if (_pregen) {
		// 兜底：维度被外部切走了（退出/重进）就放弃预生成，清掉残留状态
		if (level.getCurrentDimension() != _pregen.dim) {
			_pregen = null;
			_travelGuard = false;
			ui.hideLoading();
			return;
		}
		_pregenTick();
		return;
	}
	var tick = _myTick;
	var cur = level.getCurrentDimension();
	// 诊断心跳：确认 aether 的 onTick 到底跑没跑（每 10 秒一条）
	if (tick - _lastHb > 200) {
		_lastHb = tick;
		var _np = -1;
		try { if (level.listPlayers) _np = level.listPlayers().length; } catch (e) {}
		modLog("[天境] 心跳 onTick tick=" + tick + " dim=" + cur + " players=" + _np);
	}
	// 客户端状态（每 5 秒一条）：本机看到的位置 / 脚下与左柱方块 / 是否联机客户端
	// 方块对照：89=萤石 8/9=水 130=传送门 0=空气
	if (tick - _lastCliDiag > 100) {
		_lastCliDiag = tick;
		var _cx = Math.floor(player.getX());
		var _cy = Math.floor(player.getY());
		var _cz = Math.floor(player.getZ());
		modLog("[天境] 客户端状态 @" + _cx + "," + _cy + "," + _cz
			+ " here=" + level.getBlock(_cx, _cy, _cz)
			+ " down=" + level.getBlock(_cx, _cy - 1, _cz)
			+ " 左柱下=" + level.getBlock(_cx - 1, _cy - 1, _cz)
			+ " 左柱上=" + level.getBlock(_cx - 1, _cy + 3, _cz)
			+ " dim=" + cur + " remote=" + isRemoteClient());
	}
	// 维度/坐标的保存已交给引擎：主世界存档记“玩家上次在哪个维度”，各维度
	// 子世界的存档各记“玩家在该维度的位置”——mod 不再自己存一份。
	// 天境云弹性（白云轻弹 / 蓝云高弹）：弹跳中走平滑上抛，否则检测脚下云触发
	if (cur == AETHER_DIM) {
		if (_bounce) _bounceTick();
		else bounceOnCloud();
		// 重力矿上浮：每 tick 驱动上升中的实体；每 30 tick 检测玩家
		// 周围重力矿（上方空气则实体化上浮）
		gravitRiseTick();
		if (tick - _gravitTick > 30) {
			_gravitTick = tick;
			tryLiftGravit(Math.floor(player.getX()), Math.floor(player.getZ()));
		}
		// 调试：每 6 秒记一次位置+脚下方块（排查弹跳）
		if (tick - _lastDbg > 120) {
			_lastDbg = tick;
			var fx = Math.floor(player.getX()), fy = Math.floor(player.getY()), fz = Math.floor(player.getZ());
			modLog("[天境] pos=" + fx + "," + fy + "," + fz + " dim=" + level.getCurrentDimension() + " below=" + level.getBlock(fx, fy - 1, fz) + " here=" + level.getBlock(fx, fy, fz));
		}
	}
	// 天境背景音乐：进入天境立刻播放，之后每 ~240 秒换一首
	if (cur == AETHER_DIM) {
		if (_prevDim != AETHER_DIM) {
			_musicTimer = 0;      // 刚进入天境 → 立刻播
			_lastMusicIdx = -1;
		} else {
			_musicTimer++;
		}
		if (_musicTimer == 0 || _musicTimer >= 4800) {
			_musicTimer = 0;
			var idx;
			do { idx = Math.floor(Math.random() * _musicNames.length); } while (idx == _lastMusicIdx);
			_lastMusicIdx = idx;
			level.playMusic(_musicNames[idx], 0.3);
		}
	} else {
		// 离开天境：停掉正在播的音乐（fire-and-forget 的 OpenAL source 不会自动停）
		if (_prevDim == AETHER_DIM && level.stopMusic)
			level.stopMusic();
		_musicTimer = 0;
	}
	_prevDim = cur;
	if (cur == AETHER_DIM && player.getY() < 6) {
		// 联机客户端：由服务器把你送回主世界（本机自己切会让两边维度对不上，
		// 你在服务器眼里还留在天境）。等不到就 10 秒后兜底自己回去。
		if (isRemoteClient() && _voidWait < 600) {
			_voidWait += 4;
			return;
		}
		_voidWait = 0;
		var hx = parseInt(level.getModState("home_x"), 10);
		var hz = parseInt(level.getModState("home_z"), 10);
		if (isNaN(hx)) { hx = 0; hz = 0; }
		travelTo(0, hx, hz, 4);
		return;
	}
	_voidWait = 0;
	// 传送门检测：周期 10 tick（0.5 秒）扫描 5x5x5 框架 + 4 tick 检测站位；
	// onPlaceBlock 会立即扫描（放完水/补块零延迟），这里是兜底。
	if (tick - _lastPortalCheck > 10) {
		_lastPortalCheck = tick;
		if (cur != AETHER_DIM)
			scanForPortal();
	}
	if (tick - _lastFrameScan > 4) {
		_lastFrameScan = tick;
		if (isStandingInPortal()) {
			// 联机客户端：站在门里等服务器把你送进去（服务器那侧认得出
			// "玩家站在传送门上"）。等满 3 秒还没动静 —— 兜底自己传送，
			// 免得判断失误或服务器卡住时人被堵在门口。
			if (isRemoteClient() && _portalWait < 60) {
				_portalWait += 4;
				if (_portalWait >= 60)
					modLog("[天境] 联机等服务器超时（3 秒），兜底本地传送");
			} else {
				_portalWait = 0;
				var px = Math.floor(player.getX());
				var pz = Math.floor(player.getZ());
				var cur = level.getCurrentDimension();
				if (cur == AETHER_DIM) {
					var hx = parseInt(level.getModState("home_x"), 10);
					var hz = parseInt(level.getModState("home_z"), 10);
					if (isNaN(hx)) { hx = 0; hz = 0; }
					travelTo(0, hx, hz, 4);
				} else {
					level.setModState("home_x", px);
					level.setModState("home_y", Math.floor(player.getY()));
					level.setModState("home_z", pz);
					travelTo(AETHER_DIM, px, pz, 5);
				}
				_lastFrameScan = tick;
			}
		} else {
			_portalWait = 0;
		}
	}
	// 服务器端：替每个远程玩家检测传送门 / 掉出天境虚空（联机时"进天境"由
	// 服务器执行）。客户端上 listPlayers() 只返回本机玩家，会被跳过 —— 所以
	// 这段在单机/客户端上等于不做事，不需要额外的"是不是服务器"判断。
	if (tick - _lastRemoteTravel > 4) {
		_lastRemoteTravel = tick;
		hostRemoteTravelTick(tick);
	}
}

modLog("[天境] v3.3.1 模组已加载！柏林噪声浮空大陆 + 装饰 + 云弹性（落点对准岛顶 + 天境防坠）");

// ============================================================
//  主菜单标题替换（原版 Aether 素材原样使用，纯 mod 侧）
//  直接覆盖 gui/title.png（256x64）：原图 aether.png(512x512) 的
//  左上 256x64 正好是 Aether 主标题主体，GL 越界部分自动忽略。
// ============================================================
try {
	if (typeof Assets !== "undefined" && Assets.replaceImage) {
		Assets.replaceImage("gui/title.png", 0, 0, "gui/aether_title_raw.png");
		modLog("[天境] 主菜单标题已替换为 Aether 原图");
	} else {
		modLog("[天境] Assets.replaceImage 不可用，跳过标题替换");
	}
} catch (e) {
	modLog("[天境] 标题替换异常: " + e);
}

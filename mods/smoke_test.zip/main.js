// name: ServerSmokeTest
// author: reasonix
// version: 1.0.0
// description: 验证独立服务端真的加载并执行了 JS mod（含服务端命令）

modLog("[smoke] ===== SERVER MOD LOADED =====");
modLog("[smoke] side: isServer=" + isServer + " isClient=" + isClient);
if (isClient) {
    // 只有客户端进程会走到这里（服务端没有画面）
    modLog("[smoke] client-side half ran");
}

var __ticks = 0;

function onJoinWorld() {
    modLog("[smoke] onJoinWorld fired (server side)");
}

function onTick() {
    __ticks++;
    if (__ticks % 100 === 0)
        modLog("[smoke] server tick " + __ticks);
}

// 服务端命令：客户端输入 /smoke [文字]，由服务端执行并把返回值回给玩家。
Commands.register("smoke", function (sender, args) {
    modLog("[smoke] /smoke by " + sender + " args='" + args + "'");
    return "服务端收到 /smoke（来自 " + sender + "），参数: " + (args || "(无)");
});

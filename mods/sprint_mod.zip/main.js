// name: 疾跑模组
// author: You
// version: 1.1.0
// description: 连按两下 W 疾跑；饥饿值 < 4 时不能疾跑（与饥饿模组联动）
modLog("sprint mod loading...");

var sprinting = false;
var lastWPressTick = -999;
var wasForward = false;
var tick = 0;
var SPRINT_WINDOW = 30;   // 1.5 秒（20 tick/秒）

// 与饥饿模组联动：饥饿值 >= 4 才能疾跑
function canSprint() {
    var h = (typeof __mod_get_hunger === "function") ? __mod_get_hunger() : 10;
    return h >= 4;
}

function onTick() {
    tick++;
    var fwd = player.isForwardHeld();
    if (fwd && !wasForward) {
        // W 按下边沿：1.5 秒内第二次按下 -> 疾跑开始（饥饿足够时）
        if (tick - lastWPressTick <= SPRINT_WINDOW && canSprint()) {
            sprinting = true;
            player.setSprinting(true);
        }
        lastWPressTick = tick;
    }
    // 疾跑中饥饿降到 < 4 -> 强制结束疾跑
    if (sprinting && !canSprint()) {
        sprinting = false;
        player.setSprinting(false);
    }
    if (!fwd && wasForward && sprinting) {
        // 第二次 W 松开 -> 疾跑结束
        sprinting = false;
        player.setSprinting(false);
    }
    wasForward = fwd;
}

// name: 时间控制
// author: Reasonix
// version: 1.0.0
// description: 调整游戏内时间：面板(按 K)一键跳到 清晨/正午/黄昏/午夜；聊天命令 /time
//
// ── 时间单位与换算（来自引擎源码 handheld/src/world/level/Level.h）──
//   Level::TICKS_PER_DAY = 20 tick/秒 * 60 * 16 = 19200 tick = 游戏内一整天(16 分钟)
//   tick 0 = 06:00(日出)  4800 = 12:00(正午)  9600 = 18:00(黄昏)  14400 = 00:00(午夜)
//   1 游戏内小时 = 800 tick；反推时刻 = (tick / 800 + 6) 时
//   （太阳角度 = (tick/19200 - 0.25) * 2π，tick 4800 时太阳在正上方，即正午）
//
// ── 用法 ──
//   按 K 打开/关闭面板 → 点按钮切换时段
//   /time                    报告当前时间
//   /time ui                 打开面板（同上）
//   /time set day|noon|dusk|midnight        预设时段（also morning/evening/night…）
//   /time set 22:30          指定时刻（附带，方便命令直接用）
//   /time set 15000          指定 tick（附带）

var TICKS_PER_DAY  = 19200;   // 一整天
var TICKS_PER_HOUR = 800;     // 19200 / 24
var DAY_START_HOUR = 6;       // tick 0 对应的游戏内时刻（06:00）
var KEY_K = 75;               // Keyboard::KEY_K

// 四个时段预设，id = 面板按钮 id
var PRESETS = [
	{ id: 1, label: "清晨 06:00", hour: 6,  minute: 0 },
	{ id: 2, label: "正午 12:00", hour: 12, minute: 0 },
	{ id: 3, label: "黄昏 18:00", hour: 18, minute: 0 },
	{ id: 4, label: "午夜 00:00", hour: 0,  minute: 0 }
];

// /time set 的名字（中英文都认）
var NAMED_TIMES = {
	"day": [6, 0], "morning": [6, 0], "dawn": [6, 0], "sunrise": [6, 0],
	"noon": [12, 0], "midday": [12, 0],
	"dusk": [18, 0], "evening": [18, 0], "sunset": [18, 0],
	"midnight": [0, 0], "night": [0, 0],
	"清晨": [6, 0], "早上": [6, 0], "早晨": [6, 0],
	"正午": [12, 0], "中午": [12, 0],
	"黄昏": [18, 0], "傍晚": [18, 0],
	"午夜": [0, 0], "夜晚": [0, 0], "晚上": [0, 0]
};

var joinedWorld = false;   // 进过世界才允许开面板（主菜单里按 K 无反应）
var panelOpen   = false;   // 面板当前是否打开
var kHeld       = false;   // K 是否按住（按住时键盘会重复发按下事件，用它防抖）
var tickCount   = 0;       // onTick 计数，用来判断面板是否还活着
var lastPanelRender = -999; // 面板最后一次画自己是在第几帧（onRender 里刷新）
// 换屏动作推迟到下一帧执行：按键回调 / 按钮回调里直接换屏，
// 引擎还在处理同一个输入事件（screen 可能被删掉），推迟到 onTick 最稳。
var pending = 0;           // 0=无  1=打开面板  2=关闭面板

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------
function pad2(n) { return (n < 10 ? "0" : "") + n; }

function isDayHour(hour) { return hour >= 6 && hour < 18; }

// tick → 游戏内时刻 { hour, minute, tick }
function clockOf(tick) {
	var tt = tick % TICKS_PER_DAY;
	if (tt < 0) tt += TICKS_PER_DAY;
	var totalMin = Math.floor(tt * 24 * 60 / TICKS_PER_DAY);   // 从 06:00 起算的分钟数
	return {
		hour:   (Math.floor(totalMin / 60) + DAY_START_HOUR) % 24,
		minute: totalMin % 60,
		tick:   tick
	};
}

// 时刻 → 当天的 tick
function tickForClock(hour, minute) {
	var h = (((hour - DAY_START_HOUR) % 24) + 24) % 24;
	return Math.floor(h * TICKS_PER_HOUR + Math.round(minute * TICKS_PER_HOUR / 60));
}

// 直接写入 tick（0 ~ TICKS_PER_DAY 之外的值也接受）
function setTimeTick(tick) {
	if (typeof level.setTime !== "function") return false;
	level.setTime(Math.floor(tick));
	return true;
}

// 把时间调到「当前这一天的 hour:minute」
// 保留已经过去的整天数（否则月相/天数会倒退回去）
function setClock(hour, minute) {
	if (typeof level.setTime !== "function") return false;
	var cur = level.getTime();
	var day = Math.floor(cur / TICKS_PER_DAY);
	level.setTime(day * TICKS_PER_DAY + tickForClock(hour, minute));
	return true;
}

function nowText() {
	var c = clockOf(level.getTime());
	return "当前时间 " + pad2(c.hour) + ":" + pad2(c.minute) +
	       "（" + (isDayHour(c.hour) ? "白天" : "夜晚") + "），tick " + Math.floor(c.tick);
}

// 是否已经在世界里。除了 onJoinWorld 记的标志，还兜底查一次玩家列表：
// 模组若是**在游戏里中途启用**的（设置→模组 勾选，不重启），引擎不会再发
// 一次 onJoinWorld，只靠标志会导致按 K 没反应。
function inWorld() {
	if (joinedWorld) return true;
	if (typeof level.listPlayers === "function") {
		var ps = level.listPlayers();
		if (ps && ps.length > 0) { joinedWorld = true; return true; }
	}
	return false;
}

// 面板是否还开着。面板被别人挤掉时（按 E 开背包、切到暂停菜单…）引擎不会
// 回调 onClose，所以再用"它还在每帧画自己吗"确认一次，免得误关别人的界面。
function panelAlive() {
	return panelOpen && (tickCount - lastPanelRender) <= 2;
}

function say(s) {
	if (typeof player !== "undefined" && player && typeof player.sendMessage === "function")
		player.sendMessage(s);
	else if (typeof level.broadcast === "function")
		level.broadcast(s);
	else if (typeof modLog === "function")
		modLog(s);
}

// ---------------------------------------------------------------------------
// 面板
// ---------------------------------------------------------------------------
function openPanel() {
	if (typeof ui === "undefined" || typeof ui.openScreen !== "function") return;
	if (typeof level.getTime !== "function") return;

	var W = ui.getWidth(), H = ui.getHeight();
	var bw = 110, bh = 24, gap = 8;
	var x0 = Math.floor((W - (bw * 2 + gap)) / 2);
	var y0 = Math.floor(H / 2) - 48;

	var buttons = [];
	for (var i = 0; i < PRESETS.length; i++) {
		var p = PRESETS[i];
		buttons.push({
			id: p.id, text: p.label,
			x: x0 + (i % 2) * (bw + gap),
			y: y0 + Math.floor(i / 2) * (bh + gap),
			w: bw, h: bh
		});
	}
	buttons.push({
		id: 9, text: "关闭",
		x: Math.floor((W - bw) / 2), y: y0 + 2 * (bh + gap) + 14,
		w: bw, h: bh
	});

	panelOpen = true;
	lastPanelRender = tickCount;
	ui.openScreen({
		title: "时间控制",
		buttons: buttons,
		onButton: function (buttonId) {
			if (buttonId == 9) { pending = 2; return; }
			for (var i = 0; i < PRESETS.length; i++) {
				if (PRESETS[i].id == buttonId) {
					var p = PRESETS[i];
					applyClock(p.hour, p.minute);
					return;
				}
			}
		},
		onClose: function () { panelOpen = false; },
		// 面板里实时显示当前时刻（每帧重画）
		onRender: function () {
			lastPanelRender = tickCount;
			if (typeof ui.drawShadow !== "function") return;
			var c = clockOf(level.getTime());
			ui.drawShadow("时钟 " + pad2(c.hour) + ":" + pad2(c.minute) +
			              "  " + (isDayHour(c.hour) ? "白天" : "夜晚"),
			              x0, y0 - 30, 0xffffffff);
			ui.drawShadow("tick " + Math.floor(c.tick) + "   按 K 开关面板",
			              x0, y0 - 18, 0xffa0a0a0);
		}
	});
}

function closePanel() {
	// 只在面板确实还开着时关，否则会关掉玩家自己打开的界面
	if (panelAlive() && typeof ui.closeScreen === "function") ui.closeScreen();
	panelOpen = false;
}

// 改时间 + 回一句反馈
function applyClock(hour, minute) {
	var before = clockOf(level.getTime());
	if (setClock(hour, minute)) {
		say("§a时间已调到 " + pad2(hour) + ":" + pad2(minute) +
		    "§r（原 " + pad2(before.hour) + ":" + pad2(before.minute) + "）");
	} else {
		say("§c当前环境不支持直接改时间（客户端连别人服务器时改不了）");
	}
}

// ---------------------------------------------------------------------------
// 事件
// ---------------------------------------------------------------------------
function onJoinWorld() {
	joinedWorld = true;
	modLog("时间控制：已进入世界，按 K 打开面板，或输入 /time");
}

function onLeaveWorld() {
	joinedWorld = false;
	panelOpen = false;
	kHeld = false;
	pending = 0;
}

function onTick() {
	tickCount++;
	if (pending == 1) { pending = 0; openPanel(); }
	else if (pending == 2) { pending = 0; closePanel(); }
}

function onKey(keyCode, down) {
	if (keyCode != KEY_K) return;
	if (!down) { kHeld = false; return; }   // 抬起才重新允许触发
	if (kHeld) return;                      // 按住时键盘自动重复，忽略
	kHeld = true;
	if (!inWorld()) return;               // 主菜单/加载中不开面板
	pending = panelAlive() ? 2 : 1;
}

function onChat(msg) {
	var s = String(msg == null ? "" : msg);
	if (s.charAt(0) != "/") return;         // 只认命令，普通聊天不处理
	var parts = s.substring(1).replace(/^\s+/, "").replace(/\s+$/, "").split(/\s+/);
	if (!parts.length || !parts[0]) return;
	var cmd = parts[0].toLowerCase();
	if (cmd != "time" && cmd != "时间") return;
	runTimeCommand(parts.slice(1));
}

function runTimeCommand(args) {
	var sub = (args[0] || "").toLowerCase();

	// /time 或 /time get —— 报告时间
	if (!sub || sub == "get" || sub == "now") {
		say("§e" + nowText());
		return;
	}

	// /time ui —— 打开面板
	if (sub == "ui" || sub == "panel" || sub == "面板") {
		if (inWorld()) { pending = 1; say("§a正在打开时间控制面板（也可以直接按 K）"); }
		else say("§c先进世界再开面板");
		return;
	}

	if (sub != "set" || !args[1]) {
		say("§e用法: §f/time §7报告时间；§f/time ui §7打开面板；" +
		    "§f/time set day|noon|dusk|midnight §7（或 22:30 / tick 数字）");
		return;
	}

	var when = args[1].toLowerCase();

	// 名字（用 hasOwnProperty，避免 "constructor"/"toString" 这类原型键被误认）
	if (NAMED_TIMES.hasOwnProperty(when)) {
		applyClock(NAMED_TIMES[when][0], NAMED_TIMES[when][1]);
		return;
	}

	// 时刻 HH:MM
	if (when.indexOf(":") >= 0) {
		var hm = when.split(":");
		var h = parseInt(hm[0], 10), m = parseInt(hm[1], 10);
		if (isNaN(h) || isNaN(m) || h < 0 || h > 23 || m < 0 || m > 59) {
			say("§c时刻格式不对，例如 22:30");
			return;
		}
		applyClock(h, m);
		return;
	}

	// 纯数字 = tick
	var t = parseInt(when, 10);
	if (isNaN(t) || t < 0) {
		say("§c无法识别: " + args[1] + "（可用 day/noon/dusk/midnight、22:30 或 tick 数字）");
		return;
	}
	if (setTimeTick(t)) {
		var c = clockOf(level.getTime());
		say("§a时间已设为 tick " + Math.floor(t) + "§r（" + pad2(c.hour) + ":" + pad2(c.minute) + "）");
	} else {
		say("§c当前环境不支持直接改时间");
	}
}

// 加载完成时写一行日志，方便排查
if (typeof modLog === "function") modLog("时间控制模组已加载");

// name: 地狱火山群系
// author: coj2
// version: 1.2.0
// environment: both
// description: 自定义群系 API 的测试模组 —— 地狱火山（地狱岩山 + 岩浆湖 + 僵尸猪人 + 暗红天色/雾）。
//   /hellbiome on [维度编号]  把地狱火山撒到该维度（默认 0 = 主世界；省略维度就是 0）
//   /hellbiome off            关掉
//   /hellbiome info           看状态（编号、当前挂在哪个维度、开关）
//   /biomelist                列出所有群系编号（含原版 11 个）
//   /comebiome <编号|名字>     传送到最近的该群系
// 注意：群系是按世界种子实时算的，已经生成过的区块不会变 —— 打开后要往没去过的地方
// 走（或者开新世界）才看得到。
//
// 用到的引擎 API：
//   Biome.define([编号,] 配置)    编号省略 = 引擎自动挑一个没被占用的
//   Biome.distribution(维度, 函数) 返回群系编号；0 = 该坐标用原版群系
//   Biome.list()                  [{id, name, mod}]
//   Biome.get(编号|名字)            单条群系详情（名字/温度/方块/颜色…）
//   Biome.undistribution(维度)     取消某维度的分布
//   Biome.clearCache()            改完分布状态后清引擎的坐标缓存（否已经算过的不生效）
//   onBiomeEnter(id, oldId) / onBiomeLeave(id)   玩家跨群系时的事件（客户端每 tick 检查）
//   level.getBiome(x, z)          {id, name, mod}
//   level.findBiome(编号或名字 [,x,z [,半径]]) -> {x, z} 或 null
//   player.teleport(x, y, z)      挪动本机玩家（小写 player；大写 Player 那套没有传送）

var MOD_NAME    = "地狱火山";
var MOD_VERSION = "1.2.0";
var MOD_TAG     = "\u00a76[" + MOD_NAME + "]\u00a7r ";

var C_OK = "\u00a7a", C_ERR = "\u00a7c", C_INFO = "\u00a7e", C_DIM = "\u00a77", C_HI = "\u00a7f";

var NETHER     = 87;   // 地狱岩（Tile::netherrack）
var LAVA_STILL = 11;   // 静态岩浆（Tile::calmLava）
var LAVA_FLOW  = 10;   // 流动岩浆（Tile::lava）

var BIOME_NAME = "Hell Volcano";
var HELL_ID    = 0;    // Biome.define 返回的真实编号
var DIST_DIM   = -1;   // 当前挂着的维度（-1 = 关）

function log(m) { modLog("[hellbiome] " + m); }
function reply(m) { return MOD_TAG + m; }
function s(v) { return (v === null || v === undefined) ? "" : String(v); }
function trim(v) { return s(v).replace(/^\s+|\s+$/g, ""); }

// ---------------------------------------------------------------------------
// 1) 定义群系：编号省略 —— 引擎自动挑一个没被占用的（原版占 1..11，模组从 12 起）
// ---------------------------------------------------------------------------
var HAS_BIOME_API = (typeof Biome !== "undefined") && Biome && typeof Biome.define === "function";

if (HAS_BIOME_API) {
	HELL_ID = Biome.define({
		name: BIOME_NAME,
		temperature: 2.0,
		downfall: 0.0,
		skyColor: 0x6a1a10,        // 暗红天空
		fogColor: 0x3a0f0f,        // 暗红雾（新增：按群系的雾色）
		waterFogColor: 0x3a1010,   // 水下颜色也发红（新的：水下雾/清晰色）
		grassColor: 0x7a6a3a,      // 草/草方块颜色（这个群系其实不长草，留着演示）
		foliageColor: 0x6a5a2a,    // 树叶颜色（同上）
		topMaterial: NETHER,       // 表层方块
		material: NETHER,          // 填充方块
		surfaceDepth: 40,          // 往下 40 格都铺地狱岩 → 整座山都是地狱岩
		heightScale: 1.7,          // 起伏放大 → 容易长成山
		heightBias: 0.4,
		lavaLakes: 12,             // 每区块约 1/12 概率生成岩浆湖
		// 植被：模组群系默认什么都不长，这里显式写成 0（想长就填数量）
		tree: "none", trees: 0, grass: 0, flowers: 0, mushrooms: 0, reeds: 0, cactus: 0,
		spawns: {
			monster:  [{ mob: 36, weight: 12, min: 2, max: 4 }],   // 36 = 僵尸猪人
			creature: [],
			water:    []
		},
		// 刷怪规则（新增）：只在这个高度带刷怪，亮度 ≤ 7 才刷怪物
		spawnYMin: 30, spawnYMax: 100, monsterLightMax: 7,
		creatureProbability: 0.02
	});
	log("群系已注册：编号 " + HELL_ID + " 名字 " + BIOME_NAME);
} else {
	log("引擎里没有群系 API（Biome.define 不存在）—— 这个模组需要新版引擎");
}

// ---------------------------------------------------------------------------
// 2) 分布：把地狱火山撒到某个维度（每个维度单独挂一个回调，用闭包记住维度号）
// ---------------------------------------------------------------------------
function hellAt(x, z) {
	var cx = Math.floor(x / 128), cz = Math.floor(z / 128);
	var h = (cx * 73856093 + cz * 19349663) % 977;     // 地块哈希
	if (h < 0) h = -h;
	if (h >= 195) return 0;                            // 约 1/5 的地块是火山带
	var wob = Math.sin(x * 0.021) + Math.cos(z * 0.019);
	if (wob < -0.25) return 0;                         // 边缘抖一下，别是正方形
	return HELL_ID;
}

function makeDist(dim) {
	// 回调签名只有 (x, z)，所以用闭包记住"这个回调属于哪个维度"：
	// 只有当前打开的维度才返回群系编号，其它维度一律 0（= 原版群系）。
	return function (x, z) {
		if (DIST_DIM !== dim || HELL_ID <= 0) return 0;
		return hellAt(x, z);
	};
}

var DIST_INSTALLED = {};
function installDistribution(dim) {
	if (typeof Biome.distribution !== "function" || HELL_ID <= 0) return false;
	Biome.distribution(dim, makeDist(dim));   // 重复挂到同一维度会覆盖旧的
	if (typeof Biome.clearCache === "function") Biome.clearCache();   // 清掉旧结果
	return true;
}

function removeDistribution(dim) {
	// 优先用引擎的"取消分布"：取消后该维度彻底不进 JS（连回调都不调）。
	if (typeof Biome.undistribution === "function") Biome.undistribution(dim);
	else if (typeof Biome.clearCache === "function") Biome.clearCache();
}

// ---------------------------------------------------------------------------
// 3) 小工具：找一列的地面（避开岩浆，免得传送到岩浆里）
// ---------------------------------------------------------------------------
function findGround(x, z) {
	var y;
	for (y = 126; y > 2; y--) {
		var b = level.getBlock(x, y, z);
		if (b !== 0 && b !== LAVA_STILL && b !== LAVA_FLOW) return y;
	}
	return 64;
}

// ---------------------------------------------------------------------------
// 4) 指令
// ---------------------------------------------------------------------------
function cmdHellBiome(args) {
	if (!HELL_ID) return reply(C_ERR + "群系没注册成功（引擎里没有群系 API？）");
	var parts = trim(args).toLowerCase().split(/\s+/);
	var sub = parts[0] || "info";

	if (sub === "info") {
		return reply(C_INFO + "编号 " + C_HI + HELL_ID + C_INFO + "（" + BIOME_NAME + "）" +
			C_DIM + " | 分布：" + (DIST_DIM >= 0 ? C_OK + "维度 " + DIST_DIM : C_DIM + "关") +
			C_DIM + " | 用法：/hellbiome on [维度编号] | off");
	}
	if (sub === "on") {
		var dim = (parts.length > 1 && /^-?\d+$/.test(parts[1])) ? parseInt(parts[1], 10) : 0;
		if (!installDistribution(dim)) return reply(C_ERR + "引擎里没有 Biome.distribution");
		DIST_DIM = dim;
		return reply(C_OK + "已把地狱火山撒到" + (dim === 0 ? "主世界" : "维度 " + dim) +
			C_DIM + "（只对还没生成过的区块生效 —— 往远处走或开新世界才看得到；" +
			"脚本维度里也会按群系刷僵尸猪人）");
	}
	if (sub === "off") {
		var had = DIST_DIM;
		DIST_DIM = -1;
		if (had >= 0) removeDistribution(had);
		return reply(C_DIM + "已关闭地狱火山分布" + C_DIM + "（缓存也清了，新生成的区块立即恢复原版）");
	}
	return reply(C_ERR + "用法：/hellbiome on [维度编号] | off | info");
}

function cmdBiomeList() {
	if (typeof Biome === "undefined" || !Biome || typeof Biome.list !== "function")
		return reply(C_ERR + "引擎里没有 Biome.list");
	var all = Biome.list();
	var out = C_INFO + "群系编号（共 " + all.length + " 个，★ = 模组群系）：";
	var i;
	for (i = 0; i < all.length; i++) {
		var b = all[i];
		out += C_DIM + " " + (b.mod ? C_OK + "★" : C_HI + "") + b.id + C_DIM + "=" + (b.mod ? C_OK : C_HI) + b.name;
	}
	return reply(out);
}

// 看脚下是哪个群系（用 level.getBiome + Biome.get）
function cmdBiomeHere() {
	if (typeof level.getBiome !== "function") return reply(C_ERR + "引擎里没有 level.getBiome");
	if (typeof player === "undefined" || !player || typeof player.getX !== "function")
		return reply(C_ERR + "拿不到玩家位置（这一侧没有本机玩家）");
	var x = Math.floor(player.getX()), z = Math.floor(player.getZ());
	var b = level.getBiome(x, z);
	if (!b) return reply(C_ERR + "拿不到群系");
	var detail = (typeof Biome.get === "function") ? Biome.get(b.id) : null;
	return reply(C_INFO + "脚下：" + C_HI + "[" + b.id + "] " + b.name +
		(b.mod ? C_OK + "（模组群系）" : C_DIM + "（原版）") + C_DIM + " @ " + x + ", " + z +
		(detail ? C_DIM + " | 温度 " + detail.temperature + " 表层 " + detail.topMaterial : ""));
}

// 群系事件：引擎在客户端每 tick 检查玩家群系，跨群系时调这两个顶层函数
function onBiomeEnter(id, oldId) {
	if (id === HELL_ID && typeof player !== "undefined" && player && typeof player.sendMessage === "function")
		player.sendMessage(MOD_TAG + "\u00a76你踏进了火山地界（群系 " + id + "）");
}
function onBiomeLeave(id) {
	if (id === HELL_ID && typeof player !== "undefined" && player && typeof player.sendMessage === "function")
		player.sendMessage(MOD_TAG + "\u00a77你离开了火山地界");
}

function cmdComeBiome(args) {
	var t = trim(args);
	if (!t)
		return reply(C_INFO + "用法：/comebiome <编号|名字>   例：/comebiome " + (HELL_ID || 12) + " 或 /comebiome hell");
	if (typeof level.findBiome !== "function")
		return reply(C_ERR + "引擎里没有 level.findBiome");
	var key;
	if (/^-?\d+$/.test(t)) key = parseInt(t, 10);
	else if (t.toLowerCase() === "hell" || t.toLowerCase() === "hellvolcano" || t === "地狱火山") key = HELL_ID;
	else key = t;                                  // 其它名字交给引擎去匹配
	if (key === 0) return reply(C_ERR + "群系没注册成功，没法找");
	var pos = level.findBiome(key, 1024);
	if (!pos)
		return reply(C_ERR + "半径 1024 格内没找到这个群系" + C_DIM +
			(DIST_DIM >= 0 ? "（往没生成过的地方找找看）" : "（分布还没开：先 /hellbiome on）"));
	var gy = findGround(pos.x, pos.z);
	if (typeof player === "undefined" || !player || typeof player.teleport !== "function")
		return reply(C_OK + "找到了：" + C_DIM + pos.x + ", " + pos.z + C_DIM + "，但这一侧没有本机玩家（联机时指令在服务器上跑），请用 /comebiome 在客户端执行");
	player.teleport(pos.x + 0.5, gy + 1.2, pos.z + 0.5);
	return reply(C_OK + "已传送到群系 " + key + C_DIM + " @ " + pos.x + ", " + pos.z + "（地面高度 " + gy + "）");
}

if (typeof Commands !== "undefined" && Commands && typeof Commands.register === "function") {
	Commands.register("hellbiome", function (sender, args) { return cmdHellBiome(trim(args)); },  "地狱火山群系：on [维度]|off|info");
	Commands.register("biomelist", function (sender, args) { return cmdBiomeList(); },             "列出所有群系编号");
	Commands.register("comebiome", function (sender, args) { return cmdComeBiome(trim(args)); },   "传送到最近的某群系");
	Commands.register("biome", function (sender, args) { return cmdBiomeHere(); },                 "看脚下是哪个群系");
}

// name: Giant Zip Test
// author: You
// version: 1.7.0
// description: dimension API + black dragon boss (all JS)
modLog("zip giant loading...");

// ============ 维度系统（纯 JS，区块操作 API） ============
var currentDim = 0;
var pendingTravel = -1;
var tick = 0;

Dimension.define(20000002, { name: "水晶世界", getHeight: function(x, z) {
    return 64;
}});
modLog("crystal dimension defined");

function travelToDimension(id) {
    if (id == currentDim) { player.sendMessage("已经在这个维度了"); return; }
    ui.showLoading(id == 0 ? "返回主世界..." : "正在进入维度 " + id + " ...");
    pendingTravel = id;
}

function doTravel(id) {
    // 离开前清掉维度 20000002 的龙（避免它跟到别的维度）
    if (dragonId > 0) { mob.remove(dragonId); dragonId = -1; }
    if (id == 20000002) dragonSpawned = false;   // 重新进入维度 20000002 会再刷
    level.saveAll();
    player.teleport(0, 70, 0);
    level.resetChunks(id);
    currentDim = id;
    level.saveDimensionState();
    ui.hideLoading();
    player.sendMessage("已进入维度 " + id);
}

function onJoinWorld() {
    player.sendMessage("输入 /giant 召唤石头人，/dragon 召唤暗黑龙，/boom 放烟花");
    var d = level.getCurrentDimension();
    if (d > 0) travelToDimension(d);
}

// ============ 自定义方块 ============
var BLOCK_TEST = Block.defineBlock(100, { name: "测试方块", texture: 6, material: "stone" });
var BLOCK_REDSTONE = Block.defineBlock(101, { name: "红石方块", texture: 51, material: "stone" });
modLog("custom blocks defined");

// ============ 自定义怪物 ============
Mob.defineMob(40, {
    name: "Giant",
    texture: "mob/golem.png",
    health: 60,
    size: [1.2, 2.8],
    model: [
        { name: "body", tex: [16, 16], box: [-6, 0, -6, 12, 24, 12], pos: [0, 0, 0] },
        { name: "head", tex: [0, 0],   box: [-4, 24, -4, 8, 8, 8],   pos: [0, 0, 0] },
        { name: "armL", tex: [48, 16], box: [-8, 2, -3, 4, 18, 6],   pos: [0, 0, 0] },
        { name: "armR", tex: [48, 16], box: [4, 2, -3, 4, 18, 6],    pos: [0, 0, 0] }
    ],
    anim: function(part, age, limb, limbAmount) {
        if (part == "armL") return { x: 0, y: 0, z: Math.sin(age * 0.3) * 0.6 };
        if (part == "armR") return { x: 0, y: 0, z: -Math.sin(age * 0.3) * 0.6 };
        return null;
    }
});

// ============ 暗黑龙（维度 20000002，全 JS 行为） ============
Mob.defineMob(44, {
    name: "暗黑龙",
    texture: "mob/dragon.png",
    health: 200,
    size: [2.4, 1.4],
    scale: 2.5,
    model: [
        { name: "body",  tex: [0, 16],  box: [-9, 0, -5, 18, 6, 12],  pos: [0, 0, 0] },
        { name: "head",  tex: [0, 0],   box: [-4, 6, -7, 8, 6, 7],    pos: [0, 0, 0] },
        { name: "wingL", tex: [36, 0],  box: [5, 2, -3, 12, 2, 16],   pos: [0, 0, 0] },
        { name: "wingR", tex: [36, 0],  box: [-17, 2, -3, 12, 2, 16], pos: [0, 0, 0] },
        { name: "tail",  tex: [0, 36],  box: [-2, 0, -17, 5, 4, 12],  pos: [0, 0, 0] }
    ],
    anim: function(part, age, limb, limbAmount) {
        if (part == "wingL") return { x: 0, y: 0, z: Math.sin(age * 0.5) * 0.9 };
        if (part == "wingR") return { x: 0, y: 0, z: -Math.sin(age * 0.5) * 0.9 };
        if (part == "tail")  return { x: Math.sin(age * 0.3) * 0.5, y: 0, z: 0 };
        return null;
    }
});
modLog("dragon defined (js behavior)");

// ============ 自定义粒子 ============
Particle.define("spark", { texture: "particles/spark.png", size: 1.5, lifetime: 30, gravity: 0.02 });
Particle.define("big_spark", { texture: "particles/spark.png", size: 3.0, lifetime: 40, gravity: 0.01, color: [1.0, 0.8, 0.2] });

var dragonId = -1;
var dragonSpawned = false;   // 本维度是否已刷过（打死/飞走后不再刷）
var DRAGON_HP = 200;
var DRAGON_CX = 0, DRAGON_CY = 72, DRAGON_CZ = 0;
var DRAGON_RADIUS = 16, DRAGON_BOB = 6, DRAGON_SPEED = 0.04;
var DRAGON_DESPAWN = 60;

function onChat(msg) {
    if (msg == "/giant") {
        player.sendMessage("Spawned Giant!");
        level.spawnMob(40, player.getX(), player.getY(), player.getZ());
    } else if (msg == "/dragon") {
        if (dragonId > 0) { mob.remove(dragonId); dragonId = -1; }
        dragonId = level.spawnMob(44, DRAGON_CX, DRAGON_CY, DRAGON_CZ);
        dragonSpawned = true;
        player.sendMessage("暗黑龙出现了！");
    } else if (msg == "/boom") {
        player.sendMessage("Boom!");
        for (var i = 0; i < 20; i++) {
            level.spawnParticle("spark",
                player.getX(), player.getY() + 1, player.getZ(),
                (Math.random() - 0.5) * 0.5, Math.random() * 0.5, (Math.random() - 0.5) * 0.5);
        }
    } else if (msg.indexOf("/dim ") == 0) {
        var id = parseInt(msg.substr(5));
        if (!isNaN(id)) travelToDimension(id);
    }
}

function onTick() {
    tick++;
    if (pendingTravel >= 0) {
        var id = pendingTravel;
        pendingTravel = -1;
        doTravel(id);
    }
    // 维度 20000002：本维度还没刷过龙就刷一条（打死/飞走后不再自动刷）
    if (currentDim == 20000002 && !dragonSpawned) {
        dragonId = level.spawnMob(44, DRAGON_CX, DRAGON_CY, DRAGON_CZ);
        if (dragonId > 0) {
            dragonSpawned = true;
            player.sendMessage("暗黑龙出现在天空！");
        }
    }
    // 龙行为：绕圈飞 + 血量 + 距离
    if (dragonId > 0) {
        var a = tick * DRAGON_SPEED;
        mob.setRot(dragonId, a * 57.3, 0);
        mob.setPos(dragonId,
            DRAGON_CX + Math.cos(a) * DRAGON_RADIUS,
            DRAGON_CY + Math.sin(a * 2) * DRAGON_BOB,
            DRAGON_CZ + Math.sin(a) * DRAGON_RADIUS);
        var hp = mob.getHealth(dragonId);
        if (hp <= 0) { dragonId = -1; return; }   // 被打死了
        var p = mob.getPos(dragonId);
        if (!p) { dragonId = -1; return; }
        var dx = p[0] - player.getX();
        var dy = p[1] - player.getY();
        var dz = p[2] - player.getZ();
        if (dx*dx + dy*dy + dz*dz > DRAGON_DESPAWN * DRAGON_DESPAWN) {
            mob.remove(dragonId);
            dragonId = -1;
            player.sendMessage("暗黑龙飞远了...");
            return;
        }
    }
    // 火焰粒子：玩家视线前方 3 米
    var yaw = player.getYRot() * Math.PI / 180;
    var pitch = player.getXRot() * Math.PI / 180;
    var dx = -Math.sin(yaw) * Math.cos(pitch);
    var dy = -Math.sin(pitch);
    var dz = Math.cos(yaw) * Math.cos(pitch);
    level.spawnParticle("spark",
        player.getX() + dx * 3, player.getY() + 1 + dy * 3, player.getZ() + dz * 3,
        dx * 0.1, 0, dz * 0.1);
}

// Boss 血条（顶部）
function onGuiRender() {
    if (dragonId <= 0) return;
    var hp = mob.getHealth(dragonId);
    if (hp < 0) { dragonId = -1; return; }
    var w = ui.getWidth(), h = ui.getHeight();
    var bw = Math.floor(w * 0.55);
    var bx = Math.floor((w - bw) / 2);
    var by = 10, bh = 12;
    var ratio = hp / DRAGON_HP;
    if (ratio < 0) ratio = 0;
    if (ratio > 1) ratio = 1;
    ui.fillRect(bx, by, bw, bh, 0xaa000000);
    ui.fillRect(bx + 2, by + 2, Math.floor((bw - 4) * ratio), bh - 4, 0xffb41414);
    ui.drawText("暗黑龙", bx, by - 9, 0xffffffff);
}

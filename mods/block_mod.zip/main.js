// ============================================================
//  格挡 mod (Block Mod)
//  持剑 + 按住右键(使用键) → 剑横在视角左前(格挡姿势)
//  格挡期间正面受到的攻击全部转为剑耐久消耗，玩家不掉血
//  剑耐久超过上限时引擎自动"爆掉"（0.6.1 原有机制）
// ============================================================

// 剑的物品 id（0.6.1：256 + 注册 id）
// 铁剑 267 / 木剑 268 / 石剑 272 / 钻剑 276 / 金剑 283
var SWORD_IDS = [267, 268, 272, 276, 283];
var BLOCK_FOV = 60;   // 正面判定角度（攻击方向与玩家朝向夹角，单位度）

// 当前是否处于"格挡状态"：手持剑 且 按住右键
function __isBlocking() {
	return SWORD_IDS.indexOf(player.getHeldItemId()) >= 0 && player.isUseHeld();
}

// 每 tick：同步格挡姿势（0 正常 / 1 格挡）
function onTick() {
	player.setItemPose(__isBlocking() ? 1 : 0);
}

// 格挡中禁止攻击（mod 侧攻击 veto，无需改本体）：
// 按住右键格挡时左键挥剑/打怪无效
// 命名空间格式：__mod_<mod名>_<钩子名>（本体枚举所有匹配函数，不冲突）
function __mod_block_can_attack(victimId) {
	if (__isBlocking()) return false;
	return true;
}

// 玩家受击 hook：返回 false = 玩家不掉血（伤害已转成剑耐久）
function __mod_on_player_hurt(dmg, srcId) {
	if (!__isBlocking()) return true;          // 没在格挡 → 正常掉血

	// 只能挡正面：攻击来自正前方 ±60° 才有效
	if (srcId > 0) {
		var sp = mob.getPos(srcId);
		if (sp && sp.length >= 3) {
			var px = player.getX(), pz = player.getZ();
			var dx = px - sp[0];
			var dz = pz - sp[2];
			if (dx * dx + dz * dz > 0.01) {
				var atkYaw = Math.atan2(dx, dz) * 180 / Math.PI;   // 攻击方向 yaw
				var pyaw = player.getYRot();
				var diff = ((atkYaw - pyaw + 540) % 360) - 180;    // 归一化夹角
				if (Math.abs(diff) > BLOCK_FOV) return true;       // 背后攻击挡不了
			}
		}
	}

	// 格挡成功：伤害转剑耐久（超过 maxDamage 引擎自动爆剑）
	var cur = player.getHeldItemDamage();
	var max = player.getHeldItemMaxDamage();
	player.setHeldItemDamage(cur + dmg);
	return false;   // 不掉血
}

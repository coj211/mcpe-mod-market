// name: 椅子
// author: coj2
// version: 1.1.0
// description: 椅子方块。把准星对着椅子按 J 坐下（附近没有准星目标时会退一步找身边
//              最近的椅子），再按 J 或空格起身；椅子被拆掉也会自动起身。
//              **右键完全不碰** —— 该放方块就放方块、该挖就挖，不会抢。
//              谁按谁坐：用 player.getId() 拿按键那个人的 id，再 Player.sit(id,x,y,z)；
//              联机也一样（服务器端能直接操作指定玩家）。
//              需要 2026-09-16 及以后编的 exe（player.getId / Player.sit / Player.stand）。

var CHAIR_ID = 210;             // 逻辑 id；被别的模组占了引擎会自动顺延
// 坐下位置（重点）：Player::sitAt(sx,sy,sz) 里的 sy 是【眼睛】的高度 —— 引擎内部
// p->y 就是眼睛（发包时用 y - heightOffset 得到脚底，LocalPlayer.cpp:122；
// 坐下时 heightOffset 变成 0.35，Player.cpp:194）。
// 所以：眼睛 = 方块y + 1.02 → 脚底 = 方块y + 0.67（刚好压在座板顶面 9/16=0.5625 上），
// 而且眼睛在方块顶面【之上】—— 否则相机会落在椅子方块内部，第一人称就是一片黑。
var SEAT_EYE = 1.02;            // 眼睛相对方块底面的高度（= 座板顶 0.5625 + 坐下眼高 0.35 + 余量）
var SEAT_TOP = 10.0 / 16.0;     // 座板顶面（= model 里座板的 y+h = 8+2 = 10）；坐下时脚底 0.67 刚好压在它上面
var SEAT_TEX = "blocks/chair.png";
var TAG = "\u00a7e[椅子]\u00a7r ";

// 按哪个键坐下。用 J 不用 P —— P 被引擎占了：Minecraft.cpp:1001 会“时间+1000”、
// :1070 会切换线框渲染（画面会变线框）；B(67)/G(71)/M(77)/K(75 是时间控制模组) 也各有用途。
// 想换键就改这一行（Keyboard.h 里 A=65 … Z=90，可直接写字母码）。
var KEY_SEAT = 74;              // Keyboard::KEY_J
var KEY_SPACE = 32;

var seats = {};                 // 玩家 id -> {x,y,z}：谁坐在哪把椅子上

function log(msg) { modLog("[chair] " + msg); }

// 聊天提示。客户端 player.sendMessage 能用；独立服务器上它是空实现，
// 所以联机时按 P 的人看不到这句提示（但坐下的动作是生效的）。
function notify(msg) {
	if (typeof player !== "undefined" && player && typeof player.sendMessage === "function")
		player.sendMessage(TAG + msg);
	log(msg);
}

// 本次事件里的那个玩家（按键的人）
function eventPlayerId() {
	if (typeof player === "undefined" || !player) return -1;
	if (typeof player.getId !== "function") return -1;   // 旧 exe 没这个 API
	return player.getId();
}

// 按 id 坐/站是 2026-09-16 新加的引擎 API；旧 exe 上没有 —— 先探测再调，别直接崩。
function hasSeatApi() {
	return typeof Player !== "undefined" && Player &&
	       typeof Player.sit === "function" && typeof Player.stand === "function";
}

function chairReady() {
	return typeof CHAIR === "number" && CHAIR > 0;
}

// 坐在这个坐标上的人是谁（返回 id 或 null）
function chairAt(x, y, z) {
	var pid;
	for (pid in seats) {
		var s = seats[pid];
		if (s && s.x === x && s.y === y && s.z === z) return parseInt(pid, 10);
	}
	return null;
}

function sitDown(pid, x, y, z) {
	// 坐到方块正中间、座板顶面高度（Player::sitAt 会把玩家脚底放在这个坐标）
	// 注意给的是【眼睛】的高度，不是脚底（见 SEAT_EYE 注释）
	Player.sit(pid, x + 0.5, y + SEAT_EYE, z + 0.5);
	seats[pid] = { x: x, y: y, z: z };
}

function standUp(pid) {
	Player.stand(pid);
	delete seats[pid];
}

// ---------------------------------------------------------------------------
// 找椅子
//
// 模组里没有"准星指向哪个方块"的 API，所以自己沿视线步进采样 level.getBlock。
// 方向公式照抄引擎 Mob::getViewVector（Mob.cpp:957）：
//   yCos = cos(-yRot * DEGRAD - PI);  ySin = sin(-yRot * DEGRAD - PI);
//   xCos = -cos(-xRot * DEGRAD);      xSin = sin(-xRot * DEGRAD);
//   dir  = (ySin * xCos, xSin, yCos * xCos)
// ---------------------------------------------------------------------------
function aimedCoord(range) {
	if (!chairReady()) return null;
	if (typeof level === "undefined" || !level || typeof level.getBlock !== "function") return null;
	if (typeof player === "undefined" || !player) return null;

	var D = Math.PI / 180;
	var yrot = player.getYRot(), xrot = player.getXRot();
	var yCos = Math.cos(-yrot * D - Math.PI), ySin = Math.sin(-yrot * D - Math.PI);
	var xCos = -Math.cos(-xrot * D), xSin = Math.sin(-xrot * D);
	var dx = ySin * xCos, dy = xSin, dz = yCos * xCos;

	// 起点：眼睛（站立眼高 1.62；坐下时用不到这条路径）
	var ex = player.getX(), ey = player.getY() + 1.62, ez = player.getZ();
	var lastKey = "", t, bx, by, bz, key;
	for (t = 0.3; t <= range; t += 0.1) {
		bx = Math.floor(ex + dx * t);
		by = Math.floor(ey + dy * t);
		bz = Math.floor(ez + dz * t);
		key = bx + "," + by + "," + bz;
		if (key === lastKey) continue;              // 同一格不重复查
		lastKey = key;
		if (level.getBlock(bx, by, bz) !== 0)
			return { x: bx, y: by, z: bz, id: level.getBlock(bx, by, bz) };
	}
	return null;
}

// 兜底：准星没对上椅子时，找玩家身边最近的那把
function nearestChair(radius) {
	if (!chairReady()) return null;
	if (typeof level === "undefined" || !level || typeof level.getBlock !== "function") return null;
	if (typeof player === "undefined" || !player) return null;

	var px = Math.floor(player.getX()), py = Math.floor(player.getY()), pz = Math.floor(player.getZ());
	var best = null, bestD = 1e9, x, y, z, d;
	for (x = px - radius; x <= px + radius; x++)
		for (y = py - radius; y <= py + radius; y++)
			for (z = pz - radius; z <= pz + radius; z++) {
				if (level.getBlock(x, y, z) !== CHAIR) continue;
				d = (x - px) * (x - px) + (y - py) * (y - py) + (z - pz) * (z - pz);
				if (d < bestD) { bestD = d; best = { x: x, y: y, z: z }; }
			}
	return best;
}

// ---------------------------------------------------------------------------
// 按 P：坐下 / 起身
// ---------------------------------------------------------------------------
function toggleSeat() {
	if (!hasSeatApi()) { notify("这个程序还是旧的，坐下功能要新程序(2026-09-16 之后)"); return; }
	var pid = eventPlayerId();
	if (pid <= 0) { notify("拿不到你的玩家 id，坐不了"); return; }

	if (seats[pid]) {                    // 正坐着 -> 起身
		standUp(pid);
		notify("起身");
		return;
	}

	var hit = aimedCoord(4.5);
	if (hit && hit.id === CHAIR) {
		sitDown(pid, hit.x, hit.y, hit.z);
		notify("坐下（再按 J 或空格起身）");
		return;
	}
	var near = nearestChair(2);           // 准星没对上就找身边最近的
	if (near) {
		sitDown(pid, near.x, near.y, near.z);
		notify("坐下（再按 J 或空格起身）");
		return;
	}
	notify("没找到椅子 —— 把准星对着椅子再按 J");
}

function onKey(key, down) {
	if (!down) return;
	if (key === KEY_SEAT) { toggleSeat(); return; }
	if (key === KEY_SPACE) {              // 坐着按空格也能起身
		if (!hasSeatApi()) return;
		var pid = eventPlayerId();
		if (pid > 0 && seats[pid]) { standUp(pid); notify("起身"); }
	}
}

// ---------------------------------------------------------------------------
// 方块：座板 + 靠背 + 四条腿。每个部件都要显式给贴图（不给是空的）。
// 刻意**不注册 onUse** —— 右键保持原样（放置/破坏/交互都不受影响）。
// ---------------------------------------------------------------------------
var CHAIR = Block.defineBlock(CHAIR_ID, {
	name: "椅子",
	texture: SEAT_TEX,
	material: "wood",
	renderLayer: "alphatest",             // 模型里有透明区域
	model: [
		// 注意：整个椅子比“座板贴地”的版本抬高了 1 像素。原因是坐下时眼睛有下限
		// （必须高于方块顶面，否则第一人称黑屏），眼睛离脚底又只有 0.35，
		// 所以脚底最低只能到 0.67 —— 把座板顶面放到 10/16=0.625 才刚好垫在脚底下面。
		{ name: "seat", box: [2,  8,  2, 12, 2, 12], texture: SEAT_TEX },  // 座板（顶面 y=10 → 0.625）
		{ name: "back", box: [2, 10, 12, 12, 6,  2], texture: SEAT_TEX },  // 靠背
		{ name: "leg1", box: [3,  0,  3,  2, 8,  2], texture: SEAT_TEX },
		{ name: "leg2", box: [11, 0,  3,  2, 8,  2], texture: SEAT_TEX },
		{ name: "leg3", box: [3,  0, 11,  2, 8,  2], texture: SEAT_TEX },
		{ name: "leg4", box: [11, 0, 11,  2, 8,  2], texture: SEAT_TEX }
	],

	// 椅子被拆掉：坐在上面的人得站起来，不然会悬空
	onRemove: function (x, y, z) {
		var pid = chairAt(x, y, z);
		if (pid === null || !hasSeatApi()) return;
		standUp(pid);
		log("椅子被拆掉，让 id=" + pid + " 的玩家起身");
	}
});

log("椅子已注册：物理 id=" + CHAIR + "（逻辑 id " + CHAIR_ID + "）；按 J 坐");

// 换世界/重连后清一遍记录（位置已经无效了），顺便告诉玩家怎么坐
function onJoinWorld() {
	seats = {};
	if (typeof isClient !== "undefined" && isClient)
		notify("对着椅子按 J 坐下（再按 J 或空格起身）");
}

// name: 通用服务器命令
// author: coj2
// version: 1.1.0
// environment: both
// description: 服务器 / 主机 / 单机通用命令 mod —— /list /dim /home /kick /say /tp /time /seed /save /mods /modlist /op /deop /ops
// 权限:需要 OP 的命令会先用 level.isOp(发送者) 检查(ops.txt 名单);
//       服务器后台(控制台)永远有 OP,本机主人(单人/自己开服)默认有 OP。
//       只使用游戏已有的 mod API(level.* / mods.* / player.*),同一个 zip 客户端/服务端通用。

var DAY_TIME = 1000;
var NIGHT_TIME = 14000;

function say(s) {
	if (typeof level.broadcast === "function")
		level.broadcast(s);
	else if (typeof player !== "undefined" && player)
		player.sendMessage(s);
	else
		modLog(s);
}

function allPlayers() {
	return (typeof level.listPlayers === "function") ? level.listPlayers() : [];
}

function findPlayer(name) {
	if (!name)
		return null;
	var all = allPlayers();
	var want = String(name).toLowerCase();
	for (var i = 0; i < all.length; i++) {
		var n = (all[i].name || "").toLowerCase();
		if (n == want || n.indexOf(want) == 0)
			return all[i];
	}
	var id = parseInt(name, 10);
	if (!isNaN(id)) {
		for (var j = 0; j < all.length; j++)
			if (all[j].id == id)
				return all[j];
	}
	return null;
}

function playerListText() {
	var all = allPlayers();
	var out = [];
	for (var i = 0; i < all.length; i++)
		out.push(all[i].name + " (id " + all[i].id + ", dim " + all[i].dim + (all[i].local ? ", 主机" : "") + ")");
	return out.length ? out.join(" | ") : "无";
}

// actorId: 命令执行者的 entity id;-1 / 省略 = 服务器后台(控制台)
function isActorOp(actorId) {
	if (typeof actorId !== "number" || actorId < 0)
		return true;                       // 后台永远有 OP
	if (typeof level.isOp === "function")
		return level.isOp(actorId);        // 引擎判定:本机主人 / ops.txt 名单
	return false;
}

function requireOp(actorId, what) {
	if (isActorOp(actorId))
		return true;
	say("§c你没有 OP 权限,不能使用 " + what + "(可以找管理员把你加进 ops.txt)");
	return false;
}

function usage(actorId) {
	say("§e命令: §f/list §7· §f/seed §7· §f/mods §7· §f/home §7· §f/help");
	if (isActorOp(actorId))
		say("§eOP: §f/dim <玩家> <维度> §7· §f/home [玩家] §7· §f/kick <玩家> [原因] §7· §f/say <消息> §7· §f/tp <玩家> <x> <y> <z>");
	if (isActorOp(actorId))
		say("§eOP: §f/time set <day|night> §7· §f/save §7· §f/modlist export §7· §f/op <玩家> §7· §f/deop <玩家>");
}

function enterDimension(p, dim) {
	var x = Math.floor(p.x) + 0.5;
	var y = Math.max(Math.floor(p.y), 80) + 0.5;
	var z = Math.floor(p.z) + 0.5;
	if (typeof level.changePlayerDimension !== "function")
		return false;
	level.changePlayerDimension(p.id, dim, x, y, z);
	return true;
}

function runCommand(input, actorId) {
	var s = String(input || "").replace(/^\//, "").replace(/^\s+|\s+$/g, "");
	if (!s)
		return false;

	var parts = s.split(/\s+/);
	var cmd = parts[0].toLowerCase();
	var rest = parts.slice(1);

	// ---- 所有人可用 ----
	if (cmd == "list") {
		say("§a在线玩家 (" + allPlayers().length + "): " + playerListText());
		return true;
	}

	if (cmd == "seed") {
		var sd = (typeof level.getSeed === "function") ? level.getSeed() : "?";
		say("§a世界种子: " + sd);
		return true;
	}

	if (cmd == "mods") {
		var list = (typeof mods !== "undefined" && typeof mods.list === "function") ? mods.list() : [];
		say("§a已启用 mod (" + list.length + "): " + (list.join(", ") || "无"));
		return true;
	}

	if (cmd == "ops") {
		var ops = (typeof level.listOps === "function") ? level.listOps() : [];
		say("§aOP 名单 (" + ops.length + "): " + (ops.join(", ") || "无"));
		return true;
	}

	if (cmd == "help") {
		usage(actorId);
		return true;
	}

	// ---------------------------------------------------------------
	// ---- 以下需要 OP ----
	// ---------------------------------------------------------------
	if (cmd == "say") {
		if (!requireOp(actorId, "/say")) return true;
		if (!rest.length) { usage(actorId); return true; }
		say("§e[服务端] §f" + rest.join(" "));
		return true;
	}

	if (cmd == "save") {
		if (!requireOp(actorId, "/save")) return true;
		if (typeof level.saveAll === "function")
			level.saveAll();
		say("§a世界已保存");
		return true;
	}

	if (cmd == "time-speed" || cmd == "timespeed") {
		if (!requireOp(actorId, "/time-speed")) return true;
		if (!rest.length) { usage(actorId); return true; }
		var sp = parseFloat(rest[0]);
		if (isNaN(sp)) { usage(actorId); return true; }
		if (typeof level.setTimeSpeed !== "function") { say("§c该环境不支持"); return true; }
		say(level.setTimeSpeed(sp)
			? ("§a时间速度已设为 " + sp + (sp == 0 ? "(时间冻结)" : ""))
			: "§c设置失败(只有服务端/主机有效)");
		return true;
	}

	if (cmd == "daylight") {
		if (!requireOp(actorId, "/daylight")) return true;
		var on2 = (rest[0] || "").toLowerCase() != "off";
		var ok2 = (typeof level.setDaylightCycle === "function") ? level.setDaylightCycle(on2) : false;
		say(ok2 ? ("§a昼夜更替已" + (on2 ? "开启" : "关闭(时间冻结)")) : "§c设置失败(只有服务端/主机有效)");
		return true;
	}

	if (cmd == "gamemode" || cmd == "gm") {
		if (!requireOp(actorId, "/gamemode")) return true;
		if (!rest.length) { say("§e用法: /gamemode <creative|survival> [玩家]"); return true; }
		var m = (rest[0] || "").toLowerCase();
		var cr = (m == "creative" || m == "c" || m == "1" || m == "创造");
		if (typeof level.setGameMode !== "function") { say("§c该环境不支持"); return true; }
		if (rest.length > 1) {
			// 只改某一个人(他自己重连后生效)
			var who = findPlayer(rest[1]);
			var whoName = who ? who.name : rest[1];
			level.setGameMode(cr ? "creative" : "survival", whoName);
			say("§a已把 " + whoName + " 设为" + (cr ? "创造" : "生存") + "§7(他重连后生效)");
			return true;
		}
		level.setGameMode(cr ? "creative" : "survival");
		say("§a全服游戏模式已设为 " + (cr ? "创造" : "生存") + "§7(已在线玩家重连后生效)");
		return true;
	}

	if (cmd == "spawn") {
		if (!requireOp(actorId, "/spawn")) return true;
		if (rest.length < 2) { say("§e用法: /spawn <on|off> [all|monsters|animals]"); return true; }
		var want = (rest[0] || "").toLowerCase() != "off";
		var what = (rest[1] || "all").toLowerCase();
		if (typeof level.setMobSpawning !== "function") { say("§c该环境不支持"); return true; }
		var ok3 = (what == "monsters") ? level.setMobSpawning(want, true)
		        : (what == "animals")  ? level.setMobSpawning(true, want)
		        : level.setMobSpawning(want, want);
		say(ok3 ? ("§a刷怪(" + what + ")已" + (want ? "开启" : "关闭")) : "§c设置失败");
		return true;
	}

	if (cmd == "time") {
		var sub = (rest[0] || "").toLowerCase();
		if (sub == "set") {
			if (!requireOp(actorId, "/time set")) return true;
			var when = (rest[1] || "").toLowerCase();
			var t = (when == "night") ? NIGHT_TIME : (when == "day" ? DAY_TIME : parseInt(when, 10));
			if (isNaN(t)) { usage(actorId); return true; }
			if (typeof level.setTime === "function")
				level.setTime(t);
			say("§a时间已设为 " + t + (when == "night" ? " (夜晚)" : (when == "day" ? " (白天)" : "")));
			return true;
		}
		var now = (typeof level.getTime === "function") ? level.getTime() : "?";
		say("§a当前时间: " + now);
		return true;
	}

	if (cmd == "home") {
		// 自己回家不需要 OP;把别人送回去需要 OP
		var hp = rest.length ? findPlayer(rest[0]) : null;
		if (rest.length && !requireOp(actorId, "/home <玩家>")) return true;
		if (!hp) {
			var all = allPlayers();
			for (var i = 0; i < all.length; i++)
				if (all[i].local) hp = all[i];
			if (!hp && actorId >= 0)
				for (var k = 0; k < all.length; k++)
					if (all[k].id == actorId) hp = all[k];
		}
		if (!hp) { say("§c找不到玩家"); return true; }
		if (hp.id != actorId && !requireOp(actorId, "/home <玩家>")) return true;
		say(enterDimension(hp, 0) ? ("§a已把 " + hp.name + " 送回主世界") : "§c该环境不支持切换维度");
		return true;
	}

	if (cmd == "dim") {
		if (!requireOp(actorId, "/dim")) return true;
		if (rest.length < 2) { usage(actorId); return true; }
		var tp = findPlayer(rest[0]);
		var dim = parseInt(rest[1], 10);
		if (!tp) { say("§c找不到玩家: " + rest[0]); return true; }
		if (isNaN(dim)) { usage(actorId); return true; }
		say(enterDimension(tp, dim) ? ("§a已把 " + tp.name + " 送到维度 " + dim) : "§c该环境不支持切换维度");
		return true;
	}

	if (cmd == "tp") {
		if (!requireOp(actorId, "/tp")) return true;
		if (rest.length < 4) { usage(actorId); return true; }
		var t2 = findPlayer(rest[0]);
		var x = parseFloat(rest[1]), y = parseFloat(rest[2]), z = parseFloat(rest[3]);
		if (!t2) { say("§c找不到玩家: " + rest[0]); return true; }
		if (isNaN(x) || isNaN(y) || isNaN(z) || typeof level.teleportPlayer !== "function") { usage(actorId); return true; }
		if (level.teleportPlayer(t2.id, x, y, z))
			say("§a已把 " + t2.name + " 传送到 " + x + ", " + y + ", " + z);
		else
			say("§c传送失败: " + t2.name);
		return true;
	}

	if (cmd == "kick") {
		if (!requireOp(actorId, "/kick")) return true;
		if (!rest.length) { usage(actorId); return true; }
		var kp = findPlayer(rest[0]);
		if (!kp) { say("§c找不到玩家: " + rest[0]); return true; }
		var reason = rest.slice(1).join(" ");
		var ok = (typeof level.kickPlayer === "function") ? level.kickPlayer(kp.id, reason) : false;
		say(ok ? ("§a已踢出 " + kp.name) : ("§c踢出失败(可能是主机自己或该环境不支持): " + kp.name));
		return true;
	}

	if (cmd == "modlist") {
		var sub2 = (rest[0] || "").toLowerCase();
		if (sub2 == "export") {
			if (!requireOp(actorId, "/modlist export")) return true;
			var ok2 = (typeof mods !== "undefined" && typeof mods.exportList === "function") ? mods.exportList() : false;
			say(ok2 ? "§a已导出 mods/modlist.json" : "§c导出失败");
			return true;
		}
		var l2 = (typeof mods !== "undefined" && typeof mods.list === "function") ? mods.list() : [];
		say("§a" + (l2.join(", ") || "无"));
		return true;
	}

	// ---- OP 名单管理 ----
	if (cmd == "op" || cmd == "deop") {
		if (!requireOp(actorId, "/" + cmd)) return true;
		if (!rest.length) { usage(actorId); return true; }
		var who = rest.join(" ");
		var target = findPlayer(who);
		if (target)
			who = target.name;
		if (typeof level.setOp !== "function") { say("§c该环境不支持 OP 名单"); return true; }
		var wantOp = (cmd == "op");
		if (level.setOp(who, wantOp))
			say("§a" + who + (wantOp ? " 已成为 OP" : " 已被取消 OP"));
		else
			say("§c操作失败: " + who);
		return true;
	}

	return false;
}

// 游戏内聊天输入(/命令)
//   * 单人 / 主机 / 专用服务端:本机就是权威端,直接执行
//   * 加入别人的服务器:命令由服务器那端的 mod 执行(引擎会把 /命令 转发到服务器),
//     本机保持安静,避免出现两份结果。
function onChat(message, playerId) {
	if (!message || message.charAt(0) != "/")
		return false;
	if (typeof level.isHost === "function" && !level.isHost())
		return false;
	if (typeof playerId !== "number" || playerId < 0) {
		// 本地调用(单机/主机):执行者就是本地玩家
		playerId = (typeof player !== "undefined" && player) ? player.entityId : -1;
	}
	return runCommand(message, playerId);
}

// 控制台输入(/命令) —— 由服务器外壳 fireEvent("onServerCommand", cmd) 触发;
// 服务器后台视为最高权限(-1)。
function onServerCommand(line) {
	if (runCommand(line, -1))
		return true;
	say("§c未知命令: " + line + " (输入 /help)");
	return false;
}

modLog("[Cmd] 通用命令 mod 已加载(OP 名单:ops.txt;/op /deop /ops 管理)");

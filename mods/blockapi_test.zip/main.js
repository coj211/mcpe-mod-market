// name: 方块 API 测试
// author: Reasonix
// version: 1.0
// description: 一次性测完 自定义方块模型(3D/2D/多部件) · 方块动画 · 自定义放置 · 微方块
//
// 打开创造模式物品栏，找这几个方块：
//   竖半砖 / 贴地线 / 贴画板 / 魔书台 / 旋转水晶 / 开合箱 / 微方块

// ===========================================================================
// 1) 竖半砖 —— 对着哪一面放，半砖就贴在哪一面（placeData 决定数据值）
//    0=下半 1=上半 2=北半 3=南半 4=西半 5=东半
// ===========================================================================
var OPPOSITE = [1, 0, 3, 2, 5, 4];   // 点击面 -> 半砖贴目标格里的哪一侧
var SLAB = Block.defineBlock(200, {
    name: "竖半砖",
    texture: "blocks/slab.png",
    material: "rock",
    renderLayer: "alphatest",
    model: [
        { name: "d0", box: [0, 0, 0, 16, 8, 16],  data: 0 },
        { name: "d1", box: [0, 8, 0, 16, 8, 16],  data: 1 },
        { name: "d2", box: [0, 0, 0, 16, 16, 8],  data: 2 },
        { name: "d3", box: [0, 0, 8, 16, 16, 8],  data: 3 },
        { name: "d4", box: [0, 0, 0, 8, 16, 16],  data: 4 },
        { name: "d5", box: [8, 0, 0, 8, 16, 16],  data: 5 }
    ],
    placeData: function (x, y, z, face, cx, cy, cz) {
        return OPPOSITE[face];
    }
});

// ===========================================================================
// 2) 贴地线 —— 2D 平面（box 的 y 宽度为 0），按数据值换形状
//    部件用 data: [...] 声明"只在这些数据值时画" -> 同一个方块换外形
// ===========================================================================
var WIRE = Block.defineBlock(201, {
    name: "贴地线",
    texture: "blocks/wire.png",
    material: "plant",
    renderLayer: "alphatest",
    model: [
        { name: "ew",  box: [0, 0.5, 6, 16, 0, 4], data: [0, 2] },
        { name: "ns",  box: [6, 0.5, 0, 4, 0, 16], data: [1, 2] },
        { name: "hub", box: [6, 0.5, 6, 4, 0, 4],  data: [2] }
    ],
    // 按点击点在格内的位置决定走向：0 = 东西向，1 = 南北向，2 = 十字
    placeData: function (x, y, z, face, cx, cy, cz) {
        var ex = Math.abs(cx - 0.5), ez = Math.abs(cz - 0.5);
        if (ex > 0.3 && ez > 0.3) return 2;
        return ex >= ez ? 0 : 1;
    }
});

// ===========================================================================
// 3) 贴画板 —— 2D 贴在格子中间的一个平面上（z 宽度为 0 -> 正反两面都画）
// ===========================================================================
var PANEL = Block.defineBlock(202, {
    name: "贴画板",
    texture: "blocks/panel.png",
    material: "wood",
    renderLayer: "alphatest",
    model: [
        { name: "art", box: [1, 1, 7, 14, 14, 0] }
    ],
    collision: false
});

// ===========================================================================
// 4) 魔书台 —— 3D 多部件（底座 + 四条腿 + 发光面 + 歪着的书）
// ===========================================================================
var ALTAR = Block.defineBlock(203, {
    name: "魔书台",
    texture: "blocks/altar.png",
    material: "rock",
    renderLayer: "alphatest",
    model: [
        { name: "base", box: [0, 0, 0, 16, 3, 16] },
        { name: "leg1", box: [0, 3, 0, 3, 8, 3],   uv: "crop" },
        { name: "leg2", box: [13, 3, 0, 3, 8, 3],  uv: "crop" },
        { name: "leg3", box: [0, 3, 13, 3, 8, 3],  uv: "crop" },
        { name: "leg4", box: [13, 3, 13, 3, 8, 3], uv: "crop" },
        { name: "glow", box: [3, 3, 3, 10, 1, 10], texture: "blocks/glow.png", emissive: true },
        { name: "book", box: [5, 10, 6, 6, 1, 4],  texture: "blocks/book.png",
          pivot: [8, 10, 8], rot: [0, -25, 0] }
    ]
});

// ===========================================================================
// 5) 旋转水晶 / 开合箱 —— 方块动画（anim 每帧给部件姿态）
//    anim(part, age, time) 返回 {x,y,z} 弧度（可选 px,py,pz 格内平移）
// ===========================================================================
var CRYSTAL = Block.defineBlock(204, {
    name: "旋转水晶",
    texture: "blocks/crystal.png",
    material: "rock",
    renderLayer: "alphatest",
    light: 10,
    model: [
        { name: "base",    box: [2, 0, 2, 12, 2, 12], texture: "blocks/altar.png" },
        { name: "crystal", box: [6, 4, 6, 4, 8, 4],   emissive: true },
        { name: "ring",    box: [1, 7.5, 1, 14, 0, 14], texture: "blocks/panel.png" }
    ],
    anim: function (part, age, time) {
        if (part === "crystal") return { x: 0, y: time * 1.5, z: 0 };
        if (part === "ring")    return { x: Math.sin(time * 2) * 0.6, y: time * 2.0, z: 0 };
        return null;
    }
});

var BOX = Block.defineBlock(205, {
    name: "开合箱",
    texture: "blocks/box_side.png",
    material: "wood",
    renderLayer: "alphatest",
    model: [
        { name: "body", box: [1, 0, 1, 14, 9, 14], texture: "blocks/box_side.png" },
        { name: "lid",  box: [1, 9, 1, 14, 4, 14], texture: "blocks/box_top.png",
          pivot: [8, 9, 1] }
    ],
    anim: function (part, age, time) {
        if (part !== "lid") return null;
        var t = (time % 6) / 3;          // 0..2
        var open = t < 1 ? t : (2 - t);  // 0 -> 1 -> 0
        return { x: open * 1.3, y: 0, z: 0 };
    }
});

// ===========================================================================
// 6) 微方块 —— 一个方块格里摆 4×4×4 个小方块（自定义放置 + 格内几何）
//    这个方块格本身是**隐形**的：不画几何、也不贡献碰撞；外观和碰撞
//    完全来自 geom 里的小方块。第一块靠"点别的方块的面"放进来
//    （目标格是那个空格），之后点在已有小方块上就能继续往同一格里加。
//    micro:true 表示"我的外观来自方块实体数据 geom"，
//    geom 格式： "x y z w h d tex"（像素；tex = -1 用方块自己的贴图，
//    或 Block.injectTexture 拿到的槽号），多个小方块用 '|' 分隔。
// ===========================================================================
var MICRO_N = 4;                    // 每格切成 4×4×4 个小格
// 微方块的两种材质：Block.injectTexture 把 zip 里的 png 塞进 terrain 贴图集，
// 返回槽号 —— geom 里的 tex 字段就是它（同一格里可以混用不同材质的小方块）。
var T_STONE = Block.injectTexture("blocks/slab.png");
var T_WOOD = Block.injectTexture("blocks/micro.png");
var MICRO = Block.defineBlock(206, {
    name: "微方块",
    texture: "blocks/micro.png",     // 只用于物品栏里那个图标
    material: "wood",
    renderLayer: "alphatest",
    micro: true                      // 方块格本身不画几何、不留碰撞
});

// 接管放置：点哪就往哪长一小块。
// 算法和原版放方块一致 —— 命中点先落到某个子格上，再沿"你点的那一面"
// 往外推一格；推出本格就挪到相邻格。所以点顶面往上长、点底面往下长、
// 点侧面就往那一侧长（以前只在本格里找位置，所以"下面/左面"点不动）。
function onPlaceAttempt(x, y, z, face, cx, cy, cz, itemId, yRot, pitch) {
    if (itemId !== MICRO) return false;

    var N = MICRO_N;
    // 命中点量化成子格（+1e-4 是为了避开"正好落在面上"的浮点误差）。
    // 边界归属：点在朝外的面（上/南/东）上时，floor 已经跳到外面那一格，
    // 不用再动；只有朝内的面（下/北/西）的边界值还落在本格内，要缩回一格。
    var ix = Math.floor(cx * N + 1e-4);
    var iy = Math.floor(cy * N + 1e-4);
    var iz = Math.floor(cz * N + 1e-4);
    if (face === 0) iy -= 1;
    else if (face === 2) iz -= 1;
    else if (face === 4) ix -= 1;

    var tx = x, ty = y, tz = z;
    while (ix < 0)  { ix += N; tx--; }
    while (ix >= N) { ix -= N; tx++; }
    while (iy < 0)  { iy += N; ty--; }
    while (iy >= N) { iy -= N; ty++; }
    while (iz < 0)  { iz += N; tz--; }
    while (iz >= N) { iz -= N; tz++; }

    var at = level.getBlock(tx, ty, tz);
    if (at !== 0 && at !== MICRO) return false;    // 那一格被别的方块占了
    if (at === 0) level.setBlock(tx, ty, tz, MICRO);

    var unit = 16 / N;
    var tex = ((ix + iy + iz) % 2) ? T_WOOD : T_STONE;
    var part = (ix * unit) + " " + (iy * unit) + " " + (iz * unit) + " "
             + unit + " " + unit + " " + unit + " " + tex;
    var d = level.getBlockEntityData(tx, ty, tz);
    var cur = (d && d.geom) ? d.geom : "";
    if (cur.indexOf(part) >= 0) return true;       // 这个子格已经有了
    level.setBlockEntityData(tx, ty, tz, "geom", cur ? (cur + "|" + part) : part);
    modLog("微方块: " + tx + "," + ty + "," + tz + " 子格 " + ix + "," + iy + "," + iz);
    return true;
}

// 挖掉单个小方块：点中哪一块就删哪一块（返回 true = 引擎不拆整个方块）。
// 注：modLog() 是模组的日志接口（写进模组的日志文件，每秒限流 20 条）；
// 想排查问题打它就行，不用改游戏本体。
var _lastBreakTick = -9999;
function onBreakAttempt(x, y, z, face, cx, cy, cz) {
    if (level.getBlock(x, y, z) !== MICRO) return false;
    var d = level.getBlockEntityData(x, y, z);
    var geom = (d && d.geom) ? d.geom : "";
    if (!geom) return false;

    var t = level.getTicks();
    if (t - _lastBreakTick < 1) return true;   // 同一游戏刻只挖一块

    var hx = cx * 16, hy = cy * 16, hz = cz * 16;
    var list = geom.split("|");
    var hitIdx = -1, nearIdx = -1, nearD = 1e9;
    for (var i = 0; i < list.length; i++) {
        var f = list[i].split(" ");
        if (f.length < 6) continue;
        var px = parseFloat(f[0]), py = parseFloat(f[1]), pz = parseFloat(f[2]);
        var w = parseFloat(f[3]), h = parseFloat(f[4]), dep = parseFloat(f[5]);
        var cxx = px + w / 2, cyy = py + h / 2, czz = pz + dep / 2;
        var dx = cxx - hx, dy = cyy - hy, dz = czz - hz;
        var dd = dx * dx + dy * dy + dz * dz;
        if (dd < nearD) { nearD = dd; nearIdx = i; }
        if (hitIdx < 0 && hx >= px && hx <= px + w && hy >= py && hy <= py + h &&
            hz >= pz && hz <= pz + dep)
            hitIdx = i;
    }
    var target = (hitIdx >= 0) ? hitIdx : nearIdx;   // 没精确命中就挖最近那块
    if (target < 0) return true;

    var kept = [];
    for (var i = 0; i < list.length; i++)
        if (i !== target) kept.push(list[i]);

    _lastBreakTick = t;
    if (kept.length === 0) {
        level.setBlock(x, y, z, 0);                  // 挖空了：连容器一起清掉
    } else {
        level.setBlockEntityData(x, y, z, "geom", kept.join("|"));
    }
    return true;
}

function onJoinWorld() {
    player.sendMessage("方块 API 测试模组已加载："
                       + "竖半砖(对着哪面放就贴哪面) / "
                       + "贴地线(加一个变一种形状) / "
                       + "贴画板 / 魔书台 / 旋转水晶 / "
                       + "开合箱 / 微方块(反复点同一格叠小方块)");
    player.sendMessage("另外：原版画现在左右两面各能挂一幅；"
                       + "「双画挂饰」点一下会一次挂两幅画；"
                       + "左键点微方块可以一块一块挖掉");
}

// ===========================================================================
// 7) 双画挂饰 —— 一次挂两幅画（自定义放置 + 悬挂实体 API）
//    原版画现在也能左右两面各挂一幅了（引擎放宽了“一格只能一幅”的限制）；
//    这个物品演示的是“模组完全自己决定放什么、放哪、放几幅”。
// ===========================================================================
var PAINTING_WAND = Item.defineItem(240, {
    name: "双画挂饰",
    icon: "blocks/panel.png",
    onUse: function (x, y, z, face) {
        // dir: 0=南 1=西 2=北 3=东（画贴在被点方块的这一面）
        // 先试一对相对的方向（南+北），挂不上再试另一对（西+东）。
        var pairs = [[0, 2], [1, 3]];
        var ok = 0;
        for (var p = 0; p < pairs.length && ok === 0; p++) {
            for (var i = 0; i < 2; i++) {
                if (level.spawnPainting(x, y, z, pairs[p][i], "Kebab") >= 0)
                    ok++;
            }
        }
        player.sendMessage("双画挂饰：挂上了 " + ok
                           + " 幅画（level.spawnPainting 一次多幅）");
        return true;
    }
});

// name: 指令系统测试套件
// author: coj2
// version: 2.0.0
// environment: both
// description: 模组指令系统三合一 = 框架(注册/别名/参数解析/op 门禁/统一回话) + 自检(/ct run)
//              + 一小套实用指令(/ct help info pos players tp here dim give set kill time).
//              只用引擎里真实存在的 API(已逐条核对 ModEngine.cpp),
//              不碰任何不存在的 level.broadcast / teleportPlayer / getSeed / setOp / kickPlayer.
//
// [回话通道说明(重要,决定了某些现象)]
//   引擎里模组"把话回给执行者"只有一条路:Commands.register 那个处理函数的返回值.
//   客户端(单机/房主)走 gui.addMessage,独立服务器走 sendMessageTo.
//   player.sendMessage 在独立服务器下是空实现(ModEngine.cpp:352-360),
//   所以本模组在服务器端只能靠引擎通道回话,自己发不出去.
//   为此本模组采用"引擎通道优先 + 自适应兜底":
//     - 引擎通道(Commands.register):正路.用 SetEventPlayer 无关,两端都行.
//     - onChat 兜底:只在"引擎通道还没被证明可用"时接管,且只在客户端启用
//       (服务器端兜底既回不了话,又认不出执行者,纯属半残 -- 不启用).
//     一旦引擎调用过本模组的注册函数(ENGINE_ALIVE=true),onChat 就永久让位,
//     绝不重复执行副作用,绝不重复回话.
//
// [子命令名一律大小写不敏感;但"指令名"本身由引擎精确匹配,大小写敏感(/CT 不会命中)]

var MOD_NAME    = "指令系统测试套件";
var MOD_VERSION = "2.0.0";
var MOD_BUILD   = "2026-09-16";
// 2026-09-16 起引擎的字体渲染修好了：§ 颜色码会真正生效（原版 16 色），
// 常用全角标点也进了字形表 —— 所以这里可以正常用颜色和中文标点。
// （修复前：字形表只有 6763 个 GB2312 汉字，别的码点会被画成 atlas 第 0 格
//  「一」（一条横杠）；颜色码还会被拆开、漏出后面的格式字符。）
var MOD_TAG     = "\u00a7b[" + MOD_NAME + "]\u00a7r ";

var C_OK   = "\u00a7a";
var C_ERR  = "\u00a7c";
var C_INFO = "\u00a7e";
var C_DIM  = "\u00a77";
var C_HI   = "\u00a7f";
var C_USE  = "\u00a7e用法： \u00a7f";

function log(msg) { modLog("[cmdkit] " + msg); }
function tag(msg) { return MOD_TAG + msg; }

// ---------------------------------------------------------------------------
// 运行环境
// ---------------------------------------------------------------------------
var ENV_IS_SERVER = (typeof isServer !== "undefined") && !!isServer;
var ENV_IS_CLIENT = (typeof isClient !== "undefined") && !!isClient;
var ENV_TEXT = ENV_IS_SERVER ? "独立服务器" : (ENV_IS_CLIENT ? "客户端(单机/房主)" : "未知");

// 模组注册到引擎的命令名(同一个处理函数注册两个名字,顺便测引擎的多名字处理)
var ENGINE_REGS = ["ct", "cmdkit", "help"];

// 没有子命令的注册名 -> 整段参数直接交给某个子命令。
// 玩家最可能直接敲 /help，所以给它单独一个注册名（/help [页码]）。
var DIRECT_CMDS = { "help": "help" };

function isOurCommand(name) {
	var n = s(name).toLowerCase(), i;
	for (i = 0; i < ENGINE_REGS.length; i++)
		if (ENGINE_REGS[i] === n) return true;
	return false;
}

// ---------------------------------------------------------------------------
// 小工具
// ---------------------------------------------------------------------------
function s(v) { return (v === null || v === undefined) ? "" : String(v); }
function trim(x) { return s(x).replace(/^\s+|\s+$/g, ""); }

function splitArgs(raw) {
	var t = trim(raw);
	if (!t) return [];
	// 连续空白算一个分隔;支持 "双引号包起来的 一整段"(Duktape 是 ES5,不能靠模板字面量)
	var out = [], cur = "", inQuote = false, i, ch;
	for (i = 0; i < t.length; i++) {
		ch = t.charAt(i);
		if (ch === '"') { inQuote = !inQuote; continue; }
		if (!inQuote && (ch === " " || ch === "\t")) {
			if (cur) { out.push(cur); cur = ""; }
			continue;
		}
		cur += ch;
	}
	if (cur) out.push(cur);
	return out;
}

function joinArgs(a, from) {
	var out = [], i;
	for (i = from; i < a.length; i++) out.push(a[i]);
	return out.join(" ");
}

// 切出第一个词(子命令名)和剩余原文.
// 引擎通道传进来的 raw 是'子命令 + 参数'的整段(例如 "tp Steve 1 2 3"),
// 所以子命令名要在这里切;而 tail 保留原文(含引号),交给子命令自己再切.
function splitFirst(raw) {
	var t = s(raw), i = 0, j;
	while (i < t.length && (t.charAt(i) === " " || t.charAt(i) === "\t")) i++;
	j = i;
	while (j < t.length && t.charAt(j) !== " " && t.charAt(j) !== "\t") j++;
	var k = j;
	while (k < t.length && (t.charAt(k) === " " || t.charAt(k) === "\t")) k++;
	return { head: t.substring(i, j), tail: t.substring(k) };
}

function isNumStr(v) {
	if (v === null || v === undefined || v === "") return false;
	var n = parseFloat(v);
	return !isNaN(n) && isFinite(n);
}

function toInt(v, dflt) {
	if (!isNumStr(v)) return dflt;
	return Math.floor(parseFloat(v));
}

function toFloat(v, dflt) {
	if (!isNumStr(v)) return dflt;
	return parseFloat(v);
}

function fmtNum(n) {
	var r = Math.round(n * 10) / 10;
	return s(r);
}

function b2s(b) { return b ? "是" : "否"; }

// ---------------------------------------------------------------------------
// 玩家查询
//
// level.listPlayers() 在**纯客户端**返回空数组(ModEngine.cpp:2186-2191),
// 而 Player.list() 在客户端返回自己和远端玩家(ModEngine.cpp:2513-2535),
// 所以优先用 Player.list(),它两端都能用.
// ---------------------------------------------------------------------------
function allPlayers() {
	var l, i, out = [];
	if (typeof Player !== "undefined" && Player && typeof Player.list === "function") {
		l = Player.list();
		if (l && l.length) return l;
	}
	if (typeof level !== "undefined" && level && typeof level.listPlayers === "function") {
		l = level.listPlayers();
		if (l && l.length) return l;
	}
	return out;
}

// 本机玩家快照(独立服务器上恒为 null)
function localSnapshot() {
	if (typeof Player === "undefined" || !Player || typeof Player.self !== "function") return null;
	var p = Player.self();
	if (!p || typeof p.id !== "number") return null;
	return p;
}

function playerText(p) {
	return s(p.name) + " (id " + p.id + ", " + fmtNum(p.x) + " " + fmtNum(p.y) + " " + fmtNum(p.z) +
	       ", 维度 " + p.dim + (p.local ? ", 本机" : "") + ")";
}

// 按玩家名(大小写不敏感,支持前缀)或 id 找人
function findPlayer(token) {
	var t = trim(token);
	if (!t) return null;
	var list = allPlayers(), i, n, want = t.toLowerCase(), id;
	for (i = 0; i < list.length; i++) {
		n = s(list[i].name).toLowerCase();
		if (n === want) return list[i];
	}
	for (i = 0; i < list.length; i++) {
		n = s(list[i].name).toLowerCase();
		if (n.indexOf(want) === 0) return list[i];
	}
	id = toInt(t, -99999);
	if (id !== -99999) {
		for (i = 0; i < list.length; i++)
			if (list[i].id === id) return list[i];
	}
	return null;
}

// 执行者自己的快照:先按名字查,再退回本机
function selfSnapshot(sender) {
	var p = findPlayer(sender);
	if (p) return p;
	return localSnapshot();
}

function namesText() {
	var list = allPlayers(), out = [], i;
	for (i = 0; i < list.length; i++) out.push(s(list[i].name));
	return out.length ? out.join(", ") : "无";
}

function whoText(sender) {
	return trim(sender) ? trim(sender) : "(服务器后台)";
}

// ---------------------------------------------------------------------------
// 权限
//
// ! 引擎的 level.isOp() 收的是**玩家名字**(ModEngine.cpp:2230-2239),不是 id.
//   引擎自己**不会**拦模组注册的指令(拦截只发生在内置指令分支里),
//   所以"要 op"这件事只能模组自己做 -- 本框架的 op:true 就是这个.
// ---------------------------------------------------------------------------
function isOperator(name) {
	var n = trim(name);
	if (!n) return true;   // 服务器后台/控制台:视为最高权限
	if (typeof level !== "undefined" && level && typeof level.isOp === "function")
		return !!level.isOp(n);
	return false;
}

// ---------------------------------------------------------------------------
// 指令框架
// ---------------------------------------------------------------------------
var CMD = {};        // 主名 -> 定义
var ALIAS = {};      // 别名 -> 定义
var CMD_LIST = [];   // 按注册顺序,供 /ct help 用
var ALIAS_COUNT = 0;

function defineCmd(def) {
	var d = {
		name:    s(def.name).toLowerCase(),
		usage:   s(def.usage),
		desc:    s(def.desc),
		op:      !!def.op,
		throws:  !!def.throws,      // true = 故意把异常抛给引擎(测引擎的异常兜底)
		handler: def.handler
	};
	if (!d.name || typeof d.handler !== "function") return;
	CMD[d.name] = d;
	CMD_LIST.push(d);
	var i, a = def.aliases || [];
	for (i = 0; i < a.length; i++) {
		var al = s(a[i]).toLowerCase();
		if (!al) continue;
		ALIAS[al] = d;
		ALIAS_COUNT++;
	}
}

// 引擎通道证据
var ENGINE_ALIVE = false;
var ENGINE_HITS = {};
var FALLBACK_DONE = null;   // 兜底刚处理过的这一行,等引擎通道来"让位"

function hitsText() {
	var out = [], i;
	for (i = 0; i < ENGINE_REGS.length; i++) {
		var n = ENGINE_REGS[i];
		out.push("/" + n + " × " + (ENGINE_HITS[n] || 0));
	}
	return out.join(", ");
}

// 统一的指令执行:返回字符串(引擎通道要求返回字符串才会回话)
function runNamed(name, raw, sender, via) {
	var key = s(name).toLowerCase();
	var def = CMD[key] || ALIAS[key];
	if (!def) return "";

	if (def.op && !isOperator(sender)) {
		log("拒绝 " + whoText(sender) + " 执行 /" + key + "：不是 op");
		return C_ERR + "这条指令需要 OP 权限" + C_DIM + "(把 " + whoText(sender) +
		       " 加进本世界 op 名单：/op " + whoText(sender) + ")";
	}

	var a = splitArgs(raw);
	if (def.throws) {
		// 故意不接异常 -> 交给引擎的 pcall,验证引擎会回 "Command error: ..."
		return s(def.handler(sender, raw, a, via));
	}
	try {
		return s(def.handler(sender, raw, a, via));
	} catch (e) {
		log("/" + key + " 抛异常(框架已捕获): " + e);
		return C_ERR + "指令内部错误： " + e;
	}
}

// 引擎通道:每个注册名各自一个包装函数(这样能知道玩家敲的是哪个名字)
function engineHandlerFor(regName) {
	return function (sender, raw) {
		ENGINE_ALIVE = true;
		ENGINE_HITS[regName] = (ENGINE_HITS[regName] || 0) + 1;
		// 这一行刚被 onChat 兜底处理过 -> 静默让位(返回空串 = 引擎不发任何消息,也不执行第二遍)
		if (FALLBACK_DONE && FALLBACK_DONE.reg === regName && FALLBACK_DONE.args === s(raw)) {
			FALLBACK_DONE = null;
			log("引擎通道命中 /" + regName + "(本行已由兜底处理，本次让位)");
			return "";
		}
		if (DIRECT_CMDS[regName]) {
			log("引擎通道执行 /" + regName + " [" + trim(raw) + "] by " + whoText(sender));
			return runNamed(DIRECT_CMDS[regName], raw, s(sender), "engine");
		}
		var f = splitFirst(raw);
		var sub = f.head.toLowerCase();
		if (!sub) sub = "help";
		log("引擎通道执行 /" + regName + " " + sub + " [" + trim(f.tail) + "] by " + whoText(sender));
		return runNamed(sub, f.tail, s(sender), "engine");
	};
}

// onChat 兜底:只有"引擎通道还没被证明可用"时才接管,且只在客户端
function onChat(msg) {
	var line = s(msg);
	if (line.length < 2 || line.charAt(0) !== "/") return;   // 只管命令行
	var body = line.substring(1);
	var sp = body.indexOf(" ");
	var name = (sp < 0 ? body : body.substring(0, sp));
	var raw  = (sp < 0 ? ""   : body.substring(sp + 1));
	var key  = name.toLowerCase();
	if (!isOurCommand(key)) return;           // 不是本模组的指令,别多管
	if (ENV_IS_SERVER) return;                // 服务器端只有引擎通道能回话,不兜底
	if (ENGINE_ALIVE) return;                 // 引擎通道活着 -> 全部交给它,绝不重复

	var me = localSnapshot();
	var sender = me ? s(me.name) : "";
	log("兜底通道接住 /" + name + "(引擎通道尚未生效)");
	var direct = DIRECT_CMDS[key];
	var reply;
	if (direct) {
		reply = runNamed(direct, raw, sender, "fallback");
	} else {
		var f = splitFirst(raw);
		var sub = f.head.toLowerCase();
		if (!sub) sub = "help";
		reply = runNamed(sub, f.tail, sender, "fallback");
	}
	if (reply) {
		if (typeof player !== "undefined" && player && typeof player.sendMessage === "function")
			player.sendMessage(reply);
		else
			log("[兜底回复发不出去] " + reply);
	}
	FALLBACK_DONE = { reg: name, args: s(raw) };
}

// ---------------------------------------------------------------------------
// 自检
// ---------------------------------------------------------------------------
var REPORT = [];

function addItem(title, status, detail) {
	REPORT.push({ title: s(title), status: s(status), detail: s(detail) });
}

function countReport(st) {
	var n = 0, i;
	for (i = 0; i < REPORT.length; i++) if (REPORT[i].status === st) n++;
	return n;
}

// 探测本模组会用到的引擎 API;返回 {miss:[], serverSkip:[], ok:N}
function probeApi() {
	var miss = [], serverSkip = [], ok = 0;

	function want(label, cond, serverOnly) {
		if (cond) { ok++; return; }
		if (serverOnly && ENV_IS_SERVER) { serverSkip.push(label); return; }
		miss.push(label);
	}

	want("modLog",         typeof modLog === "function");
	want("Commands.register", typeof Commands !== "undefined" && Commands && typeof Commands.register === "function");
	want("level.getBlock",  typeof level !== "undefined" && level && typeof level.getBlock === "function");
	want("level.setBlock",  typeof level !== "undefined" && level && typeof level.setBlock === "function");
	want("level.getTime",   typeof level !== "undefined" && level && typeof level.getTime === "function");
	want("level.setTime",   typeof level !== "undefined" && level && typeof level.setTime === "function");
	want("level.isOp",      typeof level !== "undefined" && level && typeof level.isOp === "function");
	want("level.isHost",    typeof level !== "undefined" && level && typeof level.isHost === "function");
	want("level.listPlayers", typeof level !== "undefined" && level && typeof level.listPlayers === "function");
	want("level.getCurrentDimension", typeof level !== "undefined" && level && typeof level.getCurrentDimension === "function");
	want("level.changePlayerDimension", typeof level !== "undefined" && level && typeof level.changePlayerDimension === "function");
	want("level.spawnVanilla", typeof level !== "undefined" && level && typeof level.spawnVanilla === "function");
	want("level.spawnItemEntity", typeof level !== "undefined" && level && typeof level.spawnItemEntity === "function");
	want("Player.list",     typeof Player !== "undefined" && Player && typeof Player.list === "function");
	want("Player.self",     typeof Player !== "undefined" && Player && typeof Player.self === "function");
	want("mob.damage",      typeof mob !== "undefined" && mob && typeof mob.damage === "function");
	want("mob.remove",      typeof mob !== "undefined" && mob && typeof mob.remove === "function");
	want("mob.getNearby",   typeof mob !== "undefined" && mob && typeof mob.getNearby === "function");
	// 客户端专有(服务器上缺失属正常,ModEngine.cpp:352-360 就是空实现)
	want("player.sendMessage", typeof player !== "undefined" && player && typeof player.sendMessage === "function", true);
	want("player.addItem",  typeof player !== "undefined" && player && typeof player.addItem === "function", true);

	return { miss: miss, serverSkip: serverSkip, ok: ok };
}

function runSelfTest() {
	var i;
	REPORT = [];

	// 1) 加载
	addItem("模组加载", "PASS", MOD_NAME + " v" + MOD_VERSION + " (build " + MOD_BUILD + ")");

	// 2) 环境
	var host = (typeof level !== "undefined" && level && typeof level.isHost === "function") ? level.isHost() : null;
	var dim = (typeof level !== "undefined" && level && typeof level.getCurrentDimension === "function") ? level.getCurrentDimension() : "?";
	var time = (typeof level !== "undefined" && level && typeof level.getTime === "function") ? level.getTime() : "?";
	addItem("运行环境", "INFO", ENV_TEXT + " | isHost()=" + b2s(host) + " | 维度=" + dim + " | 世界时间=" + time);

	// 3) 框架注册表
	var names = [], j;
	for (j = 0; j < CMD_LIST.length; j++) names.push(CMD_LIST[j].name);
	addItem("框架注册表", CMD_LIST.length > 0 ? "PASS" : "FAIL",
		CMD_LIST.length + " 条指令 + " + ALIAS_COUNT + " 个别名： " + names.join(" "));

	// 4) 引擎指令通道(这是本轮最关键的观察项)
	if (ENGINE_ALIVE)
		addItem("引擎指令通道", "PASS", "已生效(引擎调用过注册函数): " + hitsText());
	else
		addItem("引擎指令通道", "FAIL",
			"引擎还没调用过本模组的注册函数 -> 若敲完本条仍不变，说明 runRegisteredCommand 仍是旧版(只查主堆): " + hitsText());

	// 5~7) 框架内部逻辑单测(不依赖引擎)
	var p1 = splitArgs(" a  b   c ").join(",");
	addItem("参数解析-多余空白", p1 === "a,b,c" ? "PASS" : "FAIL", 'splitArgs(" a  b   c ") = "' + p1 + '"(期望 a,b,c)');

	var p2 = splitArgs('give Steve "5 64"').join(",");
	addItem("参数解析-引号", p2 === "give,Steve,5 64" ? "PASS" : "FAIL", 'splitArgs(\'give Steve "5 64"\') = "' + p2 + '"(期望 give,Steve,5 64)');

	var p3 = splitArgs("").length;
	addItem("参数解析-空", p3 === 0 ? "PASS" : "FAIL", "splitArgs(\"\").length = " + p3 + "(期望 0)");

	// 8) API 探测
	var pr = probeApi();
	addItem("引擎 API 探测", pr.miss.length === 0 ? "PASS" : "FAIL",
		pr.miss.length ? ("缺失： " + pr.miss.join(", ")) :
		(pr.ok + " 个全部可用" + (pr.serverSkip.length ? "(服务器端预期缺失： " + pr.serverSkip.join(", ") + ")" : "")));

	// 9) op 判定
	var ghost = (typeof level !== "undefined" && level && typeof level.isOp === "function") ? level.isOp("__cmdkit_根本没有这个玩家__") : null;
	addItem("op 判定(名字)", ghost === false ? "PASS" : "FAIL",
		'level.isOp("不存在的玩家") = ' + s(ghost) + "(期望 false；注意它收的是名字不是 id)");

	// 10) 框架 op 门禁(程序化验证:拿一个肯定不是 op 的名字去跑需要 op 的指令)
	var gate = runNamed("oktest", "", "__cmdkit_根本没有这个玩家__", "selftest");
	addItem("框架 op 门禁", gate.indexOf("需要 OP") >= 0 ? "PASS" : "FAIL", "非 op 跑 /ct oktest -> " + gate);

	// 11) 玩家列表
	var list = allPlayers(), ptxt = [];
	for (j = 0; j < list.length; j++) ptxt.push(playerText(list[j]));
	addItem("玩家列表", "INFO", "共 " + list.length + " 人： " + (ptxt.length ? ptxt.join(" | ") : "无"));

	// 12) 回话通道
	if (ENV_IS_SERVER)
		addItem("回话通道", "INFO", "独立服务器：模组只能用 Commands.register 的返回值回话(player.sendMessage 是空实现)");
	else
		addItem("回话通道", "INFO", "客户端：引擎通道走 gui.addMessage；兜底通道走 player.sendMessage");

	// 13) 日志
	addItem("日志", "INFO", "modLog 限流 20 条/秒；客户端日志 %TEMP%\\mcpe_mod.log，服务器 logs\\mod.log");

	// 14) 人工确认项
	addItem("待人工确认", "INFO",
		"敲 /ct nosuch -> 客户端应静默，服务器应回 Unknown command；敲 /CT -> 引擎精确匹配，应无任何反应；" +
		"敲 /ct boom -> 应回 Command error: ...(引擎的异常兜底)");

	return REPORT;
}

function reportSummary() {
	return "自检 " + REPORT.length + " 项： " + C_OK + "通过 " + countReport("PASS") + C_ERR +
	       " 失败 " + countReport("FAIL") + C_INFO + " 提示 " + countReport("INFO") + C_DIM +
	       " (逐条看： /ct r <序号>；详情也在日志里)";
}

function reportLine(n) {
	if (n < 1 || n > REPORT.length) return "";
	var it = REPORT[n - 1];
	var col = it.status === "PASS" ? C_OK : (it.status === "FAIL" ? C_ERR : C_INFO);
	return col + n + ") [" + it.status + "] " + it.title + C_DIM + " - " + it.detail;
}

// ---------------------------------------------------------------------------
// 生物名表(就是引擎 level.spawnVanilla 真正认的那 8 种)
// ---------------------------------------------------------------------------
var MOB_LIST = ["zombie", "creeper", "skeleton", "pigzombie", "cow", "pig", "sheep", "chicken"];
var MOB_ALIAS = {
	"僵尸": "zombie", "苦力怕": "creeper", "爬行者": "creeper", "骷髅": "skeleton",
	"僵尸猪人": "pigzombie", "牛": "cow", "猪": "pig", "羊": "sheep", "鸡": "chicken"
};

// 维度切换用的落点:沿用本工程既有做法(cmd_mod),抬高一点免得落进方块里
function enterDimension(p, dim) {
	if (typeof level.changePlayerDimension !== "function")
		return false;
	var x = Math.floor(p.x) + 0.5;
	var y = Math.max(Math.floor(p.y), 80) + 0.5;
	var z = Math.floor(p.z) + 0.5;
	level.changePlayerDimension(p.id, dim, x, y, z);
	return true;
}

// ---------------------------------------------------------------------------
// 指令:自检 / 帮助 / 信息
// ---------------------------------------------------------------------------

defineCmd({
	name: "run", aliases: ["自检", "test"],
	usage: "/ct run",
	desc: "跑一遍指令系统自检，结果写进报告(/ct r 看逐条)",
	handler: function (sender, raw, a) {
		runSelfTest();
		var i, lines = [];
		for (i = 0; i < REPORT.length; i++)
			log(REPORT[i].status + " | " + REPORT[i].title + " | " + REPORT[i].detail);
		log("自检汇总： 通过 " + countReport("PASS") + " 失败 " + countReport("FAIL") + " 提示 " + countReport("INFO"));
		return tag(C_HI + "执行者 " + whoText(sender) + C_DIM + " | ") + reportSummary();
	}
});

defineCmd({
	name: "r", aliases: ["报告", "report"],
	usage: "/ct r <序号|all>",
	desc: "看自检报告的第 n 条(all = 只看汇总)",
	handler: function (sender, raw, a) {
		if (!a.length) return C_USE + "/ct r <序号|all>(先跑 /ct run)";
		if (!REPORT.length) return C_ERR + "还没有报告 -- 先敲 /ct run";
		if (a[0].toLowerCase() === "all")
			return reportSummary();
		var n = toInt(a[0], -1);
		if (n < 1 || n > REPORT.length)
			return C_ERR + "序号要在 1 ~ " + REPORT.length + " 之间";
		return reportLine(n);
	}
});

defineCmd({
	name: "help", aliases: ["帮助", "?"],
	usage: "/ct help [页码]",
	desc: "列出本模组的全部指令",
	handler: function (sender, raw, a) {
		var perPage = 8;
		var page = a.length ? toInt(a[0], 1) : 1;
		var pages = Math.max(1, Math.ceil(CMD_LIST.length / perPage));
		if (page < 1 || page > pages) page = 1;
		var out = [tag(C_HI + "指令列表 (" + page + "/" + pages + ")")];
		var i;
		for (i = (page - 1) * perPage; i < page * perPage && i < CMD_LIST.length; i++) {
			var d = CMD_LIST[i];
			out.push(C_DIM + (d.op ? "[op] " : "") + C_HI + (d.usage || ("/ct " + d.name)) + C_DIM + " - " + d.desc);
		}
		out.push(C_DIM + "共 " + CMD_LIST.length + " 条 + " + ALIAS_COUNT + " 个别名" +
		         (pages > 1 ? ("; 换页： /ct help " + (page < pages ? page + 1 : 1)) : ""));
		// 聊天框是按宽度自动折行的,但不认 \n(Gui::addMessage, Gui.cpp:307-327),所以用 " | " 连接
		return out.join(C_DIM + " | ");
	}
});

defineCmd({
	name: "info", aliases: ["信息"],
	usage: "/ct info",
	desc: "当前环境 / 端别 / 引擎通道状态",
	handler: function (sender, raw, a) {
		var dim = (typeof level.getCurrentDimension === "function") ? level.getCurrentDimension() : "?";
		var host = (typeof level.isHost === "function") ? b2s(level.isHost()) : "?";
		var op = isOperator(sender);
		return tag(C_HI + "v" + MOD_VERSION) + C_DIM + " | 端： " + C_HI + ENV_TEXT +
		       C_DIM + " | 房主： " + C_HI + host +
		       C_DIM + " | 维度： " + C_HI + dim +
		       C_DIM + " | 你(" + whoText(sender) + ")是 op: " + C_HI + b2s(op) +
		       C_DIM + " | 引擎通道： " + (ENGINE_ALIVE ? C_OK + "已生效" + C_DIM : C_ERR + "尚未生效") +
		       " (" + hitsText() + ")";
	}
});

// ---------------------------------------------------------------------------
// 指令:实用
// ---------------------------------------------------------------------------

defineCmd({
	name: "players", aliases: ["玩家", "who"],
	usage: "/ct players",
	desc: "列出当前能看到的玩家",
	handler: function (sender, raw, a) {
		var list = allPlayers(), out = [tag(C_HI + "玩家 " + list.length + " 人")], i;
		for (i = 0; i < list.length; i++) out.push(C_DIM + "-" + C_HI + playerText(list[i]));
		if (!list.length) out.push(C_DIM + "(看不到任何玩家：单机且 Player.list() 为空？)");
		return out.join(C_DIM + " | ");
	}
});

defineCmd({
	name: "pos", aliases: ["坐标"],
	usage: "/ct pos [玩家]",
	desc: "看某人坐标(不给名字 = 自己)",
	handler: function (sender, raw, a) {
		var t = a.length ? findPlayer(a[0]) : selfSnapshot(sender);
		if (!t) return C_ERR + "找不到玩家" + (a.length ? ": " + a[0] : "(你自己)") + C_DIM + "(在线： " + namesText() + ")";
		return tag(C_HI + s(t.name) + C_DIM + " @ " + C_HI + fmtNum(t.x) + " " + fmtNum(t.y) + " " + fmtNum(t.z) +
		       C_DIM + " 维度 " + C_HI + t.dim + C_DIM + " (id " + t.id + ")");
	}
});

defineCmd({
	name: "tp", aliases: ["传送"],
	usage: "/ct tp <玩家> <x y z> | /ct tp <x y z> | /ct tp <玩家> <目标玩家>",
	desc: "传送某个人(用引擎真实存在的 changePlayerDimension，没有 teleportPlayer)",
	handler: function (sender, raw, a) {
		if (typeof level.changePlayerDimension !== "function")
			return C_ERR + "本环境不支持传送(缺 level.changePlayerDimension)";
		var t;
		// A: /ct tp <玩家> <x> <y> <z>
		if (a.length >= 4 && isNumStr(a[1]) && isNumStr(a[2]) && isNumStr(a[3])) {
			t = findPlayer(a[0]);
			if (!t) return C_ERR + "找不到玩家： " + a[0] + C_DIM + "(在线： " + namesText() + ")";
			var x = toFloat(a[1], 0), y = toFloat(a[2], 0), z = toFloat(a[3], 0);
			level.changePlayerDimension(t.id, t.dim, x, y, z);
			log("tp: " + t.name + " → " + fmtNum(x) + "," + fmtNum(y) + "," + fmtNum(z) + " by " + whoText(sender));
			return tag(C_OK + "已把 " + C_HI + t.name + C_OK + " 传到 " + C_HI + fmtNum(x) + " " + fmtNum(y) + " " + fmtNum(z));
		}
		// B: /ct tp <x> <y> <z>
		if (a.length === 3 && isNumStr(a[0]) && isNumStr(a[1]) && isNumStr(a[2])) {
			t = selfSnapshot(sender);
			if (!t) return C_ERR + "找不到你自己的坐标，请写全： /ct tp <玩家> <x> <y> <z>";
			level.changePlayerDimension(t.id, t.dim, toFloat(a[0], 0), toFloat(a[1], 0), toFloat(a[2], 0));
			return tag(C_OK + "已把你自己传到 " + C_HI + a[0] + " " + a[1] + " " + a[2]);
		}
		// C: /ct tp <玩家> <目标玩家>
		if (a.length === 2) {
			var a1 = findPlayer(a[0]), a2 = findPlayer(a[1]);
			if (!a1) return C_ERR + "找不到玩家： " + a[0] + C_DIM + "(在线： " + namesText() + ")";
			if (!a2) return C_ERR + "找不到玩家： " + a[1] + C_DIM + "(在线： " + namesText() + ")";
			level.changePlayerDimension(a1.id, a2.dim, a2.x, a2.y, a2.z);
			return tag(C_OK + "已把 " + C_HI + a1.name + C_OK + " 传到 " + C_HI + a2.name + C_OK + " 的位置");
		}
		return C_USE + "/ct tp <玩家> <x> <y> <z>" + C_DIM + " | " + C_USE + "/ct tp <x> <y> <z>" +
		       C_DIM + " | " + C_USE + "/ct tp <玩家> <目标玩家>";
	}
});

defineCmd({
	name: "here", aliases: ["拉人"],
	usage: "/ct here [玩家]",
	desc: "把某人拉到你身边",
	handler: function (sender, raw, a) {
		if (typeof level.changePlayerDimension !== "function")
			return C_ERR + "本环境不支持传送";
		var me = selfSnapshot(sender);
		if (!me) return C_ERR + "找不到你自己的坐标";
		if (!a.length) return C_USE + "/ct here <玩家>";
		var t = findPlayer(a[0]);
		if (!t) return C_ERR + "找不到玩家： " + a[0] + C_DIM + "(在线： " + namesText() + ")";
		level.changePlayerDimension(t.id, me.dim, me.x, me.y, me.z);
		return tag(C_OK + "已把 " + C_HI + t.name + C_OK + " 拉到 " + C_HI + me.name + C_OK + " 身边");
	}
});

defineCmd({
	name: "dim", aliases: ["维度"],
	usage: "/ct dim <玩家> <维度号>",
	desc: "把某人送到指定维度(0=主世界，其它维度看模组注册了什么)",
	handler: function (sender, raw, a) {
		if (a.length < 2) return C_USE + "/ct dim <玩家> <维度号>";
		var t = findPlayer(a[0]);
		if (!t) return C_ERR + "找不到玩家： " + a[0];
		var dim = toInt(a[1], -99999);
		if (dim === -99999) return C_ERR + "维度号要是数字";
		if (!enterDimension(t, dim)) return C_ERR + "本环境不支持切维度";
		return tag(C_OK + "已把 " + C_HI + t.name + C_OK + " 送到维度 " + C_HI + dim);
	}
});

defineCmd({
	name: "give", aliases: ["给"],
	usage: "/ct give <物品id> [数量] | /ct give <玩家> <物品id> [数量]",
	desc: "给物品：本机玩家直接进背包，其他人掉在脚下自己捡",
	handler: function (sender, raw, a) {
		if (!a.length) return C_USE + "/ct give <物品id> [数量]" + C_DIM + " | " + C_USE + "/ct give <玩家> <物品id> [数量]";
		var target, itemId, count = 1;
		if (!isNumStr(a[0])) {
			target = findPlayer(a[0]);
			if (!target) return C_ERR + "找不到玩家： " + a[0] + C_DIM + "(在线： " + namesText() + ")";
			if (a.length < 2 || !isNumStr(a[1])) return C_USE + "/ct give <玩家> <物品id> [数量]";
			itemId = toInt(a[1], -1);
			if (a.length > 2) count = toInt(a[2], 1);
		} else {
			target = selfSnapshot(sender);
			if (!target) return C_ERR + "找不到执行者，请写全： /ct give <玩家> <物品id> [数量]";
			itemId = toInt(a[0], -1);
			if (a.length > 1) count = toInt(a[1], 1);
		}
		if (count < 1) count = 1;
		if (count > 64) count = 64;

		if (target.local && typeof player !== "undefined" && player && typeof player.addItem === "function") {
			player.addItem(itemId, count);
			log("give: " + target.name + " += " + count + "x id" + itemId + " (addItem)");
			return tag(C_OK + "已给 " + C_HI + target.name + C_OK + " " + count + " 个物品 (id " + itemId + ")" + C_DIM + "[进背包]");
		}
		if (typeof level.spawnItemEntity !== "function")
			return C_ERR + "本环境不支持给非本机玩家发物品";
		var eid = level.spawnItemEntity(target.x, target.y, target.z, itemId, count);
		if (eid === undefined || eid === null || eid <= 0)
			return C_ERR + "发放失败：物品 id " + itemId + " 无效？";
		log("give: drop " + count + "x id" + itemId + " at " + target.name + " (eid " + eid + ")");
		return tag(C_OK + "已在 " + C_HI + target.name + C_OK + " 脚下掉落 " + count + " 个物品 (id " + itemId + ")" + C_DIM + "[捡起来即可]");
	}
});

defineCmd({
	name: "set", aliases: ["生成生物"],
	usage: "/ct set <" + MOB_LIST.join("|") + "> [x y z | 玩家]",
	desc: "生成一只原版生物(就是引擎 spawnVanilla 认的那 8 种)",
	handler: function (sender, raw, a) {
		if (!a.length) return C_USE + "/ct set <" + MOB_LIST.join("|") + "> [x y z | 玩家]";
		var kind = a[0].toLowerCase();
		if (MOB_ALIAS[kind]) kind = MOB_ALIAS[kind];
		if (MOB_LIST.indexOf(kind) < 0)
			return C_ERR + "不支持的生物： " + a[0] + C_DIM + "(支持： " + MOB_LIST.join(" ") + ")";
		var x, y, z, where;
		if (a.length >= 4 && isNumStr(a[1]) && isNumStr(a[2]) && isNumStr(a[3])) {
			x = toFloat(a[1], 0); y = toFloat(a[2], 0); z = toFloat(a[3], 0);
			where = "指定坐标";
		} else if (a.length >= 2) {
			var t = findPlayer(a[1]);
			if (!t) return C_ERR + "找不到玩家： " + a[1];
			x = t.x; y = t.y; z = t.z;
			where = t.name + " 身边";
		} else {
			var me = selfSnapshot(sender);
			if (!me) return C_ERR + "找不到执行者坐标，请写全： /ct set " + kind + " <x> <y> <z>";
			x = me.x; y = me.y; z = me.z;
			where = "执行者(" + me.name + ")身边";
		}
		var eid = level.spawnVanilla(kind, x + 1.5, y, z);
		if (eid === undefined || eid === null || eid < 0)
			return C_ERR + "生成失败： " + kind + "(实体 id " + eid + ")";
		log("set: spawn " + kind + " at " + fmtNum(x + 1.5) + "," + fmtNum(y) + "," + fmtNum(z) + " -> eid " + eid);
		return tag(C_OK + "已生成 " + C_HI + kind + C_OK + "(" + where + ")实体 id " + C_HI + eid);
	}
});

defineCmd({
	name: "kill",
	usage: "/ct kill | /ct kill <玩家> | /ct kill mobs [半径]",
	desc: "杀自己 / 杀某人 / 清理身边生物(不动玩家)",
	handler: function (sender, raw, a) {
		function hurt(p) {
			if (typeof mob === "undefined" || typeof mob.damage !== "function")
				return C_ERR + "本环境不支持(mob.damage 不可用)";
			mob.damage(p.id, 1000);
			log("kill: " + p.name + " (id " + p.id + ") by " + whoText(sender));
			return tag(C_OK + "已对 " + C_HI + p.name + C_OK + " 造成 1000 点伤害 (id " + p.id + ")");
		}
		if (!a.length) {
			var me = selfSnapshot(sender);
			if (!me) return C_ERR + "找不到执行者，请写： /ct kill <玩家>";
			return hurt(me);
		}
		if (a[0].toLowerCase() === "mobs") {
			if (typeof mob === "undefined" || typeof mob.getNearby !== "function")
				return C_ERR + "本环境不支持(mob.getNearby 不可用)";
			var who = selfSnapshot(sender);
			if (!who) return C_ERR + "找不到执行者坐标";
			var r = (a.length > 1) ? toFloat(a[1], 16) : 16;
			var near = mob.getNearby(who.x, who.y, who.z, r, 32);
			var n = 0, i;
			for (i = 0; i < near.length; i++) {
				if (near[i].type === 0) continue;   // type 0 = 玩家,不动
				mob.remove(near[i].id);
				n++;
			}
			log("kill mobs: removed " + n + " in r=" + r + " by " + whoText(sender));
			return tag(C_OK + "已清理半径 " + r + " 格内的 " + n + " 个实体(不含玩家)");
		}
		var t = findPlayer(a[0]);
		if (!t) return C_ERR + "找不到玩家： " + a[0] + C_DIM + "(在线： " + namesText() + "；清生物用 /ct kill mobs [半径])";
		return hurt(t);
	}
});

defineCmd({
	name: "time", aliases: ["时间"],
	usage: "/ct time [get|day|night|<tick>]",
	desc: "看/改世界时间(day=1000, night=14000)",
	handler: function (sender, raw, a) {
		if (typeof level.getTime !== "function")
			return C_ERR + "本环境没有 level.getTime";
		var cur = level.getTime();
		if (!a.length || a[0].toLowerCase() === "get")
			return tag(C_HI + "世界时间 " + cur + C_DIM + " (day=1000, night=14000)");
		var v = a[0].toLowerCase(), t;
		if (v === "day") t = 1000;
		else if (v === "night") t = 14000;
		else {
			t = toInt(a[0], -1);
			if (t < 0) return C_USE + "/ct time [get|day|night|<tick>]";
		}
		if (typeof level.setTime !== "function") return C_ERR + "本环境没有 level.setTime";
		level.setTime(t);
		log("time: " + cur + " → " + t + " by " + whoText(sender));
		return tag(C_OK + "世界时间 " + cur + " → " + C_HI + t);
	}
});

// ---------------------------------------------------------------------------
// 指令:框架/引擎行为测试
// ---------------------------------------------------------------------------

defineCmd({
	name: "echo", aliases: ["回显"],
	usage: "/ct echo <随便写点什么>",
	desc: "把引擎传进来的执行者名和参数原样回显(测参数传递)",
	handler: function (sender, raw, a) {
		return tag("执行者=[" + C_HI + whoText(sender) + C_DIM + "] 原始参数=[" + C_HI + s(raw) + C_DIM +
		           "] 切分后=" + C_HI + a.length + C_DIM + " 段 " + (a.length ? "[" + a.join("|") + "]" : ""));
	}
});

defineCmd({
	name: "boom",
	usage: "/ct boom",
	desc: "故意抛异常，验证引擎的异常兜底(应回 Command error: ...)",
	throws: true,
	handler: function (sender, raw, a) {
		throw new Error("这是 /ct boom 故意抛的异常");
	}
});

defineCmd({
	name: "oktest", aliases: ["optest"],
	usage: "/ct oktest",
	desc: "需要 OP 的示例指令(验证框架的 op 门禁)",
	op: true,
	handler: function (sender, raw, a) {
		return tag(C_OK + "你是 op，这条需要 op 的指令执行成功(执行者 " + whoText(sender) + ")");
	}
});

// ---------------------------------------------------------------------------
// 进世界提示（“输入 /help 查看全部”）
//
// onJoinWorld 不一定每端都触发，所以再用 onTick 兜一层：谁先来都行，
// 靠 _welcomed 保证只发一次。服务器端 player.sendMessage 是空实现
// （ModEngine.cpp:352-360）发不出去，所以只在客户端发。
// ---------------------------------------------------------------------------
var _welcomed = false;

function welcomeOnce() {
	if (_welcomed) return;
	if (typeof isClient !== "undefined" && !isClient) return;
	// 还没进世界时没有本机玩家（Player.self() 返回 null）—— 标题界面不能乱发，
	// 否则 _welcomed 被提前用掉，真进世界反而看不到提示了。
	if (!localSnapshot()) return;
	if (typeof player === "undefined" || !player) return;
	if (typeof player.sendMessage !== "function") return;
	_welcomed = true;
	player.sendMessage(MOD_TAG + C_HI + "输入 " + C_INFO + "/help" + C_HI + " 查看全部指令" +
	                   C_DIM + "(也可以 /ct help)");
}

function onJoinWorld() { welcomeOnce(); }
function onTick() { welcomeOnce(); }

// ---------------------------------------------------------------------------
// 注册
// ---------------------------------------------------------------------------
(function () {
	var i;
	for (i = 0; i < ENGINE_REGS.length; i++) {
		if (typeof Commands !== "undefined" && Commands && typeof Commands.register === "function")
			Commands.register(ENGINE_REGS[i], engineHandlerFor(ENGINE_REGS[i]));
	}
})();

log(MOD_NAME + " v" + MOD_VERSION + " 已加载 | " + ENV_TEXT + " | 指令： " +
    ENGINE_REGS.join(" / ") + " | 共 " + CMD_LIST.length + " 个子命令 + " + ALIAS_COUNT + " 别名 | 自检： /ct run");
